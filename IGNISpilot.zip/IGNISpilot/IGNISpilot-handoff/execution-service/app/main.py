from __future__ import annotations

import hashlib
import json
import sqlite3
import time
import uuid
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any, Literal

import httpx
from fastapi import Depends, FastAPI, Header, HTTPException, Query, status
from pydantic import BaseModel, Field, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")
    public_personal_secret_token: str
    public_account_id: str
    execution_service_token: str
    public_api_base_url: str = "https://api.public.com"
    database_path: str = "./ignispilot_execution.sqlite3"
    live_trading_enabled: bool = False
    max_order_notional_usd: float = 1000.0
    preflight_ttl_seconds: int = 300


settings = Settings()


def db() -> sqlite3.Connection:
    connection = sqlite3.connect(settings.database_path)
    connection.row_factory = sqlite3.Row
    return connection


def init_db() -> None:
    Path(settings.database_path).parent.mkdir(parents=True, exist_ok=True)
    with db() as connection:
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS live_trade_tickets (
              ticket_id TEXT PRIMARY KEY,
              payload_json TEXT NOT NULL,
              payload_hash TEXT NOT NULL,
              preflight_json TEXT NOT NULL,
              created_at INTEGER NOT NULL,
              expires_at INTEGER NOT NULL,
              submitted_at INTEGER,
              broker_order_id TEXT,
              status TEXT NOT NULL
            )
            """
        )


class OrderRequest(BaseModel):
    symbol: str = Field(min_length=1, max_length=12)
    side: Literal["BUY", "SELL"]
    order_type: Literal["MARKET", "LIMIT"] = "MARKET"
    quantity: float | None = Field(default=None, gt=0)
    amount: float | None = Field(default=None, gt=0)
    limit_price: float | None = Field(default=None, gt=0)
    time_in_force: Literal["DAY"] = "DAY"

    @model_validator(mode="after")
    def validate_order(self) -> "OrderRequest":
        self.symbol = self.symbol.strip().upper()
        if not self.symbol.replace(".", "").replace("-", "").isalnum():
            raise ValueError("Symbol contains unsupported characters")
        if (self.quantity is None) == (self.amount is None):
            raise ValueError("Provide exactly one of quantity or amount")
        if self.order_type == "LIMIT" and self.limit_price is None:
            raise ValueError("limit_price is required for LIMIT orders")
        if self.order_type == "MARKET" and self.limit_price is not None:
            raise ValueError("limit_price is only valid for LIMIT orders")
        if self.amount is not None and self.amount > settings.max_order_notional_usd:
            raise ValueError(f"Order amount exceeds ${settings.max_order_notional_usd:,.2f} service limit")
        return self

    def public_payload(self, *, include_order_id: bool) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "instrument": {"symbol": self.symbol, "type": "EQUITY"},
            "orderSide": self.side,
            "orderType": self.order_type,
            "expiration": {"timeInForce": self.time_in_force},
            "validateOrder": True,
            "useMargin": False,
        }
        if include_order_id:
            payload["orderId"] = str(uuid.uuid4())
        if self.quantity is not None:
            payload["quantity"] = str(self.quantity)
        else:
            payload["amount"] = str(self.amount)
        if self.limit_price is not None:
            payload["limitPrice"] = str(self.limit_price)
        return payload


class SubmitRequest(BaseModel):
    ticket_id: str
    payload_hash: str
    confirm_live_trade: Literal[True]


class PublicClient:
    def __init__(self) -> None:
        self._token: str | None = None
        self._token_expires_at = 0.0
        self._http = httpx.AsyncClient(timeout=20.0)

    async def close(self) -> None:
        await self._http.aclose()

    async def token(self) -> str:
        if self._token and time.time() < self._token_expires_at - 30:
            return self._token
        response = await self._http.post(
            f"{settings.public_api_base_url}/userapiauthservice/personal/access-tokens",
            json={"validityInMinutes": 15, "secret": settings.public_personal_secret_token},
        )
        self._raise(response, "Public authentication failed")
        token = response.json().get("accessToken")
        if not isinstance(token, str) or not token:
            raise HTTPException(502, "Public returned no access token")
        self._token = token
        self._token_expires_at = time.time() + 15 * 60
        return token

    async def request(self, method: str, path: str, payload: dict[str, Any] | None = None) -> Any:
        token = await self.token()
        response = await self._http.request(
            method,
            f"{settings.public_api_base_url}{path}",
            headers={"Authorization": f"Bearer {token}", "Accept": "application/json"},
            json=payload,
        )
        self._raise(response, "Public rejected the request")
        if not response.content:
            return {"accepted": True}
        return response.json()

    @staticmethod
    def _raise(response: httpx.Response, fallback: str) -> None:
        if response.is_success:
            return
        detail = fallback
        try:
            body = response.json()
            candidate = body.get("message") or body.get("error") or body.get("detail")
            if isinstance(candidate, str):
                detail = candidate
        except Exception:
            pass
        raise HTTPException(response.status_code, detail)


public = PublicClient()


async def authorize(x_execution_token: str = Header(default="")) -> None:
    if not settings.execution_service_token or x_execution_token != settings.execution_service_token:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid execution-service token")


@asynccontextmanager
async def lifespan(_: FastAPI):
    init_db()
    yield
    await public.close()


app = FastAPI(title="IGNISpilot Live Execution Service", version="1.0.0", lifespan=lifespan)


@app.get("/health")
async def health(_: None = Depends(authorize)) -> dict[str, Any]:
    return {"ok": True, "liveTradingEnabled": settings.live_trading_enabled, "broker": "Public"}


@app.get("/account")
async def account(_: None = Depends(authorize)) -> Any:
    return await public.request("GET", "/userapigateway/trading/account")


@app.get("/portfolio")
async def portfolio(_: None = Depends(authorize)) -> Any:
    return await public.request("GET", f"/userapigateway/trading/{settings.public_account_id}/portfolio/v2")


@app.get("/quotes")
async def quotes(symbols: str = Query(min_length=1), _: None = Depends(authorize)) -> Any:
    normalized = [item.strip().upper() for item in symbols.split(",") if item.strip()][:25]
    if not normalized:
        raise HTTPException(422, "At least one symbol is required")
    return await public.request(
        "POST",
        f"/userapigateway/marketdata/{settings.public_account_id}/quotes",
        {"instruments": [{"symbol": symbol, "type": "EQUITY"} for symbol in normalized]},
    )


@app.post("/orders/preflight")
async def preflight(order: OrderRequest, _: None = Depends(authorize)) -> dict[str, Any]:
    payload = order.public_payload(include_order_id=False)
    result = await public.request(
        "POST",
        f"/userapigateway/trading/{settings.public_account_id}/preflight/single-leg",
        payload,
    )
    ticket_id = str(uuid.uuid4())
    canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"))
    payload_hash = hashlib.sha256(canonical.encode()).hexdigest()
    now = int(time.time())
    expires_at = now + settings.preflight_ttl_seconds
    with db() as connection:
        connection.execute(
            "INSERT INTO live_trade_tickets VALUES (?, ?, ?, ?, ?, ?, NULL, NULL, ?)",
            (ticket_id, canonical, payload_hash, json.dumps(result), now, expires_at, "PREFLIGHT_PASSED"),
        )
    return {"ticketId": ticket_id, "payloadHash": payload_hash, "expiresAt": expires_at, "order": payload, "preflight": result}


@app.post("/orders/submit")
async def submit(request: SubmitRequest, _: None = Depends(authorize)) -> dict[str, Any]:
    if not settings.live_trading_enabled:
        raise HTTPException(423, "LIVE_TRADING_ENABLED is false; no order was sent")
    with db() as connection:
        row = connection.execute("SELECT * FROM live_trade_tickets WHERE ticket_id = ?", (request.ticket_id,)).fetchone()
        if row is None:
            raise HTTPException(404, "Preflight ticket not found")
        if row["payload_hash"] != request.payload_hash:
            raise HTTPException(409, "Order payload hash does not match preflight")
        if row["submitted_at"] is not None:
            return {"status": "ALREADY_SUBMITTED", "brokerOrderId": row["broker_order_id"]}
        if int(time.time()) > row["expires_at"]:
            raise HTTPException(410, "Preflight ticket expired; run preflight again")
        payload = json.loads(row["payload_json"])
        payload["orderId"] = str(uuid.uuid4())
        result = await public.request("POST", f"/userapigateway/trading/{settings.public_account_id}/order", payload)
        broker_order_id = result.get("orderId") if isinstance(result, dict) else None
        connection.execute(
            "UPDATE live_trade_tickets SET submitted_at = ?, broker_order_id = ?, status = ? WHERE ticket_id = ?",
            (int(time.time()), broker_order_id, "SUBMITTED", request.ticket_id),
        )
    return {"status": "SUBMITTED", "brokerOrderId": broker_order_id, "brokerResponse": result}


@app.get("/orders/{order_id}")
async def order_status(order_id: str, _: None = Depends(authorize)) -> Any:
    return await public.request("GET", f"/userapigateway/trading/{settings.public_account_id}/order/{order_id}")


@app.delete("/orders/{order_id}")
async def cancel_order(order_id: str, _: None = Depends(authorize)) -> Any:
    return await public.request("DELETE", f"/userapigateway/trading/{settings.public_account_id}/order/{order_id}")
