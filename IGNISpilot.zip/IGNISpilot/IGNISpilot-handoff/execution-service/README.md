# IGNISpilot Live Execution Service

A small FastAPI boundary for Public market reads and owner-confirmed live orders. Convex is not involved in broker calls.

## Run

```bash
cd execution-service
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload
```

Keep `LIVE_TRADING_ENABLED=false` while testing account, portfolio, quotes, and preflight. Set it to `true` only when ready to permit the explicit `/orders/submit` endpoint.

The service stores short-lived preflight tickets in SQLite and requires the exact payload hash on final submission. Reusing a ticket returns the existing broker reference rather than placing a duplicate order.
