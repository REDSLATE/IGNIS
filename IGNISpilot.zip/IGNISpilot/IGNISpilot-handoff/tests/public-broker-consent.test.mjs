import assert from "node:assert/strict";
import test from "node:test";
import { readFileSync } from "node:fs";

const disclosure = 'The Software is provided on an "as-is" and "as-available" basis. The Company does not guarantee any specific financial outcome, profits, or success rates. You retain ultimate responsibility for monitoring your Brokerage Account activity and managing your risk settings.';
const current = { providerId: "public", termsVersion: "public-broker-connect-v1", disclosureVersion: "public-broker-connect-v1", disclosureHash: "f72838594490642bd972e5b75466a4b9c0c4170a1e66169ad9477a8254f4236a" };

function hasCurrentConsent(record) {
  return Boolean(record)
    && record.providerId === "public"
    && record.termsVersion === current.termsVersion
    && record.disclosureVersion === current.disclosureVersion
    && record.disclosureHash === current.disclosureHash;
}

function requestMode(record, mode) {
  if (!hasCurrentConsent(record)) throw new Error("Current Public broker consent is required");
  if (mode !== "read_only") throw new Error("Execution modes above read-only remain disabled");
  return "read_only_only";
}

test("Public consent dialog starts unchecked and blocks Continue", () => {
  const dialog = readFileSync("src/components/camaro/public-broker-consent-dialog.tsx", "utf8");
  assert.match(dialog, /useState\(false\)/);
  assert.match(dialog, /disabled=\{!agreed \|\| isSaving\}/);
  assert.match(dialog, new RegExp(disclosure.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")));
});

test("connection activation fails closed without a current consent record", () => {
  assert.throws(() => requestMode(null, "read_only"), /consent is required/);
  const broker = readFileSync("convex/camaroBroker.ts", "utf8");
  assert.match(broker, /await requireCurrentPublicConsent\(ctx, args\.workspaceId, userId\);/);
});

test("a successful consent record uses the current disclosure and no secret fields", () => {
  const broker = readFileSync("convex/camaroBroker.ts", "utf8");
  const schema = readFileSync("convex/schema.ts", "utf8");
  assert.equal(hasCurrentConsent(current), true);
  assert.match(broker, /disclosureText: PUBLIC_BROKER_DISCLOSURE/);
  assert.match(broker, /connectionReference: PUBLIC_CONNECTION_REFERENCE/);
  assert.match(schema, /camaroBrokerConsents: defineTable/);
  assert.doesNotMatch(schema, /camaroBrokerConsents[\s\S]{0,900}(secret|token|credential)/i);
});

test("a stale disclosure version requires renewed consent", () => {
  assert.equal(hasCurrentConsent({ ...current, termsVersion: "public-broker-connect-v0" }), false);
  assert.throws(() => requestMode({ ...current, disclosureVersion: "public-broker-connect-v0" }, "read_only"), /consent is required/);
});

test("consent does not unlock execution modes and audit messages omit raw secrets", () => {
  assert.throws(() => requestMode(current, "live_capable"), /remain disabled/);
  const broker = readFileSync("convex/camaroBroker.ts", "utf8");
  const connector = readFileSync("convex/publicConnector.ts", "utf8");
  assert.match(broker, /no credential, secret, or account identifier was stored in the audit trail/i);
  assert.doesNotMatch(connector, /console\.(log|error|warn)/);
  assert.doesNotMatch(broker, /PUBLIC_PERSONAL_SECRET_TOKEN/);
});

test("consent blocks manual live ticket creation and broker-affecting controls", () => {
  const modeControl = readFileSync("src/components/camaro/execution-mode-control.tsx", "utf8");
  const orderPanel = readFileSync("src/components/camaro/operator-order-panel.tsx", "utf8");
  assert.match(modeControl, /publicConsentCurrent/);
  assert.match(modeControl, /disabled=\{consentBlocked/);
  assert.match(modeControl, /Review Public consent/);
  assert.match(orderPanel, /publicConsentCurrent/);
  assert.match(orderPanel, /Current Public consent is required before broker preflight or submission/);
  assert.match(orderPanel, /Live ticket creation and submission remain disabled until consent is current/);
  assert.match(readFileSync("convex/camaroBroker.ts", "utf8"), /createManualLiveExecutionIntent[\s\S]*requireCurrentPublicConsent/);
  assert.match(orderPanel, /disabled=\{!publicConsentCurrent \|\| busy \|\| !ownerApproved/);
});
