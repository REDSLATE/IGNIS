import assert from "node:assert/strict";
import test from "node:test";
import { readFileSync } from "node:fs";
import { evaluatePublicOrderGate, evaluatePublicPreflightGate, PUBLIC_ORDER_BLOCK_REASONS } from "../convex/publicOrderGate.mjs";
import { createPublicOrderId, createPublicOrderPayload, sendPublicJsonRequest } from "../convex/publicOrderId.mjs";

const now = 1_750_000_000_000;
const intent = { ownerApprovalStatus: "approved", ownerApprovedBy: "owner", ownerApprovedAt: now - 1, authorityScope: "One AAPL buy", riskStatus: "passed", preflightStatus: "passed", status: "awaiting_confirmation", preflightVerifiedAt: now - 1, expiresAt: now + 60_000, orderId: createPublicOrderId() };
const state = { now, liveFlagEnabled: true, tradingPermissionVerified: true, pdtLiveConstraintsVerified: true, ownerAuthorityValid: true, settings: { mode: "OPERATOR_CONFIRM_REQUIRED", liveOrderGateEnabled: true }, connection: { status: "connected_read_only", lastSyncedAt: now - 1 }, reconciliation: { status: "reconciled" }, intent };

test("every broker-write refusal gate fails closed with a machine-readable reason", () => {
  const variants = [
    [{ liveFlagEnabled: false }, "LIVE_FLAG_OFF"],
    [{ settings: { mode: "READ_ONLY", liveOrderGateEnabled: false } }, "WORKSPACE_GATE_OFF"],
    [{ intent: { ...intent, ownerApprovalStatus: "pending" } }, "OWNER_APPROVAL_REQUIRED"],
    [{ connection: { status: "not_connected" } }, "BROKER_CONNECTIVITY_REQUIRED"],
    [{ tradingPermissionVerified: false }, "BROKER_PERMISSION_UNVERIFIED"],
    [{ reconciliation: { status: "attention" } }, "RECONCILIATION_REQUIRED"],
    [{ pdtLiveConstraintsVerified: false }, "PDT_LIVE_CONSTRAINTS_UNVERIFIED"],
    [{ intent: { ...intent, riskStatus: "failed" } }, "RISK_CHECK_FAILED"],
    [{ intent: { ...intent, preflightStatus: "pending" } }, "PREFLIGHT_REQUIRED"],
    [{ intent: { ...intent, expiresAt: now } }, "INTENT_EXPIRED"],
  ];
  for (const [patch, reason] of variants) assert.equal(evaluatePublicOrderGate({ ...state, ...patch }), reason);
  assert.equal(evaluatePublicOrderGate(state), null);
  assert.equal(evaluatePublicPreflightGate({ ...state, intent: { ...intent, preflightStatus: "pending" } }), null);
  assert.equal(evaluatePublicPreflightGate({ ...state, ownerAuthorityValid: false, intent: { ...intent, preflightStatus: "pending" } }), PUBLIC_ORDER_BLOCK_REASONS.AUTHORITY_CONSENT_REQUIRED);
});

test("mocked successful request has stable UUID orderId and no network is needed for gate tests", async () => {
  const orderId = createPublicOrderId();
  const payload = createPublicOrderPayload({ ...intent, orderId, symbol: "AAPL", side: "buy", quantity: 2, orderType: "market", timeInForce: "day" });
  let calls = 0;
  const response = await sendPublicJsonRequest(async (_url, init) => { calls += 1; assert.equal(init.method, "POST"); assert.equal(JSON.parse(init.body).orderId, orderId); return new Response(JSON.stringify({ orderId: "public-order" }), { status: 200 }); }, "https://mock.public/order", "POST", "token", payload);
  assert.equal(response.ok, true); assert.equal(calls, 1);
  assert.equal(createPublicOrderPayload({ ...intent, orderId, symbol: "AAPL", side: "buy", quantity: 2, orderType: "market", timeInForce: "day" }).orderId, orderId);
});

test("atomic claim, retry ID reuse, receipts, and reconciliation state transitions stay represented in server code", () => {
  const internal = readFileSync("convex/camaroBrokerInternal.ts", "utf8");
  const trading = readFileSync("convex/publicTrading.ts", "utf8");
  const schema = readFileSync("convex/schema.ts", "utf8");
  assert.match(internal, /intent\.status === "submitting"/);
  assert.match(internal, /retryState = \(intent\.submissionAttemptCount/);
  assert.match(internal, /blockReason/);
  assert.match(trading, /liveOrderGateEnabled\(\)/);
  assert.match(trading, /no broker order was sent/);
  assert.match(trading, /internal\.publicConnector\.syncReadOnly/);
  for (const event of ["owner_approval_recorded", "submission_attempt", "broker_accepted", "status_updated", "fill_recorded"]) assert.match(schema, new RegExp(`v\\.literal\\("${event}"\\)`));
});

test("production Camaro broker contract exports explicit approval, submission, preflight, and read-only verification functions", () => {
  const broker = readFileSync("convex/camaroBroker.ts", "utf8");
  const approval = broker.slice(broker.indexOf("export const approvePublicExecutionIntent"), broker.indexOf("export const submitPublicExecutionIntent"));
  const submission = broker.slice(broker.indexOf("export const submitPublicExecutionIntent"), broker.indexOf("export const preflightPublicExecutionIntent"));
  const preflight = broker.slice(broker.indexOf("export const preflightPublicExecutionIntent"), broker.indexOf("export const refreshPublicExecutionOrder"));
  const readOnly = broker.slice(broker.indexOf("export const enablePublicReadOnly"));

  assert.match(approval, /export const approvePublicExecutionIntent = mutation\(/);
  assert.match(approval, /export const confirmPublicExecutionIntent = mutation\(/);
  assert.doesNotMatch(approval, /confirmPublicExecutionIntent = approvePublicExecutionIntent/);
  assert.match(submission, /export const submitPublicExecutionIntent = action\(/);
  assert.match(submission, /internal\.publicTrading\.submit/);
  assert.match(preflight, /export const preflightPublicExecutionIntent = action\(/);
  assert.match(preflight, /internal\.publicTrading\.preflight/);
  assert.match(readOnly, /export const syncPublicReadOnly = action\(/);
  assert.match(readOnly, /internal\.publicConnector\.syncReadOnly/);
});
