import assert from "node:assert/strict";
import test from "node:test";
import { readFileSync } from "node:fs";

const engine = readFileSync("convex/camaroOpportunityEngine.ts", "utf8");
const schema = readFileSync("convex/schema.ts", "utf8");
const board = readFileSync("convex/camaroOpportunity.ts", "utf8");

test("economic fingerprint uses adaptive zone normalization and stable SHA-256 inputs", () => {
  assert.match(engine, /const zone_size = Math\.max\(atr \* 0\.25, Math\.abs\(entry_zone\) \* 0\.001\)/);
  assert.match(engine, /const normalized_zone = Math\.round\(entry_zone \/ zone_size\)/);
  assert.match(engine, /crypto\.subtle\.digest\("SHA-256"/);
  assert.match(engine, /\[normalizeSymbol\(symbol\), strategy\.trim\(\)\.toLowerCase\(\), directionValue, timeframeValue, normalized_zone\]/);
  assert.match(engine, /by_workspaceId_economicFingerprint/);
});

test("economically identical plans are blocked by an append-only dedup receipt", () => {
  assert.match(engine, /eventType: "opportunity_plan_deduplicated"/);
  assert.match(engine, /no second plan was created and this receipt remains append-only/);
  assert.match(engine, /return \{ intentId: prior\._id, fingerprint, deduplicated: true, capitalPressure: null \}/);
  assert.match(schema, /economicFingerprint: v\.optional\(v\.string\(\)\)/);
  assert.match(schema, /\.index\("by_workspaceId_economicFingerprint"/);
});

test("OpportunityEngine ranks every configured symbol and sends only top-N to Forven cognition", () => {
  assert.match(engine, /DEFAULT_UNIVERSE/);
  for (const symbol of ["AAPL", "TSLA", "NVDA", "SPY", "BTC-USD", "ETH-USD"]) assert.match(engine, new RegExp(`symbol: "${symbol}"`));
  assert.match(engine, /A discovery scan requires one perception snapshot for every configured universe symbol/);
  assert.match(engine, /\.sort\(\(left, right\) => right\.adaptiveScore - left\.adaptiveScore\)/);
  assert.match(engine, /selectedForCognition: index < config\.topN/);
  assert.match(engine, /sent the top \$\{config\.topN\} to Forven cognition/);
  assert.doesNotMatch(engine, /createPublicExecutionIntent|submit.*broker/i);
});

test("AdaptiveKernel retains defaults until the five-loop cadence has sufficient outcomes", () => {
  assert.match(engine, /resolvedLoopCount % 5 === 0 && available\.length >= 2/);
  assert.match(engine, /status: shouldUpdate \? "updated" : "default_retained"/);
  assert.match(engine, /AdaptiveKernel retained safe\/default weights/);
  assert.match(schema, /camaroAdaptiveKernelUpdates/);
});

test("CapitalPressure emits a non-executing REDUCE recommendation only", () => {
  assert.match(engine, /args\.expectedEdge - weakest\.expectedEdge > config\.capitalPressureThreshold/);
  assert.match(engine, /action: "REDUCE"/);
  assert.match(engine, /Recommendation only; no position was closed or broker order submitted/);
  assert.match(engine, /capital_pressure_reduce_recommended/);
  assert.doesNotMatch(engine, /closePosition|reducePosition|submitReduce/);
  assert.match(board, /never closes a position, and never submits a broker order/);
});

test("Jarvis bootstrap validates configuration and preserves intent-only execution", () => {
  assert.match(engine, /export function create_jarvis/);
  assert.match(engine, /MomentumBreakout.*MeanReversion.*FundingArbitrage.*OptionsFlow.*TrendFollowing/);
  assert.match(engine, /Forven thesis generation for ranked top-N only/);
  assert.match(engine, /intent-only; existing authority, consent, risk, and live-order gates remain required/);
  assert.match(engine, /topN must fit the configured universe/);
  assert.match(engine, /capital pressure threshold must be non-negative/);
});
