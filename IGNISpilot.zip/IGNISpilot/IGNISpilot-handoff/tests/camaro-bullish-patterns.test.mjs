import assert from "node:assert/strict";
import test from "node:test";
import { readFileSync } from "node:fs";

const detector = readFileSync("convex/camaroBullishPatterns.js", "utf8");
const engine = readFileSync("convex/camaroOpportunityEngine.ts", "utf8");
const schema = readFileSync("convex/schema.ts", "utf8");
const boundary = readFileSync("convex/camaroOpportunity.ts", "utf8");
const board = readFileSync(
  "src/components/camaro/opportunity-command-board.tsx",
  "utf8",
);
const voice = readFileSync(
  "src/components/camaro/voice-command-panel.tsx",
  "utf8",
);

const bar = (timestamp, high, low, close) => ({ timestamp, high, low, close });

test("bullish research implements transparent Double Bottom, Inverse Head & Shoulders, and Falling Wedge criteria", () => {
  assert.match(detector, /assessDoubleBottom/);
  assert.match(detector, /assessInverseHeadAndShoulders/);
  assert.match(detector, /assessFallingWedge/);
  assert.match(detector, /Comparable troughs/);
  assert.match(detector, /Head dominance/);
  assert.match(detector, /Convergence/);
  assert.match(detector, /Neckline breakout/);
  assert.match(detector, /Resistance breakout/);
  assert.match(detector, /Invalidation/);
});

test("ambiguous or malformed bullish input is blocked rather than inferred", () => {
  assert.match(detector, /At least five ordered bars/);
  assert.match(detector, /At least seven ordered bars/);
  assert.match(detector, /At least six ordered bars/);
  assert.match(detector, /Malformed OHLC research input was blocked/);
  assert.match(detector, /state: "blocked"/);
});

test("bullish pattern research stores confidence freshness detection invalidation and block receipts", () => {
  assert.match(schema, /double_bottom/);
  assert.match(schema, /inverse_head_and_shoulders/);
  assert.match(schema, /falling_wedge/);
  assert.match(engine, /recordBullishPatternResearch/);
  assert.match(engine, /bullish_pattern_detected/);
  assert.match(engine, /bullish_pattern_invalidated/);
  assert.match(engine, /bullish_pattern_blocked/);
  assert.match(boundary, /bullishPatterns/);
});

test("bullish pattern results remain read-only and surface only existing inspection context", () => {
  assert.match(
    engine,
    /No execution intent, broker call, authority change, or live-order action was created/,
  );
  assert.match(board, /Bullish pattern research/);
  assert.match(
    board,
    /Double Bottom, Inverse Head & Shoulders, and Falling Wedge/,
  );
  assert.match(board, /Research only · no execution path/);
  assert.match(voice, /bearish-pattern research context and its corresponding bullish-pattern research context/);
  assert.doesNotMatch(
    detector,
    /createPublicExecutionIntent|confirmPublicExecutionIntent|broker.*submit|submit.*broker/i,
  );
  assert.doesNotMatch(
    engine,
    /recordBullishPatternResearch[\s\S]{0,300}createPublicExecutionIntent|recordBullishPatternResearch[\s\S]{0,300}submit.*broker/i,
  );
});

test("detector confirms a Double Bottom only after a neckline close", async () => {
  const { assessBullishPatterns: assess } =
    await import("../convex/camaroBullishPatterns.js");
  const result = assess(
    [
      bar(1, 100, 90, 94),
      bar(2, 105, 96, 101),
      bar(3, 99, 91, 95),
      bar(4, 103, 94, 100),
      bar(5, 108, 101, 106),
    ],
    5,
  ).find((pattern) => pattern.pattern === "double_bottom");
  assert.equal(result.state, "confirmed");
  assert.equal(
    result.criteria.find((criterion) => criterion.label === "Neckline breakout")
      .met,
    true,
  );
});

test("detector invalidates an Inverse Head & Shoulders below its head buffer", async () => {
  const { assessBullishPatterns: assess } =
    await import("../convex/camaroBullishPatterns.js");
  const result = assess(
    [
      bar(1, 100, 94, 97),
      bar(2, 106, 98, 102),
      bar(3, 101, 88, 92),
      bar(4, 107, 99, 103),
      bar(5, 99, 95, 97),
      bar(6, 102, 96, 99),
      bar(7, 94, 86, 87),
    ],
    7,
  ).find((pattern) => pattern.pattern === "inverse_head_and_shoulders");
  assert.equal(result.state, "invalidated");
  assert.equal(
    result.criteria.find((criterion) => criterion.label === "Invalidation").met,
    true,
  );
});

test("detector blocks an ambiguous Falling Wedge instead of confirming it", async () => {
  const { assessBullishPatterns: assess } =
    await import("../convex/camaroBullishPatterns.js");
  const result = assess(
    [
      bar(1, 100, 90, 95),
      bar(2, 101, 89, 96),
      bar(3, 100, 88, 94),
      bar(4, 102, 87, 95),
      bar(5, 101, 86, 94),
      bar(6, 103, 85, 92),
    ],
    6,
  ).find((pattern) => pattern.pattern === "falling_wedge");
  assert.equal(result.state, "blocked");
  assert.equal(
    result.criteria.find((criterion) => criterion.label === "Convergence").met,
    false,
  );
});

test("detector invalidates a Double Bottom below its trough buffer", async () => {
  const { assessBullishPatterns: assess } = await import("../convex/camaroBullishPatterns.js");
  const result = assess([
    bar(1, 100, 90, 94), bar(2, 105, 96, 101), bar(3, 99, 91, 95), bar(4, 102, 94, 98), bar(5, 92, 88, 89),
  ], 5).find((pattern) => pattern.pattern === "double_bottom");
  assert.equal(result.state, "invalidated");
  assert.equal(result.criteria.find((criterion) => criterion.label === "Invalidation").met, true);
});

test("detector blocks an ambiguous Double Bottom instead of confirming it", async () => {
  const { assessBullishPatterns: assess } = await import("../convex/camaroBullishPatterns.js");
  const result = assess([
    bar(1, 100, 80, 90), bar(2, 105, 96, 101), bar(3, 99, 91, 95), bar(4, 103, 94, 98), bar(5, 104, 97, 100),
  ], 5).find((pattern) => pattern.pattern === "double_bottom");
  assert.equal(result.state, "blocked");
  assert.equal(result.criteria.find((criterion) => criterion.label === "Comparable troughs").met, false);
});

test("detector confirms Inverse Head & Shoulders only after a neckline breakout", async () => {
  const { assessBullishPatterns: assess } = await import("../convex/camaroBullishPatterns.js");
  const result = assess([
    bar(1, 100, 94, 97), bar(2, 106, 98, 102), bar(3, 101, 88, 92), bar(4, 107, 99, 103), bar(5, 99, 95, 97), bar(6, 104, 96, 100), bar(7, 110, 103, 108),
  ], 7).find((pattern) => pattern.pattern === "inverse_head_and_shoulders");
  assert.equal(result.state, "confirmed");
  assert.equal(result.criteria.find((criterion) => criterion.label === "Neckline breakout").met, true);
});

test("detector blocks ambiguous Inverse Head & Shoulders geometry", async () => {
  const { assessBullishPatterns: assess } = await import("../convex/camaroBullishPatterns.js");
  const result = assess([
    bar(1, 100, 80, 90), bar(2, 106, 98, 102), bar(3, 101, 88, 92), bar(4, 107, 99, 103), bar(5, 99, 95, 97), bar(6, 104, 96, 100), bar(7, 110, 103, 108),
  ], 7).find((pattern) => pattern.pattern === "inverse_head_and_shoulders");
  assert.equal(result.state, "blocked");
  assert.equal(result.criteria.find((criterion) => criterion.label === "Shoulder symmetry").met, false);
});

test("detector confirms a Falling Wedge only after resistance breakout", async () => {
  const { assessBullishPatterns: assess } = await import("../convex/camaroBullishPatterns.js");
  const result = assess([
    bar(1, 110, 90, 100), bar(2, 106, 89, 98), bar(3, 102, 88, 96), bar(4, 98, 87, 94), bar(5, 94, 86, 92), bar(6, 96, 85, 95),
  ], 6).find((pattern) => pattern.pattern === "falling_wedge");
  assert.equal(result.state, "confirmed");
  assert.equal(result.criteria.find((criterion) => criterion.label === "Resistance breakout").met, true);
});

test("detector invalidates a Falling Wedge below support", async () => {
  const { assessBullishPatterns: assess } = await import("../convex/camaroBullishPatterns.js");
  const result = assess([
    bar(1, 110, 90, 100), bar(2, 106, 89, 98), bar(3, 102, 88, 96), bar(4, 98, 87, 94), bar(5, 94, 86, 92), bar(6, 92, 80, 82),
  ], 6).find((pattern) => pattern.pattern === "falling_wedge");
  assert.equal(result.state, "invalidated");
  assert.equal(result.criteria.find((criterion) => criterion.label === "Invalidation").met, true);
});
