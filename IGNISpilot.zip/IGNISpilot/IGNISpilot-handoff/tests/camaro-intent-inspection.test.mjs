import assert from "node:assert/strict";
import test from "node:test";
import { readFileSync } from "node:fs";

test("legacy Inspect intent holds incomplete data before the Convex mutation", () => {
  const cockpit = readFileSync("src/app/(app)/app/page.tsx", "utf8");
  assert.match(cockpit, /function validateInspectionIntent/);
  assert.match(cockpit, /Provide a thesis of at least 10 characters before inspection/);
  assert.match(cockpit, /Set confidence between 0 and 1 before inspection/);
  assert.match(cockpit, /disabled=\{Boolean\(inspectionIntentError\) \|\| isCreatingIntent\}/);
  assert.match(cockpit, /if \(inspectionIntentError \|\| !selectedWatchlistEntry\)/);
});

test("legacy Inspect intent uses the selected watchlist asset class", () => {
  const cockpit = readFileSync("src/app/(app)/app/page.tsx", "utf8");
  assert.match(cockpit, /const selectedWatchlistEntry = watchlist\.find/);
  assert.match(cockpit, /symbol: selectedWatchlistEntry\.symbol, assetClass: selectedWatchlistEntry\.assetClass/);
  assert.doesNotMatch(cockpit, /createIntent\(\{ workspaceId, symbol: selectedSymbol, assetClass,/);
});
