import assert from "node:assert/strict";
import test from "node:test";
import { readFileSync } from "node:fs";

const voice = readFileSync("src/lib/camaro/voice.ts", "utf8");
const panel = readFileSync("src/components/camaro/voice-command-panel.tsx", "utf8");
const cockpit = readFileSync("src/app/(app)/app/page.tsx", "utf8");

test("Camaro voice command allowlist is explicitly read-only", () => {
  assert.match(voice, /kind: "show_positions"/);
  assert.match(voice, /kind: "inspect_symbol"/);
  assert.match(voice, /kind: "show_receipts"/);
  assert.match(voice, /kind: "historical_dry_run"/);
  assert.match(voice, /Camaro voice supports only: show positions, inspect a symbol, show receipts, and historical dry run/);
});

test("Camaro voice blocks unsafe trading and governance commands", () => {
  assert.match(voice, /enable\\s\+\(\?:live\\s\+\)\?trading/);
  assert.match(voice, /\(\?:submit\|place\|create\|cancel\)/);
  assert.match(voice, /\(\?:kill\|halt\|flatten\)/);
  assert.match(voice, /Voice commands cannot enable trading, handle orders, change authority or consent, or trigger kill, halt, or flatten actions/);
  assert.doesNotMatch(panel, /createPublicExecutionIntent|confirmPublicExecutionIntent|cancelPublicExecutionOrder/);
});

test("Camaro voice holds a visible transcript until explicit confirmation", () => {
  assert.match(panel, /Visible transcript/);
  assert.match(panel, /Review command/);
  assert.match(panel, /Transcript held for confirmation/);
  assert.match(panel, /Confirm read-only action/);
  assert.match(panel, /setPendingCommand\(parsed\.command\)/);
  assert.match(panel, /if \(!pendingCommand\) return/);
  assert.match(cockpit, /id="camaro-position-state" aria-label="Camaro read-only position state"/);
  assert.match(cockpit, /Camaro will not infer positions from intents, voice input, or stale broker state/);
});

test("Camaro voice prefers an installed feminine en-GB system voice and falls back safely", () => {
  assert.match(voice, /voice\.lang\.toLowerCase\(\)\.startsWith\("en-gb"\)/);
  assert.match(voice, /female\|woman\|zira\|hazel/);
  assert.match(voice, /britishVoices\[0\] \?\? null/);
  assert.match(panel, /No en-GB system voice installed/);
  assert.match(panel, /Text-only responses/);
  assert.match(panel, /British feminine voice preference depends on voices installed by this device; Camaro cannot guarantee a system voice/);
});

test("voice historical dry run uses the existing receipt-only simulation path", () => {
  assert.match(cockpit, /function handleVoiceHistoricalDryRun/);
  assert.match(cockpit, /runHistoricalSimulation\(\{ workspaceId, symbol/);
  assert.match(cockpit, /No broker order was created or routed/);
  assert.doesNotMatch(panel, /broker.*submit|submit.*broker/i);
});
