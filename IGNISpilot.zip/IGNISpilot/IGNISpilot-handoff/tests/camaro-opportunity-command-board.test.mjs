import assert from "node:assert/strict";
import test from "node:test";
import { readFileSync } from "node:fs";

const board = readFileSync("src/components/camaro/opportunity-command-board.tsx", "utf8");
const boundary = readFileSync("convex/camaroOpportunity.ts", "utf8");

test("opportunity command board preserves score and rationale as backend-owned fields", () => {
  assert.match(boundary, /pending OpportunityEngine has not published a ranked scan contract/);
  assert.match(boundary, /no score, model contribution, direction, or rationale is inferred by this board/);
  assert.match(board, /Published scan contract/);
  assert.doesNotMatch(boundary, /adaptiveScore:\s*[0-9]/);
});

test("decision timeline exposes replayable audit and runtime receipts", () => {
  assert.match(boundary, /camaroAudit/);
  assert.match(boundary, /camaroRuntimeReceipts/);
  assert.match(boundary, /stage: "scan"/);
  assert.match(boundary, /stage: "risk_authority"/);
  assert.match(boundary, /stage: "reconciliation"/);
  assert.match(board, /Replayable inspection trail/);
  assert.match(board, /No linked receipt has been recorded yet/);
});

test("dry-run replay is receipt-only and has no broker execution path", () => {
  assert.match(board, /camaroCredits\.runHistoricalSimulation/);
  assert.match(board, /No broker order was created or routed/);
  assert.doesNotMatch(board, /createPublicExecutionIntent/);
  assert.doesNotMatch(board, /confirmPublicExecutionIntent/);
  assert.doesNotMatch(board, /submit.*broker/i);
});

test("capital-pressure REDUCE stays a non-executing recommendation", () => {
  assert.match(boundary, /will not infer or execute a REDUCE recommendation/);
  assert.match(board, /Reduce is recommendation-only/);
  assert.match(board, /non-executing/);
  assert.match(board, /This board never reduces a position/);
  assert.doesNotMatch(board, /reducePosition|executeReduce|submitReduce/);
});
