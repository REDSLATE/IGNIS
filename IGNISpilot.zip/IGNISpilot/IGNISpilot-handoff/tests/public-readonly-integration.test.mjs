import assert from "node:assert/strict";
import test from "node:test";

const FRESH_MS = 15 * 60 * 1000;

function healthFor(connection, now = 2_000_000) {
  if (!connection) return "unavailable";
  if (connection.status === "sync_unavailable") return "error";
  if (!connection.lastSyncedAt) return "unavailable";
  return now - connection.lastSyncedAt > FRESH_MS ? "stale" : "degraded";
}

function requestFailure(status) {
  return status === 401 || status === 403 ? "unauthorized" : "error";
}

function reconcile(intentSymbols, positions) {
  const intents = new Set(intentSymbols.map((symbol) => symbol.toUpperCase()));
  const discrepancies = positions.filter((position) => !intents.has(position.symbol.toUpperCase()));
  return { status: discrepancies.length ? "attention" : "reconciled", discrepancyCount: discrepancies.length };
}

test("unauthorized Public responses fail closed without provider details", () => {
  assert.equal(requestFailure(401), "unauthorized");
  assert.equal(requestFailure(403), "unauthorized");
  assert.equal(healthFor({ status: "sync_unavailable" }), "error");
});

test("non-success Public responses become a generic error state", () => {
  assert.equal(requestFailure(429), "error");
  assert.equal(requestFailure(500), "error");
});

test("old verified Public snapshots surface as stale", () => {
  assert.equal(healthFor({ status: "connected_read_only", lastSyncedAt: 2_000_000 - FRESH_MS - 1 }), "stale");
  assert.equal(healthFor({ status: "connected_read_only", lastSyncedAt: 2_000_000 - FRESH_MS }), "degraded");
});

test("broker positions without Camaro intents create reconciliation attention", () => {
  assert.deepEqual(reconcile(["AAPL"], [{ symbol: "AAPL" }, { symbol: "NVDA" }]), { status: "attention", discrepancyCount: 1 });
  assert.deepEqual(reconcile(["AAPL"], [{ symbol: "aapl" }]), { status: "reconciled", discrepancyCount: 0 });
});
