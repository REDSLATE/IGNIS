import assert from "node:assert/strict";
import test from "node:test";
import { readFileSync } from "node:fs";

const trading = readFileSync("convex/publicTrading.ts", "utf8");
const broker = readFileSync("convex/camaroBroker.ts", "utf8");
const internalBroker = readFileSync("convex/camaroBrokerInternal.ts", "utf8");
const publicOrderId = readFileSync("convex/publicOrderId.mjs", "utf8");
const schema = readFileSync("convex/schema.ts", "utf8");
const intentValidationSource = readFileSync("src/lib/camaro/execution-intent.ts", "utf8");

test("uses only verified Public order endpoints server-side", () => {
  assert.match(trading, /"use node"/);
  assert.match(trading, /\/preflight\/single-leg/);
  assert.match(trading, /\/order`/);
  assert.match(trading, /\/order\/\$\{encodeURIComponent\(state\.intent\.externalOrderReference\)\}/);
  assert.match(publicOrderId, /useMargin: false/);
  assert.match(publicOrderId, /timeInForce: "DAY"/);
  assert.doesNotMatch(trading, /console\.log|NEXT_PUBLIC_PUBLIC/);
});

test("gates preflight and submit fail closed", () => {
  assert.match(trading, /Server revalidation blocked Public preflight/);
  assert.match(trading, /evaluatePublicPreflightGate/);
  assert.match(readFileSync("convex/publicOrderGate.mjs", "utf8"), /settings\?\.liveOrderGateEnabled \|\| input\.settings\.mode !== "OPERATOR_CONFIRM_REQUIRED"/);
  assert.match(readFileSync("convex/publicOrderGate.mjs", "utf8"), /reconciliation\?\.status !== "reconciled"/);
  assert.match(trading, /!liveOrderGateEnabled\(\)/);
  assert.match(readFileSync("convex/camaroBrokerInternal.ts", "utf8"), /!settings\.liveOrderGateEnabled/);
  assert.match(broker, /duplicate active execution intent/i);
  assert.match(broker, /Current Public consent and workspace access are required/);
});

test("intent supports exactly quantity or notional and an expiry-bound hash", () => {
  assert.match(broker, /hasQuantity === hasNotional/);
  assert.match(broker, /timeInForce: "day"/);
  assert.match(broker, /idempotencyKey: intentHash/);
  assert.match(broker, /const orderId = createPublicOrderId\(\)/);
  assert.match(broker, /orderId,/);
  assert.match(schema, /orderId: v\.optional\(v\.string\(\)\)/);
  assert.match(schema, /notional: v\.optional\(v\.number\(\)\)/);
  assert.match(schema, /preflightVerifiedAt/);
});

test("receipt lifecycle distinguishes submit, fill, and cancellation", () => {
  for (const event of ["submission_attempt", "broker_accepted", "broker_rejected", "submission_failed", "status_updated", "fill_recorded", "cancellation_attempt", "cancellation_result"]) assert.match(schema, new RegExp(`v\\.literal\\("${event}"\\)`));
  assert.match(trading, /Submitted is not filled/);
  assert.match(trading, /Public reports the order filled/);
  assert.match(trading, /cancellation request/);
  assert.match(internalBroker, /retryState: "duplicate_blocked"/);
  assert.match(internalBroker, /outboundAttemptResult: "not_sent"/);
});

test("credential and error handling are secret-safe", () => {
  assert.match(trading, /PUBLIC_PERSONAL_SECRET_TOKEN/);
  assert.match(trading, /No raw provider response was stored/);
  assert.doesNotMatch(broker, /PUBLIC_PERSONAL_SECRET_TOKEN/);
  assert.doesNotMatch(trading, /console\.error/);
});

test("manual live ticket is owner-confirmed before broker preflight", () => {
  const panel = readFileSync("src/components/camaro/operator-order-panel.tsx", "utf8");
  assert.match(panel, /useState\("AAPL"\)/);
  assert.match(panel, /createManualLiveExecutionIntent/);
  assert.match(panel, /normalizeCashEquitySymbol\(event\.target\.value\)/);
  assert.match(panel, /symbol: normalizedSymbol/);
  assert.match(panel, /authorityScope: authorityScope\.trim\(\)/);
  assert.match(panel, /maxLength=\{240\}/);
  assert.match(panel, /validateCashEquityIntentForm/);
  assert.match(panel, /Create manual live ticket/);
  assert.match(panel, /Submit live order/);
  assert.doesNotMatch(panel, /approveIntent/);
  assert.match(panel, /Review Public consent/);
});

test("cash equity intent validation retains symbol, amount, limit, and authority checks", () => {
  assert.match(intentValidationSource, /A-Z0-9/);
  assert.match(intentValidationSource, /Enter a valid U.S. equity or ETF symbol/);
  assert.match(intentValidationSource, /greater than zero/);
  assert.match(intentValidationSource, /Describe the bounded authority scope/);
});

test("server revalidates ticker syntax and bounded authority scope", () => {
  assert.match(broker, /A-Z0-9/);
  assert.match(broker, /Enter a valid U.S. equity or ETF symbol/);
  assert.match(broker, /MAX_AUTHORITY_SCOPE_LENGTH/);
  assert.match(broker, /Provide exactly one positive quantity or dollar notional/);
});

test("manual live creation requires owner consent while broker readiness remains at preflight and submit", () => {
  const manualIntent = broker.slice(broker.indexOf("export const createManualLiveExecutionIntent"), broker.indexOf("export const approvePublicExecutionIntent"));
  assert.match(manualIntent, /membership.role !== "owner"/);
  assert.match(manualIntent, /requireCurrentPublicConsent/);
  assert.doesNotMatch(manualIntent, /ACCOUNT_STATE_FRESHNESS_MS|latestReconciliation|latestSnapshot|brokerWriteBlockReason/);
  assert.match(manualIntent, /ownerApprovalStatus: blockers.length \? "pending" : "approved"/);
  assert.match(trading, /evaluatePublicPreflightGate/);
  assert.match(internalBroker, /evaluatePublicOrderGate/);
});

test("intent errors render safe remediation instead of raw Convex details", () => {
  const panel = readFileSync("src/components/camaro/operator-order-panel.tsx", "utf8");
  assert.match(panel, /function actionableError/);
  assert.match(panel, /Review and record the current Public disclosure before broker preflight or submission/);
  assert.match(panel, /The requested control did not complete/);
  assert.doesNotMatch(panel, /description: error instanceof Error \? error\.message/);
});
