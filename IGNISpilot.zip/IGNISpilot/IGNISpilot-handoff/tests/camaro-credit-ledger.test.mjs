import assert from "node:assert/strict";
import test from "node:test";

const MONTHLY_INCLUDED_CREDITS = 100;
const costs = { historical_simulation: 4, extended_replay: 2, resolved_outcome_training: 8, advanced_challenge_pack: 3 };
const packs = { md_credit_100: { id: "camaro_100", credits: 100 }, md_credit_300: { id: "camaro_300", credits: 300 } };

function creditState(initial = 0) {
  const ledger = new Map();
  let balance = initial;
  function debit(action, key) {
    if (ledger.has(key)) return ledger.get(key);
    const required = costs[action];
    const result = balance < required
      ? { state: "insufficient", required, balance, amount: 0 }
      : (balance -= required, { state: "charged", required, balance, amount: -required });
    ledger.set(key, result);
    return result;
  }
  return { debit, get balance() { return balance; }, ledger };
}

function fulfilledOrderState() {
  const orders = new Map();
  const audits = [];
  const balances = new Map();
  function fulfill({ workspaceId, productId, orderId, paymentStatus }) {
    if (paymentStatus === "pending" || paymentStatus === "canceled") {
      audits.push({ type: `credit_checkout_${paymentStatus}`, orderId });
      return { state: paymentStatus, granted: false };
    }
    const existing = orders.get(orderId);
    if (existing) {
      if (existing.workspaceId !== workspaceId) {
        audits.push({ type: "credit_checkout_workspace_denied", orderId });
        return { state: "wrong_workspace", granted: false };
      }
      audits.push({ type: "credit_checkout_duplicate", orderId });
      return { state: "duplicate", granted: false };
    }
    const pack = packs[productId];
    if (!pack) {
      audits.push({ type: "credit_checkout_unknown_pack", orderId });
      return { state: "unknown_pack", granted: false };
    }
    const balance = (balances.get(workspaceId) ?? 0) + pack.credits;
    balances.set(workspaceId, balance);
    orders.set(orderId, { workspaceId, productId, packId: pack.id, credits: pack.credits });
    audits.push({ type: "credit_platform_grant", orderId });
    return { state: "granted", granted: true, balance, receipt: { packId: pack.id, orderId, workspaceId, actorSource: "platform_fulfillment" } };
  }
  return { fulfill, balances, orders, audits };
}

test("each workspace receives 100 included credits per month", () => {
  assert.equal(MONTHLY_INCLUDED_CREDITS, 100);
});

test("double submit returns the original debit without charging twice", () => {
  const state = creditState(8);
  const first = state.debit("historical_simulation", "simulation:one");
  const second = state.debit("historical_simulation", "simulation:one");
  assert.equal(first.state, "charged");
  assert.deepEqual(second, first);
  assert.equal(state.balance, 4);
  assert.equal(state.ledger.size, 1);
});

test("insufficient credits hold only the optional compute action", () => {
  const state = creditState(1);
  const held = state.debit("historical_simulation", "simulation:held");
  assert.equal(held.state, "insufficient");
  assert.equal(held.amount, 0);
  assert.equal(state.balance, 1);
});

test("concurrent distinct debit attempts cannot create a negative balance", async () => {
  const state = creditState(4);
  const results = await Promise.all(["a", "b", "c"].map((key) => Promise.resolve().then(() => state.debit("historical_simulation", key))));
  assert.equal(results.filter((result) => result.state === "charged").length, 1);
  assert.equal(state.balance, 0);
  assert.ok(state.balance >= 0);
});

test("paid platform orders grant the configured pack and immutable receipt once", () => {
  const state = fulfilledOrderState();
  const first = state.fulfill({ workspaceId: "workspace-a", productId: "md_credit_100", orderId: "order-1001", paymentStatus: "paid" });
  const duplicate = state.fulfill({ workspaceId: "workspace-a", productId: "md_credit_100", orderId: "order-1001", paymentStatus: "paid" });
  assert.equal(first.state, "granted");
  assert.equal(first.balance, 100);
  assert.deepEqual(first.receipt, { packId: "camaro_100", orderId: "order-1001", workspaceId: "workspace-a", actorSource: "platform_fulfillment" });
  assert.equal(duplicate.state, "duplicate");
  assert.equal(state.balances.get("workspace-a"), 100);
  assert.equal(state.orders.size, 1);
});

test("orders never grant for canceled or pending checkout", () => {
  const state = fulfilledOrderState();
  assert.equal(state.fulfill({ workspaceId: "workspace-a", productId: "md_credit_300", orderId: "order-pending", paymentStatus: "pending" }).granted, false);
  assert.equal(state.fulfill({ workspaceId: "workspace-a", productId: "md_credit_300", orderId: "order-canceled", paymentStatus: "canceled" }).granted, false);
  assert.equal(state.balances.get("workspace-a"), undefined);
});

test("a paid order is denied when replayed for another workspace", () => {
  const state = fulfilledOrderState();
  state.fulfill({ workspaceId: "workspace-a", productId: "md_credit_300", orderId: "order-cross", paymentStatus: "completed" });
  const denied = state.fulfill({ workspaceId: "workspace-b", productId: "md_credit_300", orderId: "order-cross", paymentStatus: "completed" });
  assert.equal(denied.state, "wrong_workspace");
  assert.equal(state.balances.get("workspace-a"), 300);
  assert.equal(state.balances.get("workspace-b"), undefined);
});

test("a failed downstream action uses a compensating receipt instead of editing a debit", () => {
  const state = creditState(4);
  const debit = state.debit("historical_simulation", "simulation:failure");
  assert.equal(debit.amount, -4);
  const compensation = { entryType: "refund", amount: 4, reference: "simulation:failure" };
  assert.equal(compensation.entryType, "refund");
  assert.equal(compensation.amount + debit.amount, 0);
});

test("zero-credit safety, authority, and broker paths have no debit requirement", () => {
  const includedPaths = ["risk_check", "authority_gate", "broker_reconciliation", "audit_receipt", "position_visibility", "unsafe_intent_block"];
  const state = creditState(0);
  for (const path of includedPaths) assert.equal(costs[path], undefined, `${path} must not be credit-gated`);
  assert.equal(state.balance, 0);
});
