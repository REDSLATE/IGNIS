import assert from "node:assert/strict";
import test from "node:test";
import { readFileSync } from "node:fs";

const modes = ["READ_ONLY", "PAPER", "OPERATOR_CONFIRM_REQUIRED", "LIVE_DISABLED_PENDING_ENABLEMENT"];

function writeBlock(mode) {
  if (mode === "READ_ONLY") return "Broker writes are unavailable in READ_ONLY mode.";
  if (mode === "PAPER") return "Broker writes are unavailable in PAPER mode.";
  if (mode === "LIVE_DISABLED_PENDING_ENABLEMENT") return "Live broker writes are disabled pending explicit enablement.";
  return "Live broker writes remain disabled by the global live-order gate.";
}

test("execution authority requires an explicit operator-selected mode", () => {
  const source = readFileSync("convex/camaroBroker.ts", "utf8");
  assert.match(source, /camaroExecutionSettings/);
  assert.match(source, /Operator explicitly selected \$\{args\.mode\}/);
  assert.deepEqual(modes, ["READ_ONLY", "PAPER", "OPERATOR_CONFIRM_REQUIRED", "LIVE_DISABLED_PENDING_ENABLEMENT"]);
});

test("all non-live paths hard-block broker writes", () => {
  assert.match(writeBlock("READ_ONLY"), /unavailable/);
  assert.match(writeBlock("PAPER"), /unavailable/);
  assert.match(writeBlock("LIVE_DISABLED_PENDING_ENABLEMENT"), /disabled/);
  const connector = readFileSync("convex/publicConnector.ts", "utf8");
  assert.doesNotMatch(connector, /\/orders|submitOrder|placeOrder|method:\s*["']POST["'][\s\S]{0,300}order/i);
});

test("immutable intent review is available before broker readiness, never an order", () => {
  const source = readFileSync("convex/camaroBroker.ts", "utf8");
  const schema = readFileSync("convex/schema.ts", "utf8");
  assert.match(source, /createPublicExecutionIntent/);
  assert.match(source, /No broker order was submitted/);
  const createIntent = source.slice(source.indexOf("export const createPublicExecutionIntent"), source.indexOf("export const approvePublicExecutionIntent"));
  assert.doesNotMatch(createIntent, /A fresh verified Public account state is required/);
  assert.doesNotMatch(createIntent, /A successful Public reconciliation is required/);
  assert.match(source, /Broker readiness is checked only at documented preflight/);
  assert.match(source, /duplicate active execution intent/i);
  assert.match(schema, /camaroExecutionIntents: defineTable/);
  assert.match(schema, /camaroExecutionReceipts: defineTable/);
});

test("final confirmation is bound to immutable intent scope and revalidates server gates", () => {
  const source = readFileSync("convex/camaroBroker.ts", "utf8");
  assert.match(source, /confirmPublicExecutionIntent/);
  assert.match(source, /intent\.authorityScope !== args\.authorityScope\.trim\(\)/);
  assert.match(source, /intent\.authorityScope !== args\.authorityScope\.trim\(\)/);
  assert.match(source, /internal\.publicTrading\.submit/);
  const execution = readFileSync("convex/camaroExecution.ts", "utf8");
  assert.match(execution, /PUBLIC_LIVE_ORDER_GATE_ENABLED/);
});
