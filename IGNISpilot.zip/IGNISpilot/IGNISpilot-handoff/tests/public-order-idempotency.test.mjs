import assert from "node:assert/strict";
import test from "node:test";
import {
  assertPublicOrderId,
  createPublicOrderId,
  createPublicOrderPayload,
  sendPublicJsonRequest,
} from "../convex/publicOrderId.mjs";

const firstOrderId = "a0b1c2d3-e4f5-4a67-8b9c-0d1e2f3a4b5c";
const secondOrderId = "b1c2d3e4-f5a6-4b78-8c9d-1e2f3a4b5c6d";
const intent = {
  orderId: firstOrderId,
  symbol: "AAPL",
  side: "buy",
  quantity: 2,
  orderType: "market",
};

function createAtomicClaimStore() {
  let state = "awaiting_confirmation";
  const receipts = [];
  return {
    claim(orderId) {
      assertPublicOrderId(orderId);
      if (state !== "awaiting_confirmation") {
        receipts.push({ orderId, retryState: "duplicate_blocked", outboundAttemptResult: "not_sent" });
        return { state: "duplicate" };
      }
      state = "submitting";
      receipts.push({ orderId, retryState: "initial", outboundAttemptResult: "started" });
      return { state: "claimed" };
    },
    receipts,
  };
}

test("Public order request body includes the documented UUID orderId", async () => {
  const calls = [];
  const fetchMock = async (url, options) => {
    calls.push({ url, options });
    return { ok: true };
  };
  const payload = createPublicOrderPayload(intent);
  await sendPublicJsonRequest(fetchMock, "https://api.public.com/userapigateway/trading/account/order", "POST", "test-token", payload);

  assert.equal(calls.length, 1);
  assert.equal(JSON.parse(calls[0].options.body).orderId, firstOrderId);
  assert.equal(calls[0].options.method, "POST");
  assert.deepEqual(calls[0].options.headers, { Authorization: "Bearer test-token", Accept: "application/json", "Content-Type": "application/json" });
});

test("the same immutable intent preserves its Public orderId across retries", () => {
  assert.equal(createPublicOrderPayload(intent).orderId, createPublicOrderPayload({ ...intent }).orderId);
});

test("distinct intents receive distinct canonical UUID v4 orderIds", () => {
  assert.equal(createPublicOrderId(() => firstOrderId), firstOrderId);
  assert.equal(createPublicOrderId(() => secondOrderId), secondOrderId);
  assert.notEqual(createPublicOrderId(() => firstOrderId), createPublicOrderId(() => secondOrderId));
});

test("malformed or non-v4 Public orderIds are rejected without replacement", () => {
  for (const invalidOrderId of ["not-a-uuid", "a0b1c2d3-e4f5-1a67-8b9c-0d1e2f3a4b5c", "a0b1c2d3-e4f5-4a67-7b9c-0d1e2f3a4b5c"]) {
    assert.throws(() => createPublicOrderPayload({ ...intent, orderId: invalidOrderId }), /canonical UUID v4/);
  }
});

test("atomic submission claim lets one concurrent caller submit and blocks duplicates", async () => {
  const store = createAtomicClaimStore();
  const outcomes = await Promise.all(Array.from({ length: 8 }, () => Promise.resolve().then(() => store.claim(firstOrderId))));
  assert.equal(outcomes.filter((outcome) => outcome.state === "claimed").length, 1);
  assert.equal(outcomes.filter((outcome) => outcome.state === "duplicate").length, 7);
  assert.deepEqual(store.receipts[0], { orderId: firstOrderId, retryState: "initial", outboundAttemptResult: "started" });
  assert.ok(store.receipts.slice(1).every((receipt) => receipt.retryState === "duplicate_blocked" && receipt.outboundAttemptResult === "not_sent"));
});
