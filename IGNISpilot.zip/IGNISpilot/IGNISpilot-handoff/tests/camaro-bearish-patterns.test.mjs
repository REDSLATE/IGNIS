import assert from "node:assert/strict";
import test from "node:test";
import { readFileSync } from "node:fs";

const detector = readFileSync("convex/camaroBearishPatterns.js", "utf8");
const engine = readFileSync("convex/camaroOpportunityEngine.ts", "utf8");
const schema = readFileSync("convex/schema.ts", "utf8");
const boundary = readFileSync("convex/camaroOpportunity.ts", "utf8");
const board = readFileSync("src/components/camaro/opportunity-command-board.tsx", "utf8");
const voice = readFileSync("src/components/camaro/voice-command-panel.tsx", "utf8");

test("bearish research implements transparent Double Top, Head & Shoulders, and Rising Wedge criteria", () => {
  assert.match(detector, /assessDoubleTop/);
  assert.match(detector, /assessHeadAndShoulders/);
  assert.match(detector, /assessRisingWedge/);
  assert.match(detector, /Comparable peaks/);
  assert.match(detector, /Head dominance/);
  assert.match(detector, /Convergence/);
  assert.match(detector, /Neckline break/);
  assert.match(detector, /Support break/);
  assert.match(detector, /Invalidation/);
});

test("ambiguous or malformed pattern input is blocked rather than inferred", () => {
  assert.match(detector, /At least five ordered bars/);
  assert.match(detector, /At least seven ordered bars/);
  assert.match(detector, /At least six ordered bars/);
  assert.match(detector, /Malformed OHLC research input was blocked/);
  assert.match(detector, /state: "blocked"/);
});

test("pattern research stores confidence freshness detection invalidation and block receipts", () => {
  assert.match(schema, /camaroPatternResearch/);
  assert.match(schema, /confidence: v\.number\(\)/);
  assert.match(schema, /freshness: v\.union/);
  assert.match(engine, /bearish_pattern_detected/);
  assert.match(engine, /bearish_pattern_invalidated/);
  assert.match(engine, /bearish_pattern_blocked/);
  assert.match(boundary, /bearishPatterns/);
});

test("pattern results remain read-only and cannot invoke execution paths", () => {
  assert.match(engine, /No execution intent, broker call, authority change, or live-order action was created/);
  assert.match(board, /Research only · no execution path/);
  assert.match(board, /Structure, confirmation, and invalidation/);
  assert.match(voice, /deterministic bearish-pattern research context/);
  assert.doesNotMatch(detector, /createPublicExecutionIntent|confirmPublicExecutionIntent|broker.*submit|submit.*broker/i);
  assert.doesNotMatch(engine, /createPublicExecutionIntent|confirmPublicExecutionIntent|submit.*broker/i);
});

const bar = (timestamp, high, low, close) => ({ timestamp, high, low, close });

test("detector confirms a Double Top only after a neckline close", async () => {
  const { assessBearishPatterns: assess } = await import("../convex/camaroBearishPatterns.js");
  const result = assess([
    bar(1, 100, 96, 98), bar(2, 95, 90, 92), bar(3, 101, 96, 99), bar(4, 97, 93, 94), bar(5, 94, 88, 89),
  ], 5).find((pattern) => pattern.pattern === "double_top");
  assert.equal(result.state, "confirmed");
  assert.equal(result.criteria.find((criterion) => criterion.label === "Neckline break").met, true);
});

test("detector invalidates a Head & Shoulders above its head buffer", async () => {
  const { assessBearishPatterns: assess } = await import("../convex/camaroBearishPatterns.js");
  const result = assess([
    bar(1, 100, 96, 98), bar(2, 97, 90, 93), bar(3, 110, 98, 106), bar(4, 98, 91, 94), bar(5, 101, 96, 99), bar(6, 100, 95, 98), bar(7, 113, 106, 112),
  ], 7).find((pattern) => pattern.pattern === "head_and_shoulders");
  assert.equal(result.state, "invalidated");
  assert.equal(result.criteria.find((criterion) => criterion.label === "Invalidation").met, true);
});

test("detector blocks an ambiguous Rising Wedge instead of confirming it", async () => {
  const { assessBearishPatterns: assess } = await import("../convex/camaroBearishPatterns.js");
  const result = assess([
    bar(1, 100, 90, 95), bar(2, 101, 89, 96), bar(3, 100, 88, 94), bar(4, 102, 87, 95), bar(5, 101, 86, 94), bar(6, 103, 85, 92),
  ], 6).find((pattern) => pattern.pattern === "rising_wedge");
  assert.equal(result.state, "blocked");
  assert.equal(result.criteria.find((criterion) => criterion.label === "Convergence").met, false);
});
