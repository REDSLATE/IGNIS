import Link from "next/link";
import {
  ArrowRight,
  BadgeCheck,
  Bot,
  Brackets,
  CandlestickChart,
  CheckCircle2,
  CircleDot,
  ClipboardCheck,
  GitCompareArrows,
  LockKeyhole,
  Radar,
  ReceiptText,
  RefreshCw,
  Scale,
  ShieldCheck,
  Waypoints,
} from "lucide-react";
import { SiteFooter } from "@/components/site-footer";
import { SiteHeader } from "@/components/site-header";
import { Button } from "@/components/ui/button";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const rules = [
  ["01", "Authority", "No role implies execution authority."],
  ["02", "Risk", "Exposure, PDT, and duplicate checks require verified data."],
  ["03", "Broker", "Read-only reconciliation must be connected before it can inform decisions."],
  ["04", "Receipt", "Every decision, block, and override is replayable."],
];

const faqs = [
  {
    question: "Does Camaro place orders by itself?",
    answer:
      "No. Camaro creates decision-support intents and audit receipts. This release does not place orders, expose a live-order control, or connect a broker execution path.",
  },
  {
    question: "What happens when peer runtimes disagree?",
    answer:
      "Camaro can publish an independent stance and formally challenge a peer. The evidence, counter-stance, decision, and resolution remain available in the audit trail.",
  },
  {
    question: "Can the runtime operate before a broker is connected?",
    answer:
      "Yes. Teams can manage a watchlist and record decision-support intents with stated unavailable or blocked conditions. Camaro now includes a broker-agnostic provider catalog and a manual-import setup path; direct read-only support is added adapter by adapter where a broker or exchange permits it. Market and broker data are only shown after separately configured server-side adapters are implemented.",
  },
];

function StatusDot({ className = "" }: { className?: string }) {
  return <span className={`inline-block h-2 w-2 rounded-full bg-signal ${className}`} />;
}

export default function HomePage() {
  return (
    <div className="flex min-h-screen flex-col bg-background text-foreground">
      <SiteHeader productName="IGNISpilot" logoUrl={process.env.NEXT_PUBLIC_BRAND_LOGO} />

      <main className="flex-1 overflow-hidden">
        <section className="brand-grid relative border-b border-border">
          <div className="mx-auto grid max-w-7xl gap-12 px-4 py-16 sm:px-6 sm:py-24 lg:grid-cols-[0.9fr_1.1fr] lg:px-8 lg:py-28">
            <div className="relative z-10 max-w-3xl">
              <div className="flex items-center gap-3 font-mono-system text-[11px] font-medium uppercase tracking-[0.22em] text-primary">
                <span className="flex items-center gap-2"><StatusDot /> Cockpit in progress</span>
                <span className="h-px w-8 bg-border" />
                <span>RISEDUAL / Camaro</span>
              </div>
              <h1 className="mt-6 font-[family-name:var(--font-heading)] text-4xl font-bold leading-[0.96] tracking-[-0.055em] sm:text-6xl lg:text-7xl">
                Peer minds.<br />
                Policy gates.<br />
                <span className="text-primary">Reality aligned.</span>
              </h1>
              <p className="mt-7 max-w-xl text-base leading-7 text-muted-foreground sm:text-lg">
                IGNISpilot is building Camaro as a connected, approval-only cockpit for watchlists, governed decision intents, broker-agnostic read-only reconciliation, and audit receipts—without autonomous trading or performance claims.
              </p>
              <div className="mt-9 flex flex-col gap-3 sm:flex-row">
                <Button asChild size="lg" className="rounded-sm px-6 font-semibold">
                  <Link href="/sign-up">Open Camaro workspace <ArrowRight className="h-4 w-4" /></Link>
                </Button>
                <Button asChild size="lg" variant="outline" className="rounded-sm border-border bg-background/70 px-6">
                  <Link href="#console">Inspect the console</Link>
                </Button>
              </div>
              <p className="mt-5 font-mono-system text-xs uppercase tracking-[0.12em] text-muted-foreground">
                Intent + approval launch scope. No autonomous brokerage execution.
              </p>
            </div>

            <div id="console" className="panel-surface relative overflow-hidden border border-border p-3 shadow-2xl sm:p-5">
              <div className="absolute inset-0 brand-grid opacity-40" />
              <div className="relative border border-border bg-background/85 p-4 sm:p-5">
                <div className="flex items-center justify-between border-b border-border pb-4">
                  <div className="flex items-center gap-3">
                    <div className="flex h-8 w-8 items-center justify-center border border-primary text-primary"><ShieldCheck className="h-4 w-4" /></div>
                    <div><p className="text-sm font-semibold">Camaro Runtime Health</p><p className="font-mono-system text-[10px] uppercase tracking-wider text-muted-foreground">authority console</p></div>
                  </div>
                  <span className="flex items-center gap-2 border border-signal px-2 py-1 font-mono-system text-[10px] uppercase text-signal"><StatusDot /> healthy</span>
                </div>

                <div className="grid grid-cols-2 divide-x divide-border border-b border-border sm:grid-cols-4">
                  {[["Authority", "OPERATOR"], ["Peers", "6 / 6 ONLINE"], ["Latency", "18ms"], ["Mode", "INTENT"]].map(([label, value]) => (
                    <div key={label} className="py-4 pr-3 text-left first:pr-3 sm:px-3 sm:first:pl-0">
                      <p className="font-mono-system text-[9px] uppercase tracking-wider text-muted-foreground">{label}</p>
                      <p className="mt-1 text-xs font-semibold text-signal">{value}</p>
                    </div>
                  ))}
                </div>

                <div className="grid gap-3 pt-4 sm:grid-cols-[1.4fr_0.8fr]">
                  <div className="border border-border bg-card p-4">
                    <div className="flex items-center justify-between"><p className="font-mono-system text-[10px] uppercase tracking-wider text-muted-foreground">Execution readiness</p><p className="text-sm font-semibold">98%</p></div>
                    <div className="mt-6 flex h-20 items-end gap-1">
                      {[20, 32, 26, 44, 38, 55, 49, 60, 57, 75, 68, 86].map((height, index) => <span key={index} className="flex-1 bg-signal/70" style={{ height: `${height}%` }} />)}
                    </div>
                  </div>
                  <div className="border border-border bg-card p-4">
                    <p className="font-mono-system text-[10px] uppercase tracking-wider text-muted-foreground">Risk exposure</p>
                    <div className="mt-5 flex items-center gap-3"><div className="flex h-14 w-14 items-center justify-center rounded-full border-4 border-signal border-l-border border-b-border font-mono-system text-xs">32%</div><p className="text-xs text-muted-foreground">of policy<br />limit</p></div>
                  </div>
                </div>
                <div className="mt-3 flex flex-wrap gap-2 border-t border-border pt-3 font-mono-system text-[10px] uppercase tracking-wider text-muted-foreground">
                  <span className="flex items-center gap-1"><CircleDot className="h-3 w-3 text-primary" /> approval-only</span><span>·</span><span>broker unconnected</span><span>·</span><span>receipt available</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section id="runtime" className="border-b border-border px-4 py-16 sm:px-6 sm:py-24 lg:px-8">
          <div className="mx-auto max-w-7xl">
            <div className="grid gap-8 lg:grid-cols-[0.7fr_1.3fr] lg:items-end">
              <div><p className="font-mono-system text-xs uppercase tracking-[0.2em] text-primary">// tactical runtime</p><h2 className="mt-4 font-[family-name:var(--font-heading)] text-3xl font-bold leading-none tracking-[-0.04em] sm:text-5xl">Think independently.<br />Act through gates.</h2></div>
              <p className="max-w-2xl text-base leading-7 text-muted-foreground">Camaro is RISEDUAL&apos;s tactical decision-support runtime—not an unchecked executor. It records an operational thesis, exposes missing and blocked controls, and preserves a receipt for human review.</p>
            </div>

            <div className="mt-12 grid gap-px border border-border bg-border lg:grid-cols-[1.25fr_0.75fr]">
              <article className="bg-background p-6 sm:p-8">
                <div className="flex items-center justify-between"><div className="flex h-10 w-10 items-center justify-center border border-primary text-primary"><Waypoints className="h-5 w-5" /></div><span className="font-mono-system text-xs text-primary">01 / DECIDE</span></div>
                <h3 className="mt-12 max-w-lg font-[family-name:var(--font-heading)] text-3xl font-semibold tracking-[-0.04em]">Stance, challenge, and decision live on one shared bus.</h3>
                <p className="mt-5 max-w-lg leading-7 text-muted-foreground">Publish a tactical stance. Bring in peer evidence. Challenge the call when Camaro sees a different path. The decision remains attributable, inspectable, and ready for replay.</p>
                <div className="mt-8 grid gap-3 sm:grid-cols-3">
                  {[['WATCHLIST', 'EQUITY + CRYPTO'], ['DATA', 'NOT CONFIGURED'], ['AUTHORITY', 'APPROVAL ONLY']].map(([label, value]) => <div key={label} className="border border-border bg-card p-3"><p className="font-mono-system text-[9px] uppercase tracking-wider text-muted-foreground">{label}</p><p className="mt-2 text-xs font-semibold">{value}</p></div>)}
                </div>
              </article>
              <div className="grid gap-px bg-border sm:grid-cols-2 lg:grid-cols-1">
                <article className="bg-card p-6"><Radar className="h-5 w-5 text-primary" /><p className="mt-8 font-mono-system text-xs text-primary">02 / GOVERN</p><h3 className="mt-3 text-xl font-semibold">Authority is visible.</h3><p className="mt-3 text-sm leading-6 text-muted-foreground">Seats, data availability, exposure placeholders, and policy blocks are never implied by role identity.</p></article>
                <article className="bg-card p-6"><LockKeyhole className="h-5 w-5 text-signal" /><p className="mt-8 font-mono-system text-xs text-signal">03 / INTENT</p><h3 className="mt-3 text-xl font-semibold">Approval stays human.</h3><p className="mt-3 text-sm leading-6 text-muted-foreground">Camaro records a decision-support intent. Order routing is not available in this cockpit.</p></article>
              </div>
            </div>
          </div>
        </section>

        <section className="brand-grid border-b border-border px-4 py-16 sm:px-6 sm:py-24 lg:px-8">
          <div className="mx-auto max-w-7xl">
            <div className="flex flex-col justify-between gap-7 md:flex-row md:items-end"><div><p className="font-mono-system text-xs uppercase tracking-[0.2em] text-primary">// policy path</p><h2 className="mt-4 font-[family-name:var(--font-heading)] text-3xl font-bold leading-none tracking-[-0.04em] sm:text-5xl">No hidden handoffs.</h2></div><p className="max-w-md text-sm leading-6 text-muted-foreground">A tactical decision only advances when the operating controls agree with it.</p></div>
            <div className="mt-12 grid border-l border-t border-border sm:grid-cols-2 lg:grid-cols-4">
              {rules.map(([number, title, detail]) => <article key={number} className="min-h-52 border-b border-r border-border bg-background/90 p-6"><p className="font-mono-system text-xs text-primary">{number}</p><h3 className="mt-10 text-xl font-semibold">{title}</h3><p className="mt-3 text-sm leading-6 text-muted-foreground">{detail}</p></article>)}
            </div>
          </div>
        </section>

        <section className="border-b border-border px-4 py-16 sm:px-6 sm:py-24 lg:px-8">
          <div className="mx-auto grid max-w-7xl gap-12 lg:grid-cols-2 lg:items-center">
            <div className="panel-surface border border-border p-3 sm:p-5"><div className="border border-border bg-background p-5 sm:p-7"><div className="flex items-center justify-between"><p className="font-mono-system text-[11px] uppercase tracking-wider text-primary">audit / receipt ledger</p><ReceiptText className="h-5 w-5 text-primary" /></div><div className="mt-8 space-y-0 border border-border"><div className="grid grid-cols-[auto_1fr_auto] items-center gap-3 border-b border-border p-3 font-mono-system text-[10px]"><ClipboardCheck className="h-4 w-4 text-primary" /><span>WATCHLIST / USER EDITABLE</span><span className="text-muted-foreground">READY</span></div><div className="grid grid-cols-[auto_1fr_auto] items-center gap-3 border-b border-border p-3 font-mono-system text-[10px]"><ShieldCheck className="h-4 w-4 text-alert" /><span>DATA ADAPTER / UNAVAILABLE</span><span className="text-muted-foreground">NO QUOTE</span></div><div className="grid grid-cols-[auto_1fr_auto] items-center gap-3 border-b border-border p-3 font-mono-system text-[10px]"><LockKeyhole className="h-4 w-4 text-primary" /><span>INTENT / HUMAN REVIEW</span><span className="text-muted-foreground">RECEIPT</span></div><div className="grid grid-cols-[auto_1fr_auto] items-center gap-3 p-3 font-mono-system text-[10px]"><GitCompareArrows className="h-4 w-4 text-muted-foreground" /><span>BROKER READ-ONLY / NOT CONNECTED</span><span className="text-muted-foreground">—</span></div></div></div></div>
            <div><p className="font-mono-system text-xs uppercase tracking-[0.2em] text-primary">// broker reality</p><h2 className="mt-4 font-[family-name:var(--font-heading)] text-3xl font-bold leading-none tracking-[-0.04em] sm:text-5xl">Lifecycle control that remembers what actually happened.</h2><p className="mt-6 max-w-xl leading-7 text-muted-foreground">Positions, exits, stale tickers, stops, fills, and broker events are compared to runtime intent—then preserved as receipts you can replay, train from, or challenge.</p><div className="mt-8 space-y-4"><div className="flex gap-4"><RefreshCw className="mt-1 h-5 w-5 shrink-0 text-primary" /><div><h3 className="font-semibold">Reconcile before you assume</h3><p className="mt-1 text-sm leading-6 text-muted-foreground">Compare intended state with account, orders, fills, and positions.</p></div></div><div className="flex gap-4"><CandlestickChart className="mt-1 h-5 w-5 shrink-0 text-signal" /><div><h3 className="font-semibold">Manage the whole position</h3><p className="mt-1 text-sm leading-6 text-muted-foreground">Hold, exit, release, or escalate using a recorded lifecycle decision.</p></div></div><div className="flex gap-4"><Brackets className="mt-1 h-5 w-5 shrink-0 text-primary" /><div><h3 className="font-semibold">Simulate and replay</h3><p className="mt-1 text-sm leading-6 text-muted-foreground">Review resolved trades, blocks, regret cases, and peer disagreement outcomes.</p></div></div></div></div>
          </div>
        </section>

        <section className="px-4 py-16 sm:px-6 sm:py-24 lg:px-8">
          <div className="mx-auto grid max-w-7xl gap-12 lg:grid-cols-[0.8fr_1.2fr]">
            <div><p className="font-mono-system text-xs uppercase tracking-[0.2em] text-primary">// operating doctrine</p><h2 className="mt-4 font-[family-name:var(--font-heading)] text-3xl font-bold leading-none tracking-[-0.04em] sm:text-5xl">Control before any future execution.</h2><p className="mt-6 max-w-md leading-7 text-muted-foreground">Built for tactical teams that want a stronger decision loop—not investment advice, a promise of market performance, or autonomous trading.</p><Button asChild size="lg" className="mt-8 rounded-sm"><Link href="/sign-up">Open cockpit <ArrowRight className="h-4 w-4" /></Link></Button></div>
            <Accordion type="single" collapsible className="w-full border-t border-border">{faqs.map((item, index) => <AccordionItem key={item.question} value={`item-${index}`}><AccordionTrigger className="text-left font-semibold">{item.question}</AccordionTrigger><AccordionContent className="max-w-2xl leading-7 text-muted-foreground">{item.answer}</AccordionContent></AccordionItem>)}</Accordion>
          </div>
        </section>
      </main>

      <SiteFooter productName="IGNISpilot" footerText="Camaro records governed decisions and clear blockers for human review." />
    </div>
  );
}
