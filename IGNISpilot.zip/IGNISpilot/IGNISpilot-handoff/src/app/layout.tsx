import type { Metadata } from "next";
import { IBM_Plex_Mono, Sora } from "next/font/google";
import { ConvexAuthNextjsServerProvider } from "@convex-dev/auth/nextjs/server";
import { Providers } from "@/lib/convex";
import { PostHogProvider } from "@/lib/posthog";
import { Toaster } from "@/components/ui/toaster";
import "./globals.css";

const sora = Sora({ subsets: ["latin"], variable: "--font-sora" });
const plexMono = IBM_Plex_Mono({ subsets: ["latin"], weight: ["400", "500", "600"], variable: "--font-plex-mono" });

export const metadata: Metadata = {
  title: "IGNISpilot | Tactical Trading Runtime",
  description: "Camaro is RISEDUAL's policy-gated tactical runtime for execution intent, broker reconciliation, and replayable audit receipts.",
  icons: {
    icon: [
      { url: process.env.NEXT_PUBLIC_BRAND_LOGO_LIGHT_MODE ?? "/brand/ignispilot-icon-light.png", media: "(prefers-color-scheme: light)" },
      { url: process.env.NEXT_PUBLIC_BRAND_LOGO_DARK_MODE ?? process.env.NEXT_PUBLIC_BRAND_LOGO ?? "/brand/ignispilot-icon-dark.png", media: "(prefers-color-scheme: dark)" },
    ],
    apple: "/brand/icon-192.png",
  },
};
const GSC_VERIFICATION_TOKEN = process.env.NEXT_PUBLIC_GSC_VERIFICATION_TOKEN;

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <ConvexAuthNextjsServerProvider><html lang="en"><head>{GSC_VERIFICATION_TOKEN && <meta name="google-site-verification" content={GSC_VERIFICATION_TOKEN} />}</head><body className={`${sora.variable} ${plexMono.variable} font-sans antialiased`}><PostHogProvider><Providers>{children}<Toaster /></Providers></PostHogProvider></body></html></ConvexAuthNextjsServerProvider>;
}
