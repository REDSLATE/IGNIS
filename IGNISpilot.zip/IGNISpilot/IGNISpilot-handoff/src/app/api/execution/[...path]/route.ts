import { NextRequest, NextResponse } from "next/server";

async function proxy(request: NextRequest, context: { params: Promise<{ path: string[] }> }) {
  const baseUrl = process.env.EXECUTION_SERVICE_URL;
  const token = process.env.EXECUTION_SERVICE_TOKEN;
  if (!baseUrl || !token) return NextResponse.json({ detail: "Execution service is not configured" }, { status: 503 });
  const { path } = await context.params;
  const target = new URL(path.join("/"), `${baseUrl.replace(/\/$/, "")}/`);
  request.nextUrl.searchParams.forEach((value, key) => target.searchParams.append(key, value));
  const body = ["GET", "HEAD"].includes(request.method) ? undefined : await request.text();
  const response = await fetch(target, {
    method: request.method,
    headers: { "Content-Type": request.headers.get("content-type") ?? "application/json", "X-Execution-Token": token },
    body: body || undefined,
    cache: "no-store",
  });
  return new NextResponse(response.body, { status: response.status, headers: { "Content-Type": response.headers.get("content-type") ?? "application/json" } });
}

export const GET = proxy;
export const POST = proxy;
export const DELETE = proxy;
