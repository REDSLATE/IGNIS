"use client";

import { useQuery } from "convex/react";
import { api } from "@convex/_generated/api";
import posthog from "posthog-js";
import { decorateCheckoutUrl } from "@/lib/posthog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowUpRight, Check, CircleCheck, Clock3, CreditCard, Gauge, ShieldCheck } from "lucide-react";
import Link from "next/link";

const BUSINESS_ID = process.env.NEXT_PUBLIC_BUSINESS_ID;

const plans = [
  { name: "Free", price: "$0", features: ["1 workspace", "Up to 3 team members", "Basic analytics"] },
  { name: "Pro", price: "$29/mo", features: ["Unlimited workspaces", "Up to 20 team members", "Advanced analytics", "Priority support", "Custom branding"] },
  { name: "Enterprise", price: "$99/mo", features: ["Everything in Pro", "Unlimited team members", "SSO & SAML", "Dedicated support", "SLA guarantee"] },
];

function checkoutUrl(url: string, workspaceId: string) {
  const parsed = new URL(decorateCheckoutUrl(url), window.location.origin);
  parsed.searchParams.set("workspaceId", workspaceId);
  parsed.searchParams.set("success_url", `${window.location.origin}/app/settings/billing/checkout?status=success`);
  parsed.searchParams.set("cancel_url", `${window.location.origin}/app/settings/billing/checkout?status=cancel`);
  return parsed.toString();
}

export default function BillingPage() {
  const workspaces = useQuery(api.workspaces.listForUser);
  const workspace = workspaces?.[0];
  const credits = useQuery(api.camaroCredits.getOverview, workspace ? { workspaceId: workspace._id } : "skip");
  const creditOverview = credits ?? undefined;

  if (workspaces === undefined) {
    return <div className="space-y-6"><div><h1 className="font-[family-name:var(--font-heading)] text-2xl font-semibold tracking-[-0.04em]">Billing / Credits</h1><p className="font-mono-system text-[10px] uppercase tracking-[0.14em] text-primary">Camaro operating allowance</p></div><Skeleton className="h-64" /></div>;
  }

  if (!workspace) {
    return <div className="space-y-6"><div><h1 className="text-2xl font-bold tracking-tight">Billing</h1><p className="text-sm text-muted-foreground">Create a workspace first to manage billing.</p></div><Button asChild><Link href="/app/settings">Create Workspace</Link></Button></div>;
  }

  const currentPlan = workspace.plan;
  const trialEnd = workspace.trialEndsAt ? new Date(workspace.trialEndsAt) : null;
  const isTrialing = workspace.subscriptionStatus === "trialing";
  const daysLeft = trialEnd && isTrialing ? Math.max(0, Math.ceil((trialEnd.getTime() - Date.now()) / (1000 * 60 * 60 * 24))) : 0;

  return (
    <div className="mx-auto max-w-6xl space-y-8 pb-8">
      <div className="brand-grid border border-border bg-card/65 p-5 sm:p-7">
        <p className="font-mono-system text-[10px] uppercase tracking-[0.18em] text-primary">Camaro / credits</p>
        <div className="mt-3 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div><h1 className="font-[family-name:var(--font-heading)] text-3xl font-semibold tracking-[-0.05em]">Operating allowance.</h1><p className="mt-2 max-w-2xl text-sm leading-6 text-muted-foreground">Credits cover optional Camaro compute. They never gate the controls that protect people, positions, authority, or broker truth.</p></div>
          <Link href="/app/settings/billing/checkout" className="font-mono-system text-[10px] uppercase tracking-[0.13em] text-primary hover:text-foreground">Checkout status <ArrowUpRight className="inline h-3.5 w-3.5" /></Link>
        </div>
      </div>

      <section className="grid gap-4 lg:grid-cols-[0.9fr_1.1fr]">
        <Card className="panel-surface border-primary/45"><CardHeader><CardTitle className="flex items-center gap-2 font-[family-name:var(--font-heading)]"><Gauge className="h-5 w-5 text-primary" />Camaro balance</CardTitle><CardDescription>Per workspace, refreshed monthly.</CardDescription></CardHeader><CardContent>
          {creditOverview === undefined ? <Skeleton className="h-24" /> : <><div className="flex items-end gap-3"><p className="font-mono-system text-5xl font-semibold tracking-[-0.08em] text-primary">{creditOverview.availableCredits}</p><p className="mb-1 text-sm text-muted-foreground">credits available</p></div><p className="mt-4 border-t border-border pt-4 text-sm leading-6 text-muted-foreground"><span className="font-medium text-foreground">{creditOverview.monthlyIncludedCredits} included credits</span> are granted each UTC month. {creditOverview.pendingIncludedGrant ? "Your next allowance is reserved and posts with your next optional-compute request." : "This month’s allowance is already posted."}</p></>}
        </CardContent></Card>
        <Card className="border-border bg-card"><CardHeader><CardTitle className="flex items-center gap-2"><ShieldCheck className="h-5 w-5 text-signal" />Always available</CardTitle><CardDescription>Zero credits never disables essential operating controls.</CardDescription></CardHeader><CardContent className="grid gap-2 sm:grid-cols-2">{["Risk and authority gates", "Broker reconciliation", "Position visibility", "Unsafe-intent blocks", "Essential audit receipts"].map((item) => <p key={item} className="flex items-center gap-2 border border-border bg-background/50 px-3 py-2 text-sm"><CircleCheck className="h-4 w-4 shrink-0 text-signal" />{item}</p>)}</CardContent></Card>
      </section>

      <section><div className="mb-3 flex items-end justify-between"><div><p className="font-mono-system text-[10px] uppercase tracking-[0.15em] text-primary">One-time top-ups</p><h2 className="mt-1 font-[family-name:var(--font-heading)] text-2xl font-semibold tracking-[-0.04em]">Add optional compute capacity.</h2></div><Badge variant="outline" className="rounded-sm font-mono-system text-[9px] uppercase tracking-[0.12em]">Platform checkout</Badge></div>
        <div className="grid gap-4 md:grid-cols-2">{creditOverview === undefined ? <><Skeleton className="h-48" /><Skeleton className="h-48" /></> : creditOverview.creditPacks.map((pack) => <Card key={pack.id} className={pack.available ? "border-primary/45 bg-card" : "border-border bg-card/70"}><CardContent className="p-5"><div className="flex items-start justify-between gap-4"><div><p className="font-mono-system text-[10px] uppercase tracking-[0.14em] text-primary">{pack.label}</p><p className="mt-3 font-mono-system text-4xl font-semibold tracking-[-0.07em]">+{pack.credits}</p><p className="mt-1 text-sm text-muted-foreground">one-time Camaro credits</p></div><CreditCard className="h-5 w-5 text-primary" /></div><div className="mt-5 border-t border-border pt-4">{pack.available && pack.checkoutUrl ? <Button asChild className="w-full rounded-sm font-mono-system text-[10px] uppercase tracking-[0.12em]"><a href={checkoutUrl(pack.checkoutUrl, workspace._id)} onClick={() => posthog.capture("begin_credit_checkout", { credit_pack: pack.id, workspace_id: workspace._id, $groups: { business: BUSINESS_ID } })}>Continue to checkout <ArrowUpRight className="h-4 w-4" /></a></Button> : <div className="flex items-start gap-2 border border-border bg-background/50 p-3"><Clock3 className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" /><p className="text-xs leading-5 text-muted-foreground">This pack is not available yet. Platform catalog sync is required before checkout can open.</p></div>}</div></CardContent></Card>)}</div>
      </section>

      <section className="grid gap-4 lg:grid-cols-[1.1fr_0.9fr]">
        <Card><CardHeader><CardTitle>Credit purchase history</CardTitle><CardDescription>Immutable receipts from verified platform orders and monthly grants.</CardDescription></CardHeader><CardContent>{creditOverview === undefined ? <Skeleton className="h-32" /> : <div className="space-y-2">{creditOverview.entries.filter((entry) => entry.entryType === "platform_grant" || entry.entryType === "included_grant" || entry.entryType === "manual_grant").slice(0, 6).map((entry) => <div key={entry._id} className="flex items-center justify-between gap-3 border border-border bg-background/45 px-3 py-2"><div className="min-w-0"><p className="truncate text-sm">{entry.summary}</p><p className="font-mono-system text-[9px] uppercase tracking-[0.1em] text-muted-foreground">{new Date(entry.createdAt).toLocaleDateString()} · {entry.source.replaceAll("_", " ")}</p></div><span className="font-mono-system text-sm text-signal">+{entry.amount}</span></div>)}{creditOverview.entries.filter((entry) => entry.entryType === "platform_grant" || entry.entryType === "included_grant" || entry.entryType === "manual_grant").length === 0 && <p className="border border-dashed border-border p-4 text-sm text-muted-foreground">No credit grants have posted yet.</p>}</div>}</CardContent></Card>
        <Card><CardHeader><CardTitle>Current plan</CardTitle><CardDescription>{workspace.name}</CardDescription></CardHeader><CardContent>{isTrialing && <p className="mb-4 text-sm text-muted-foreground">Trial ends <span className="font-medium text-foreground">{trialEnd?.toLocaleDateString()}</span> · {daysLeft} days remaining.</p>}{workspace.checkoutUrl ? <Button asChild variant="outline" className="rounded-sm"><a href={decorateCheckoutUrl(workspace.checkoutUrl)} target="_blank" rel="noopener noreferrer">Upgrade plan <ArrowUpRight className="h-4 w-4" /></a></Button> : <p className="text-sm leading-6 text-muted-foreground">Plan upgrades are not configured for this workspace.</p>}</CardContent></Card>
      </section>

      <details className="border border-border bg-card/60 p-4"><summary className="cursor-pointer font-mono-system text-[10px] uppercase tracking-[0.14em] text-muted-foreground">Plan comparison</summary><div className="mt-4 grid gap-3 sm:grid-cols-3">{plans.map((plan) => <div key={plan.name} className={plan.name.toLowerCase() === currentPlan.toLowerCase() ? "border border-primary/50 bg-background/50 p-4" : "border border-border bg-background/35 p-4"}><p className="font-medium">{plan.name}</p><p className="mt-1 text-xl font-semibold">{plan.price}</p><ul className="mt-3 space-y-2">{plan.features.map((feature) => <li key={feature} className="flex gap-2 text-xs text-muted-foreground"><Check className="h-3.5 w-3.5 shrink-0 text-primary" />{feature}</li>)}</ul></div>)}</div></details>
    </div>
  );
}
