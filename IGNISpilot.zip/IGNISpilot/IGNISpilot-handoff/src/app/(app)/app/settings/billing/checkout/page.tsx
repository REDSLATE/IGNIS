"use client";

import { Suspense } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { CircleCheck, CircleX, Clock3, ShieldCheck } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

function CheckoutResult() {
  const params = useSearchParams();
  const status = params.get("status");
  const canceled = status === "cancel" || status === "canceled";
  const successful = status === "success" || status === "completed";
  const Icon = canceled ? CircleX : successful ? Clock3 : ShieldCheck;
  const eyebrow = canceled ? "Checkout canceled" : successful ? "Checkout received" : "Checkout status";
  const title = canceled ? "No credits were added." : successful ? "Waiting for verified payment." : "Your credit checkout is protected.";
  const detail = canceled ? "Your workspace balance is unchanged. You can return to credits whenever you are ready." : successful ? "A redirect is not a grant. IGNISpilot adds credits only after the signed platform fulfillment confirms a paid order for this workspace." : "Platform checkout is the only payment path. Credits are granted once, from a verified paid order receipt.";
  return <div className="mx-auto flex min-h-[65vh] max-w-xl items-center"><Card className="w-full border-primary/45 panel-surface"><CardContent className="p-7 text-center sm:p-10"><Icon className={`mx-auto h-10 w-10 ${canceled ? "text-alert" : "text-primary"}`} /><p className="mt-5 font-mono-system text-[10px] uppercase tracking-[0.16em] text-primary">{eyebrow}</p><h1 className="mt-3 font-[family-name:var(--font-heading)] text-3xl font-semibold tracking-[-0.05em]">{title}</h1><p className="mx-auto mt-4 max-w-md text-sm leading-6 text-muted-foreground">{detail}</p><Button asChild className="mt-7 rounded-sm font-mono-system text-[10px] uppercase tracking-[0.12em]"><Link href="/app/settings/billing">Return to billing</Link></Button></CardContent></Card></div>;
}

export default function CheckoutStatusPage() {
  return <Suspense fallback={<div className="p-8 text-sm text-muted-foreground">Loading checkout status…</div>}><CheckoutResult /></Suspense>;
}
