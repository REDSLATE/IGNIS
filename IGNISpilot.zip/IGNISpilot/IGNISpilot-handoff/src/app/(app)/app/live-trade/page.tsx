"use client";

import { useEffect, useState } from "react";
import { AlertTriangle, RefreshCw, ShieldCheck } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

async function api(path: string, init?: RequestInit) {
  const response = await fetch(`/api/execution/${path}`, { ...init, headers: { "Content-Type": "application/json", ...(init?.headers ?? {}) } });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.detail ?? `Request failed (${response.status})`);
  return data;
}

export default function LiveTradePage() {
  const [symbol, setSymbol] = useState("AAPL");
  const [side, setSide] = useState("BUY");
  const [orderType, setOrderType] = useState("MARKET");
  const [amountKind, setAmountKind] = useState("quantity");
  const [amount, setAmount] = useState("1");
  const [limitPrice, setLimitPrice] = useState("");
  const [health, setHealth] = useState<any>();
  const [portfolio, setPortfolio] = useState<any>();
  const [quote, setQuote] = useState<any>();
  const [ticket, setTicket] = useState<any>();
  const [submitted, setSubmitted] = useState<any>();
  const [orderStatus, setOrderStatus] = useState<any>();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function load() {
    setError("");
    try {
      const [h, p, q] = await Promise.all([api("health"), api("portfolio"), api(`quotes?symbols=${encodeURIComponent(symbol)}`)]);
      setHealth(h); setPortfolio(p); setQuote(q);
    } catch (e) { setError(e instanceof Error ? e.message : "Unable to load live data"); }
  }
  useEffect(() => { void load(); }, []);

  async function preflight() {
    setBusy(true); setError(""); setSubmitted(undefined);
    try {
      const payload: any = { symbol: symbol.toUpperCase(), side, order_type: orderType, [amountKind]: Number(amount) };
      if (orderType === "LIMIT") payload.limit_price = Number(limitPrice);
      setTicket(await api("orders/preflight", { method: "POST", body: JSON.stringify(payload) }));
    } catch (e) { setError(e instanceof Error ? e.message : "Preflight failed"); }
    finally { setBusy(false); }
  }

  async function submit() {
    if (!ticket) return;
    setBusy(true); setError("");
    try {
      setSubmitted(await api("orders/submit", { method: "POST", body: JSON.stringify({ ticket_id: ticket.ticketId, payload_hash: ticket.payloadHash, confirm_live_trade: true }) }));
    } catch (e) { setError(e instanceof Error ? e.message : "Submission failed"); }
    finally { setBusy(false); }
  }

  async function refreshOrder() {
    if (!submitted?.brokerOrderId) return;
    setBusy(true); setError("");
    try { setOrderStatus(await api(`orders/${encodeURIComponent(submitted.brokerOrderId)}`)); }
    catch (e) { setError(e instanceof Error ? e.message : "Unable to refresh order"); }
    finally { setBusy(false); }
  }

  async function cancelOrder() {
    if (!submitted?.brokerOrderId) return;
    setBusy(true); setError("");
    try { setOrderStatus(await api(`orders/${encodeURIComponent(submitted.brokerOrderId)}`, { method: "DELETE" })); }
    catch (e) { setError(e instanceof Error ? e.message : "Unable to cancel order"); }
    finally { setBusy(false); }
  }

  return <div className="mx-auto max-w-6xl space-y-6">
    <header className="panel-surface border border-primary/30 p-6"><div className="flex flex-wrap items-start justify-between gap-4"><div><p className="font-mono-system text-[10px] uppercase tracking-[0.16em] text-primary">Direct execution boundary</p><h1 className="mt-2 font-heading text-3xl font-semibold">Manual live trading</h1><p className="mt-3 max-w-2xl text-sm leading-6 text-muted-foreground">Live market reads and Public execution flow through FastAPI. Convex does not preflight, submit, refresh, or cancel these orders.</p></div><Badge variant="outline" className={health?.liveTradingEnabled ? "border-alert/50 text-alert" : "border-primary/40 text-primary"}>{health?.liveTradingEnabled ? "LIVE SUBMISSION ENABLED" : "READ + PREFLIGHT ONLY"}</Badge></div></header>
    {error && <div className="border border-alert/50 bg-alert/5 p-4 text-sm text-alert"><AlertTriangle className="mr-2 inline h-4 w-4" />{error}</div>}
    <div className="grid gap-6 lg:grid-cols-[1fr_1fr]">
      <section className="panel-surface border border-border p-5"><div className="flex items-center justify-between"><h2 className="font-heading text-xl font-semibold">Live order ticket</h2><Button variant="outline" size="sm" onClick={() => void load()}><RefreshCw className="mr-2 h-4 w-4" />Refresh</Button></div>
        <div className="mt-5 grid gap-4 sm:grid-cols-2"><div><Label>Symbol</Label><Input value={symbol} onChange={e => { setSymbol(e.target.value.toUpperCase()); setTicket(undefined); }} /></div><div><Label>Side</Label><Select value={side} onValueChange={v => { setSide(v); setTicket(undefined); }}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="BUY">Buy</SelectItem><SelectItem value="SELL">Sell</SelectItem></SelectContent></Select></div><div><Label>Amount type</Label><Select value={amountKind} onValueChange={v => { setAmountKind(v); setTicket(undefined); }}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="quantity">Shares</SelectItem><SelectItem value="amount">Dollar amount</SelectItem></SelectContent></Select></div><div><Label>Amount</Label><Input inputMode="decimal" value={amount} onChange={e => { setAmount(e.target.value); setTicket(undefined); }} /></div><div><Label>Order type</Label><Select value={orderType} onValueChange={v => { setOrderType(v); setTicket(undefined); }}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="MARKET">Market</SelectItem><SelectItem value="LIMIT">Limit</SelectItem></SelectContent></Select></div>{orderType === "LIMIT" && <div><Label>Limit price</Label><Input inputMode="decimal" value={limitPrice} onChange={e => { setLimitPrice(e.target.value); setTicket(undefined); }} /></div>}</div>
        <Button className="mt-5" disabled={busy} onClick={() => void preflight()}>Run Public preflight</Button>
        {ticket && <div className="mt-5 border border-primary/35 bg-primary/5 p-4"><div className="flex items-center gap-2 text-primary"><ShieldCheck className="h-4 w-4" /><strong>Preflight passed</strong></div><pre className="mt-3 max-h-56 overflow-auto whitespace-pre-wrap text-xs text-muted-foreground">{JSON.stringify(ticket.preflight, null, 2)}</pre><p className="mt-3 text-xs text-alert">This next button submits a real order when live submission is enabled.</p><Button variant="destructive" className="mt-3" disabled={busy || !health?.liveTradingEnabled} onClick={() => void submit()}>Confirm and submit live order</Button></div>}
        {submitted && <div className="mt-5 border border-signal/40 bg-signal/5 p-4"><pre className="overflow-auto text-xs">{JSON.stringify(submitted, null, 2)}</pre><div className="mt-3 flex gap-2"><Button variant="outline" disabled={busy || !submitted.brokerOrderId} onClick={() => void refreshOrder()}>Refresh order status</Button><Button variant="outline" disabled={busy || !submitted.brokerOrderId} onClick={() => void cancelOrder()}>Cancel open order</Button></div>{orderStatus && <pre className="mt-3 overflow-auto border border-border p-3 text-xs">{JSON.stringify(orderStatus, null, 2)}</pre>}</div>}
      </section>
      <section className="space-y-6"><div className="panel-surface border border-border p-5"><h2 className="font-heading text-xl font-semibold">Live quote</h2><pre className="mt-4 max-h-64 overflow-auto whitespace-pre-wrap text-xs text-muted-foreground">{quote ? JSON.stringify(quote, null, 2) : "Loading…"}</pre></div><div className="panel-surface border border-border p-5"><h2 className="font-heading text-xl font-semibold">Portfolio and positions</h2><pre className="mt-4 max-h-96 overflow-auto whitespace-pre-wrap text-xs text-muted-foreground">{portfolio ? JSON.stringify(portfolio, null, 2) : "Loading…"}</pre></div></section>
    </div>
  </div>;
}
