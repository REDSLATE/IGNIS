"use client";

import { type FormEvent, useMemo, useState } from "react";
import { useAction, useMutation, useQuery } from "convex/react";
import { api } from "@convex/_generated/api";
import type { Id } from "@convex/_generated/dataModel";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/components/ui/use-toast";
import { PublicBrokerConsentDialog } from "@/components/camaro/public-broker-consent-dialog";
import { ExecutionModeControl } from "@/components/camaro/execution-mode-control";
import { OperatorOrderPanel } from "@/components/camaro/operator-order-panel";
import { OpportunityCommandBoard } from "@/components/camaro/opportunity-command-board";
import { VoiceCommandPanel } from "@/components/camaro/voice-command-panel";
import {
  Activity,
  AlertTriangle,
  Archive,
  ArrowRight,
  Bot,
  CircleDollarSign,
  CircleAlert,
  DatabaseZap,
  FileUp,
  Gauge,
  Landmark,
  Link2,
  Loader2,
  LockKeyhole,
  MessageSquareWarning,
  Plus,
  ReceiptText,
  RefreshCw,
  ShieldCheck,
  Sparkles,
  Trash2,
  WifiOff,
} from "lucide-react";

const HORIZONS = [
  { value: "intraday", label: "Intraday" },
  { value: "swing", label: "Swing" },
  { value: "position", label: "Position" },
] as const;

const STANCE_SIDES = [
  { value: "long", label: "Long" },
  { value: "short", label: "Short" },
  { value: "neutral", label: "Neutral" },
] as const;

type AssetClass = "equity" | "crypto";
type Horizon = (typeof HORIZONS)[number]["value"];
type StanceSide = (typeof STANCE_SIDES)[number]["value"];
type WatchlistEntry = { _id: Id<"camaroWatchlist">; symbol: string; assetClass: AssetClass };
type ProviderId = "public" | "alpaca" | "interactive_brokers" | "coinbase" | "kraken" | "generic_rest" | "csv_manual_import";
type ProviderCatalogItem = {
  id: ProviderId;
  name: string;
  status: "available" | "coming_soon" | "manual_import";
  description: string;
  assetClasses: AssetClass[];
  capabilities: string[];
  connectionMode: "oauth" | "api_key" | "personal_access_token" | "manual_import" | "none";
  setupGuidance: string;
};

function formatTime(timestamp: number) {
  return new Intl.DateTimeFormat("en-US", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" }).format(timestamp);
}

function StatusDot({ tone = "muted" }: { tone?: "primary" | "signal" | "alert" | "muted" }) {
  const classes = { primary: "bg-primary", signal: "bg-signal", alert: "bg-alert", muted: "bg-muted-foreground" };
  return <span className={`h-2 w-2 shrink-0 rounded-full ${classes[tone]}`} />;
}

function CockpitLoading() {
  return <div className="space-y-6"><Skeleton className="h-28 w-full" /><div className="grid gap-4 xl:grid-cols-3"><Skeleton className="h-56" /><Skeleton className="h-56 xl:col-span-2" /></div><Skeleton className="h-72 w-full" /></div>;
}

function validateInspectionIntent({ selectedSymbol, selectedAssetClass, thesis, confidence }: { selectedSymbol: string; selectedAssetClass?: AssetClass; thesis: string; confidence: string }) {
  if (!selectedSymbol || selectedSymbol === "none" || !selectedAssetClass) return "Select a current watchlist symbol before inspecting an intent.";
  const normalizedThesis = thesis.trim();
  if (normalizedThesis.length < 10) return "Provide a thesis of at least 10 characters before inspection.";
  if (normalizedThesis.length > 1200) return "Keep the thesis to 1200 characters or fewer.";
  const parsedConfidence = Number(confidence);
  if (!Number.isFinite(parsedConfidence) || parsedConfidence < 0 || parsedConfidence > 1) return "Set confidence between 0 and 1 before inspection.";
  return null;
}

export default function AppDashboardPage() {
  const cockpit = useQuery(api.camaro.getCockpit);
  const runtime = useQuery(api.camaroRuntime.getRuntimeSpine, cockpit?.workspace ? { workspaceId: cockpit.workspace._id } : "skip");
  const connections = useQuery(api.camaroBroker.getConnections, cockpit?.workspace ? { workspaceId: cockpit.workspace._id } : "skip");
  const credits = useQuery(api.camaroCredits.getOverview, cockpit?.workspace ? { workspaceId: cockpit.workspace._id } : "skip");
  const seedExamples = useMutation(api.camaro.seedExamples);
  const addWatchlistSymbol = useMutation(api.camaro.addWatchlistSymbol);
  const removeWatchlistSymbol = useMutation(api.camaro.removeWatchlistSymbol);
  const createIntent = useMutation(api.camaro.createIntent);
  const enableManualImport = useMutation(api.camaroBroker.enableManualImport);
  const enablePublicReadOnly = useMutation(api.camaroBroker.enablePublicReadOnly);
  const recordPublicBrokerConsent = useMutation(api.camaroBroker.recordPublicBrokerConsent);
  const syncPublicReadOnly = useAction(api.camaroBroker.syncPublicReadOnly);
  const recordReconciliationBoundary = useMutation(api.camaroBroker.recordReconciliationBoundary);
  const recordHeartbeat = useMutation(api.camaroRuntime.recordOperatorHeartbeat);
  const publishStance = useMutation(api.camaroRuntime.publishStance);
  const challengeStance = useMutation(api.camaroRuntime.challengeStance);
  const recordOutcome = useMutation(api.camaroRuntime.recordOutcome);
  const inspectPromotionReadiness = useMutation(api.camaroRuntime.inspectPromotionReadiness);
  const runHistoricalSimulation = useMutation(api.camaroCredits.runHistoricalSimulation);
  const runExtendedReplay = useMutation(api.camaroCredits.runExtendedReplay);
  const runOutcomeTraining = useMutation(api.camaroCredits.runOutcomeTraining);
  const runAdvancedChallengePack = useMutation(api.camaroCredits.runAdvancedChallengePack);
  const { toast } = useToast();

  const [symbol, setSymbol] = useState("");
  const [assetClass, setAssetClass] = useState<AssetClass>("equity");
  const [selectedSymbol, setSelectedSymbol] = useState("");
  const [horizon, setHorizon] = useState<Horizon>("intraday");
  const [thesis, setThesis] = useState("");
  const [confidence, setConfidence] = useState("0.50");
  const [stanceSymbol, setStanceSymbol] = useState("");
  const [stanceAssetClass, setStanceAssetClass] = useState<AssetClass>("equity");
  const [stanceSide, setStanceSide] = useState<StanceSide>("neutral");
  const [stanceRationale, setStanceRationale] = useState("");
  const [outcomeSummary, setOutcomeSummary] = useState("");
  const [promotionArtifact, setPromotionArtifact] = useState("Camaro doctrine configuration");
  const [isSavingWatchlist, setIsSavingWatchlist] = useState(false);
  const [isCreatingIntent, setIsCreatingIntent] = useState(false);
  const [isSeeding, setIsSeeding] = useState(false);
  const [isEnablingImport, setIsEnablingImport] = useState(false);
  const [isEnablingPublic, setIsEnablingPublic] = useState(false);
  const [isPublicConsentOpen, setIsPublicConsentOpen] = useState(false);
  const [isSyncingPublic, setIsSyncingPublic] = useState(false);
  const [isRecordingHeartbeat, setIsRecordingHeartbeat] = useState(false);
  const [isPublishingStance, setIsPublishingStance] = useState(false);
  const [isRecordingOutcome, setIsRecordingOutcome] = useState(false);
  const [isInspectingPromotion, setIsInspectingPromotion] = useState(false);
  const [challengingId, setChallengingId] = useState<Id<"camaroStances"> | null>(null);
  const [reconcilingId, setReconcilingId] = useState<Id<"camaroProviderConnections"> | null>(null);
  const [creditActionInFlight, setCreditActionInFlight] = useState<string | null>(null);

  const watchlist = cockpit?.watchlist ?? [];
  const equities = useMemo(() => watchlist.filter((item) => item.assetClass === "equity"), [watchlist]);
  const cryptoWatchlist = useMemo(() => watchlist.filter((item) => item.assetClass === "crypto"), [watchlist]);
  const selectedIntent = cockpit?.intents[0];
  const manualImportConnection = connections?.connections.find((connection) => connection.providerId === "csv_manual_import");
  const publicConnection = connections?.connections.find((connection) => connection.providerId === "public");
  const noMarketData = cockpit?.provider.status === "not_configured";

  if (cockpit === undefined) return <CockpitLoading />;

  if (!cockpit?.workspace) {
    return <div className="mx-auto max-w-2xl py-12"><Card className="border-primary/40 panel-surface"><CardContent className="p-8 text-center sm:p-12"><ShieldCheck className="mx-auto h-10 w-10 text-primary" /><p className="mt-6 font-mono-system text-xs uppercase tracking-[0.18em] text-primary">Camaro workspace required</p><h1 className="mt-3 font-[family-name:var(--font-heading)] text-3xl font-semibold tracking-[-0.05em]">Establish your operating workspace.</h1><p className="mx-auto mt-4 max-w-lg text-sm leading-6 text-muted-foreground">Create or join a workspace before using the approval-only Camaro cockpit.</p></CardContent></Card></div>;
  }

  const workspaceId = cockpit.workspace._id;
  const availableSymbols = watchlist.map((entry) => entry.symbol);
  const selectedWatchlistEntry = watchlist.find((entry) => entry.symbol === selectedSymbol);
  const inspectionIntentError = validateInspectionIntent({ selectedSymbol, selectedAssetClass: selectedWatchlistEntry?.assetClass, thesis, confidence });

  async function handleAddWatchlist(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setIsSavingWatchlist(true);
    try { await addWatchlistSymbol({ workspaceId, symbol, assetClass }); setSymbol(""); toast({ title: "Watchlist updated", description: "No quote or signal was retrieved." }); }
    catch (error) { toast({ variant: "destructive", title: "Unable to add symbol", description: error instanceof Error ? error.message : "Try again." }); }
    finally { setIsSavingWatchlist(false); }
  }

  async function handleCreateIntent(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (inspectionIntentError || !selectedWatchlistEntry) {
      toast({ variant: "destructive", title: "Complete the inspection", description: inspectionIntentError ?? "Select a current watchlist symbol before inspecting an intent." });
      return;
    }
    setIsCreatingIntent(true);
    try { await createIntent({ workspaceId, symbol: selectedWatchlistEntry.symbol, assetClass: selectedWatchlistEntry.assetClass, horizon, thesis: thesis.trim(), confidence: Number(confidence) }); setThesis(""); toast({ title: "Intent inspected", description: "A blocked decision receipt was recorded." }); }
    catch (error) { toast({ variant: "destructive", title: "Unable to inspect intent", description: error instanceof Error ? error.message : "Try again." }); }
    finally { setIsCreatingIntent(false); }
  }

  async function handleRecordHeartbeat() {
    setIsRecordingHeartbeat(true);
    try { await recordHeartbeat({ workspaceId }); toast({ title: "Heartbeat recorded", description: "No sidecar, runtime token, or Mission Control connection was implied." }); }
    catch (error) { toast({ variant: "destructive", title: "Unable to record heartbeat", description: error instanceof Error ? error.message : "Try again." }); }
    finally { setIsRecordingHeartbeat(false); }
  }

  async function handlePublishStance(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setIsPublishingStance(true);
    try { await publishStance({ workspaceId, symbol: stanceSymbol, assetClass: stanceAssetClass, side: stanceSide, confidence: Number(confidence), rationale: stanceRationale }); setStanceRationale(""); toast({ title: "Camaro stance published", description: "An operator-recorded opinion and receipt are now available." }); }
    catch (error) { toast({ variant: "destructive", title: "Unable to publish stance", description: error instanceof Error ? error.message : "Try again." }); }
    finally { setIsPublishingStance(false); }
  }

  async function handleChallenge(stanceId: Id<"camaroStances">) {
    setChallengingId(stanceId);
    try { await challengeStance({ stanceId, targetRuntime: "Peer runtime (unconnected)", counterSide: "neutral", rationale: "Operator-recorded challenge for review; no peer runtime connection is available." }); toast({ title: "Challenge recorded", description: "No external peer was contacted." }); }
    catch (error) { toast({ variant: "destructive", title: "Unable to record challenge", description: error instanceof Error ? error.message : "Try again." }); }
    finally { setChallengingId(null); }
  }

  async function handleRecordOutcome(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setIsRecordingOutcome(true);
    try { await recordOutcome({ workspaceId, intentId: selectedIntent?._id, disposition: selectedIntent ? "blocked" : "unresolved", summary: outcomeSummary }); setOutcomeSummary(""); toast({ title: "Outcome receipt recorded", description: "No fill, price, or performance outcome was claimed." }); }
    catch (error) { toast({ variant: "destructive", title: "Unable to record outcome", description: error instanceof Error ? error.message : "Try again." }); }
    finally { setIsRecordingOutcome(false); }
  }

  async function handlePromotionInspection(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setIsInspectingPromotion(true);
    try { await inspectPromotionReadiness({ workspaceId, artifactName: promotionArtifact }); toast({ title: "Promotion held", description: "Readiness was inspected; nothing was promoted." }); }
    catch (error) { toast({ variant: "destructive", title: "Unable to inspect promotion", description: error instanceof Error ? error.message : "Try again." }); }
    finally { setIsInspectingPromotion(false); }
  }

  async function handleSeedExamples() {
    setIsSeeding(true);
    try { await seedExamples({ workspaceId }); toast({ title: "Examples added", description: "Neutral symbols only; no market data was loaded." }); }
    catch (error) { toast({ variant: "destructive", title: "Unable to seed examples", description: error instanceof Error ? error.message : "Try again." }); }
    finally { setIsSeeding(false); }
  }

  async function handleEnableManualImport() {
    setIsEnablingImport(true);
    try { await enableManualImport({ workspaceId, providerId: "csv_manual_import" }); toast({ title: "Manual-import setup recorded", description: "No file, broker credential, or account data was captured." }); }
    catch (error) { toast({ variant: "destructive", title: "Unable to enable setup", description: error instanceof Error ? error.message : "Try again." }); }
    finally { setIsEnablingImport(false); }
  }

  async function handleEnablePublicReadOnly() {
    setIsEnablingPublic(true);
    try { await enablePublicReadOnly({ workspaceId }); toast({ title: "Public read-only connector enabled", description: "Server-only credentials remain outside this workspace. Run a read-only sync to inspect broker state." }); }
    catch (error) { toast({ variant: "destructive", title: "Unable to enable Public", description: error instanceof Error ? error.message : "Try again." }); }
    finally { setIsEnablingPublic(false); }
  }

  async function handlePublicConsent() {
    setIsEnablingPublic(true);
    try {
      await recordPublicBrokerConsent({ workspaceId, agreed: true });
      await enablePublicReadOnly({ workspaceId });
      setIsPublicConsentOpen(false);
      toast({ title: "Public read-only connector enabled", description: "Current consent was recorded server-side. Server-only credentials remain outside this workspace." });
    } catch (error) {
      toast({ variant: "destructive", title: "Unable to enable Public", description: error instanceof Error ? error.message : "Try again." });
    } finally {
      setIsEnablingPublic(false);
    }
  }

  async function handleSyncPublicReadOnly() {
    setIsSyncingPublic(true);
    try { await syncPublicReadOnly({ workspaceId }); toast({ title: "Public sync completed", description: "The console now reflects the verified read-only health state. No order action was attempted." }); }
    catch (error) { toast({ variant: "destructive", title: "Public sync unavailable", description: "The server recorded a safe unavailable receipt. No provider details were exposed." }); }
    finally { setIsSyncingPublic(false); }
  }

  async function handleRecordBoundary(connectionId: Id<"camaroProviderConnections">) {
    setReconcilingId(connectionId);
    try { await recordReconciliationBoundary({ connectionId }); toast({ title: "No-data receipt recorded", description: "Camaro did not invent a reconciliation result." }); }
    catch (error) { toast({ variant: "destructive", title: "Unable to record receipt", description: error instanceof Error ? error.message : "Try again." }); }
    finally { setReconcilingId(null); }
  }

  async function handleCreditAction(action: "historical_simulation" | "extended_replay" | "resolved_outcome_training" | "advanced_challenge_pack") {
    const actionDetail = credits?.actions.find((item) => item.id === action);
    if (!actionDetail) return;
    const idempotencyKey = `cockpit:${action}:${globalThis.crypto.randomUUID()}`;
    setCreditActionInFlight(action);
    try {
      const result = action === "historical_simulation"
        ? await runHistoricalSimulation({ workspaceId, symbol: selectedSymbol || availableSymbols[0] || "CAMARO", idempotencyKey })
        : action === "extended_replay"
          ? await runExtendedReplay({ workspaceId, idempotencyKey })
          : action === "resolved_outcome_training"
            ? await runOutcomeTraining({ workspaceId, idempotencyKey })
            : await runAdvancedChallengePack({ workspaceId, idempotencyKey });
      if (result.state === "insufficient") {
        toast({ variant: "destructive", title: "Optional analysis held", description: `${result.required} credits are required; ${result.balance} available. Safety, broker, audit, and position controls remain included.` });
      } else if (result.started) {
        toast({ title: `${actionDetail.label} receipt created`, description: `${result.required} credits debited. This remains a governed, non-execution workflow.` });
      }
    } catch (error) { toast({ variant: "destructive", title: "Unable to start optional analysis", description: error instanceof Error ? error.message : "Try again." }); }
    finally { setCreditActionInFlight(null); }
  }

  async function handleVoiceHistoricalDryRun(symbol: string) {
    await runHistoricalSimulation({ workspaceId, symbol, idempotencyKey: `voice-console:dry-run:${symbol}:${crypto.randomUUID()}` });
    toast({ title: "Voice dry-run receipt created", description: `${symbol} was queued for historical simulation. No broker order was created or routed.` });
  }

  return <div className="space-y-6 pb-8">
    <PublicBrokerConsentDialog open={isPublicConsentOpen} onOpenChange={setIsPublicConsentOpen} onConfirm={handlePublicConsent} isSaving={isEnablingPublic} />
    <section className="border border-primary/35 bg-card p-5 shadow-[0_18px_56px_-34px_hsl(var(--primary))] sm:p-7"><div className="flex flex-col gap-5 xl:flex-row xl:items-end xl:justify-between"><div><div className="flex items-center gap-2 font-mono-system text-[10px] uppercase tracking-[0.18em] text-primary"><Bot className="h-4 w-4" /> RISEDUAL / Camaro tactical runtime</div><h1 className="mt-3 max-w-3xl font-[family-name:var(--font-heading)] text-3xl font-semibold tracking-[-0.05em] sm:text-4xl">Decision intent, governed by receipts.</h1><p className="mt-3 max-w-2xl text-sm leading-6 text-muted-foreground">Workspace-scoped operational records for the Camaro runtime. The cockpit records governed operational controls and only exposes the documented, operator-confirmed Public equity order path when every server gate passes.</p></div><div className="flex flex-wrap gap-2"><Badge variant="outline" className="rounded-sm border-alert/50 font-mono-system text-[10px] uppercase tracking-[0.12em] text-alert">Approval-only</Badge><Badge variant="outline" className="rounded-sm border-border font-mono-system text-[10px] uppercase tracking-[0.12em] text-muted-foreground">Operator gated</Badge></div></div><div className="mt-6 grid gap-2 sm:grid-cols-2 xl:grid-cols-5"><StatusCell label="Runtime" value={runtime?.heartbeat ? "Heartbeat recorded" : "No heartbeat"} tone={runtime?.heartbeat?.freshness === "recorded" ? "signal" : "muted"} /><StatusCell label="Token check" value={runtime?.heartbeat?.tokenCheck ?? "Unavailable"} tone="muted" /><StatusCell label="Mission Control" value="Unconnected" tone="muted" /><StatusCell label="Provider" value={cockpit.provider.status.replaceAll("_", " ")} tone={noMarketData ? "alert" : "muted"} /><StatusCell label="Broker" value="Operator-gated" tone="muted" /></div></section>

    <VoiceCommandPanel workspaceId={workspaceId} watchlist={watchlist} onHistoricalDryRun={handleVoiceHistoricalDryRun} />

    <section id="camaro-position-state" aria-label="Camaro read-only position state"><Card className="border-border bg-background/45"><CardHeader className="border-b border-border pb-4"><div className="flex items-start justify-between gap-4"><div><p className="font-mono-system text-[10px] uppercase tracking-[0.16em] text-primary">Read-only position state</p><CardTitle className="mt-2">No reconciled position records available.</CardTitle></div><Landmark className="h-5 w-5 text-primary" /></div></CardHeader><CardContent className="p-5"><p className="text-sm leading-6 text-muted-foreground">Camaro will not infer positions from intents, voice input, or stale broker state. Connect and reconcile a supported read-only source before position lifecycle records can appear here.</p></CardContent></Card></section>

    <OperatorOrderPanel workspaceId={workspaceId} liveOrderGateEnabled={connections?.executionControl.liveOrderGateEnabled ?? false} publicConsentCurrent={connections?.publicConsent.isCurrent ?? false} executionMode={connections?.executionControl.selectedMode ?? "READ_ONLY"} intents={connections?.executionControl.intents ?? []} onReviewConsent={() => setIsPublicConsentOpen(true)} />

    <section className="grid gap-6 xl:grid-cols-[0.9fr_1.1fr]"><Card className="border-primary/35 bg-card"><CardHeader className="border-b border-border pb-4"><div className="flex items-start justify-between gap-4"><div><p className="font-mono-system text-[10px] uppercase tracking-[0.16em] text-primary">Compute allocation / governed</p><CardTitle className="mt-2">Camaro usage credits</CardTitle></div><CircleDollarSign className="h-5 w-5 text-primary" /></div></CardHeader><CardContent className="p-5"><div className="border border-primary/30 bg-primary/5 p-4"><p className="font-mono-system text-[10px] uppercase tracking-[0.14em] text-primary">Available analysis capacity</p><p className="mt-2 font-[family-name:var(--font-heading)] text-5xl font-semibold tracking-[-0.06em]">{credits?.availableCredits ?? "—"}<span className="ml-2 text-lg text-muted-foreground">credits</span></p><p className="mt-3 text-sm leading-6 text-muted-foreground">{credits?.monthlyIncludedCredits ?? 24} included each monthly period. Credits only govern optional compute; they never buy, remove, or weaken safety controls.</p></div><div className="mt-4 border border-border bg-background/45 p-4"><p className="font-mono-system text-[10px] uppercase tracking-[0.14em] text-muted-foreground">Always included / never credit-gated</p><div className="mt-3 flex flex-wrap gap-2">{credits?.includedCapabilities.map((capability) => <span key={capability} className="border border-border px-2 py-1 font-mono-system text-[9px] uppercase tracking-[0.1em] text-muted-foreground">{capability}</span>)}</div></div></CardContent></Card><Card className="panel-surface"><CardHeader className="border-b border-border pb-4"><div><p className="font-mono-system text-[10px] uppercase tracking-[0.16em] text-primary">Optional analysis queue</p><CardTitle className="mt-2">Cost is shown before any compute starts.</CardTitle></div></CardHeader><CardContent className="p-5"><div className="space-y-2">{credits?.actions.map((action) => { const insufficient = (credits.availableCredits ?? 0) < action.cost; const inFlight = creditActionInFlight === action.id; return <div key={action.id} className="border border-border bg-background/45 p-4"><div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between"><div><div className="flex flex-wrap items-center gap-2"><p className="font-medium">{action.label}</p><Badge variant="outline" className="rounded-sm border-primary/40 font-mono-system text-[9px] uppercase tracking-[0.1em] text-primary">{action.cost} credits</Badge></div><p className="mt-1 text-sm leading-6 text-muted-foreground">{action.description}</p>{insufficient && <p className="mt-2 font-mono-system text-[10px] uppercase tracking-[0.1em] text-alert">Held: {action.cost} required / {credits.availableCredits} available</p>}</div><Button type="button" variant="outline" size="sm" disabled={inFlight} onClick={() => void handleCreditAction(action.id)} className="shrink-0 rounded-sm font-mono-system text-[10px] uppercase tracking-wide">{inFlight ? <Loader2 className="animate-spin" /> : <DatabaseZap />}{insufficient ? "Explain hold" : "Confirm run"}</Button></div></div>; })}</div></CardContent></Card></section>

    <section className="grid gap-6 xl:grid-cols-[1.15fr_0.85fr]"><Card className="panel-surface"><CardHeader className="border-b border-border pb-4"><div className="flex items-start justify-between gap-4"><div><p className="font-mono-system text-[10px] uppercase tracking-[0.16em] text-primary">Credit receipts / append-only</p><CardTitle className="mt-2">Every allocation remains attributable.</CardTitle></div><ReceiptText className="h-5 w-5 text-primary" /></div></CardHeader><CardContent className="p-5"><div className="divide-y divide-border border border-border">{credits?.entries.length ? credits.entries.map((entry) => <div key={entry._id} className="p-3"><div className="flex flex-wrap items-center justify-between gap-2"><span className="font-mono-system text-[10px] uppercase tracking-[0.12em] text-primary">{entry.entryType.replaceAll("_", " ")}</span><span className="font-mono-system text-[10px] uppercase tracking-[0.12em] text-muted-foreground">{entry.amount > 0 ? "+" : ""}{entry.amount} · balance {entry.balanceAfter}</span></div><p className="mt-2 text-sm leading-6 text-muted-foreground">{entry.summary}</p><p className="mt-2 font-mono-system text-[9px] uppercase tracking-[0.1em] text-muted-foreground">{formatTime(entry.createdAt)} · {entry.idempotencyKey}</p></div>) : <EmptyPanel icon={ReceiptText} title="No credit receipts yet" description="Your included monthly grant will appear when an optional analysis action is first requested." />}</div></CardContent></Card><aside className="border border-border bg-muted/20 p-5"><p className="font-mono-system text-[10px] uppercase tracking-[0.16em] text-primary">Control boundary</p><h2 className="mt-3 font-[family-name:var(--font-heading)] text-2xl font-semibold tracking-[-0.04em]">Insufficient credits stop compute, not control.</h2><p className="mt-3 text-sm leading-6 text-muted-foreground">A held simulation, replay, training pass, or challenge pack records why it was held. Risk checks, authority gates, broker reconciliation, audit receipts, position visibility, and blocks on unsafe intent remain available at zero credits.</p></aside></section>

    <section className="grid gap-6 xl:grid-cols-[0.8fr_1.2fr]"><Card className="panel-surface"><CardHeader className="border-b border-border pb-4"><div className="flex items-start justify-between gap-4"><div><p className="font-mono-system text-[10px] uppercase tracking-[0.16em] text-primary">01 / Sovereign sidecar</p><CardTitle className="mt-2">Heartbeat is a record, not a connection.</CardTitle></div><Activity className="h-5 w-5 text-primary" /></div></CardHeader><CardContent className="p-5"><div className="border border-border bg-background/45 p-4"><div className="flex items-center justify-between gap-3"><div><p className="font-medium">Camaro runtime status</p><p className="mt-1 text-sm leading-6 text-muted-foreground">{runtime?.heartbeat?.detail ?? "No heartbeat has been recorded in this workspace."}</p></div><StatusDot tone={runtime?.heartbeat?.freshness === "recorded" ? "signal" : "muted"} /></div>{runtime?.heartbeat && <p className="mt-3 font-mono-system text-[10px] uppercase tracking-[0.12em] text-muted-foreground">{formatTime(runtime.heartbeat.recordedAt)} · {runtime.heartbeat.freshness}</p>}</div><Button type="button" variant="outline" size="sm" onClick={() => void handleRecordHeartbeat()} disabled={isRecordingHeartbeat} className="mt-4 rounded-sm font-mono-system text-[10px] uppercase tracking-wide">{isRecordingHeartbeat ? <Loader2 className="animate-spin" /> : <RefreshCw />} Record operator heartbeat</Button><p className="mt-4 text-xs leading-5 text-muted-foreground">Future seam: a sovereign sidecar can verify runtime tokens and post service heartbeats through a server-side contract. This release stores neither token nor sidecar connection.</p></CardContent></Card>
      <Card><CardHeader className="border-b border-border pb-4"><div className="flex items-start justify-between gap-4"><div><p className="font-mono-system text-[10px] uppercase tracking-[0.16em] text-primary">02 / Brain → Mission Control</p><CardTitle className="mt-2">Intent is inspectable before it can travel.</CardTitle></div><ArrowRight className="h-5 w-5 text-primary" /></div></CardHeader><CardContent className="p-5"><div className="grid gap-3 sm:grid-cols-3"><SpineStep label="Brain / Camaro" detail="Creates operator-recorded stance and intent." state="represented" /><SpineStep label="Mission Control" detail="Future inspection and routing endpoint." state="unconnected" /><SpineStep label="Broker reality" detail="Future read-only reconciliation boundary." state="unconnected" /></div><div className="mt-4 border border-border bg-muted/25 p-4 text-sm leading-6 text-muted-foreground">Current contract: an intent is validated inside its workspace, receives doctrine and risk inspection, and produces append-only receipts. It cannot become an order or invoke an external runtime.</div></CardContent></Card></section>

    <section className="grid gap-6 xl:grid-cols-[0.85fr_1.15fr]"><Card id="camaro-voice-inspection"><CardHeader className="border-b border-border pb-4"><div className="flex items-start justify-between gap-4"><div><p className="font-mono-system text-[10px] uppercase tracking-[0.16em] text-primary">03 / Watchlist</p><CardTitle className="mt-2">Separate equity and crypto routes.</CardTitle></div><Archive className="h-5 w-5 text-primary" /></div></CardHeader><CardContent className="p-5"><form onSubmit={handleAddWatchlist} className="grid gap-3 sm:grid-cols-[1fr_140px_auto]"><div><Label htmlFor="watchlist-symbol" className="sr-only">Symbol</Label><Input id="watchlist-symbol" value={symbol} onChange={(event) => setSymbol(event.target.value)} placeholder="Add symbol" maxLength={20} /></div><Select value={assetClass} onValueChange={(value) => setAssetClass(value as AssetClass)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="equity">Equity</SelectItem><SelectItem value="crypto">Crypto</SelectItem></SelectContent></Select><Button type="submit" disabled={isSavingWatchlist} className="rounded-sm font-mono-system text-[10px] uppercase tracking-wide">{isSavingWatchlist ? <Loader2 className="animate-spin" /> : <Plus />} Add</Button></form>{watchlist.length === 0 ? <div className="mt-5 border border-dashed border-border p-5"><p className="font-medium">No workspace symbols yet.</p><p className="mt-1 text-sm leading-6 text-muted-foreground">Add your own identifiers or seed neutral examples. Camaro does not fetch prices or signals.</p><Button type="button" variant="outline" size="sm" onClick={() => void handleSeedExamples()} disabled={isSeeding} className="mt-4 rounded-sm font-mono-system text-[10px] uppercase tracking-wide">{isSeeding ? <Loader2 className="animate-spin" /> : <Sparkles />} Add neutral examples</Button></div> : <div className="mt-5 space-y-5"><WatchlistGroup label="Equity policy route" entries={equities} onRemove={(id) => void removeWatchlistSymbol({ watchlistId: id })} /><WatchlistGroup label="Crypto policy route" entries={cryptoWatchlist} onRemove={(id) => void removeWatchlistSymbol({ watchlistId: id })} /></div>}</CardContent></Card>
      <Card><CardHeader className="border-b border-border pb-4"><div className="flex items-start justify-between gap-4"><div><p className="font-mono-system text-[10px] uppercase tracking-[0.16em] text-primary">04 / Intent inspection</p><CardTitle className="mt-2">Record the thesis. Show the gate.</CardTitle></div><ShieldCheck className="h-5 w-5 text-primary" /></div></CardHeader><CardContent className="p-5"><form onSubmit={handleCreateIntent} className="grid gap-4"><div className="grid gap-3 sm:grid-cols-3"><Select value={selectedSymbol} onValueChange={setSelectedSymbol}><SelectTrigger><SelectValue placeholder="Select symbol" /></SelectTrigger><SelectContent>{availableSymbols.length ? availableSymbols.map((item) => <SelectItem key={item} value={item}>{item}</SelectItem>) : <SelectItem value="none" disabled>Add a watchlist symbol first</SelectItem>}</SelectContent></Select><Select value={horizon} onValueChange={(value) => setHorizon(value as Horizon)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{HORIZONS.map((item) => <SelectItem key={item.value} value={item.value}>{item.label}</SelectItem>)}</SelectContent></Select><div><Label htmlFor="intent-confidence" className="sr-only">Confidence</Label><Input id="intent-confidence" type="number" min="0" max="1" step="0.01" value={confidence} onChange={(event) => setConfidence(event.target.value)} /></div></div><Textarea value={thesis} onChange={(event) => setThesis(event.target.value)} placeholder="Operator thesis for inspection (10–1200 characters)" rows={4} />{inspectionIntentError ? <p className="text-sm leading-6 text-alert">{inspectionIntentError}</p> : null}<Button type="submit" disabled={Boolean(inspectionIntentError) || isCreatingIntent} className="w-fit rounded-sm font-mono-system text-[10px] uppercase tracking-wide">{isCreatingIntent ? <Loader2 className="animate-spin" /> : <ArrowRight />} Inspect intent</Button></form><div className="mt-5 border-t border-border pt-4"><p className="font-mono-system text-[10px] uppercase tracking-[0.14em] text-muted-foreground">Latest decisions</p>{cockpit.intents.length ? <div className="mt-3 space-y-2">{cockpit.intents.map((intent) => <div key={intent._id} className="border border-border bg-background/45 p-3"><div className="flex items-center justify-between gap-3"><p className="font-mono-system text-sm font-medium">{intent.symbol} <span className="text-muted-foreground">/ {intent.horizon}</span></p><Badge variant="outline" className="rounded-sm border-alert/50 font-mono-system text-[9px] uppercase tracking-[0.1em] text-alert">{intent.status.replaceAll("_", " ")}</Badge></div><p className="mt-2 text-sm leading-6 text-muted-foreground">{intent.thesis}</p><p className="mt-2 font-mono-system text-[10px] uppercase tracking-[0.12em] text-muted-foreground">{formatTime(intent.createdAt)} · {Math.round(intent.confidence * 100)}% operator confidence</p></div>)}</div> : <p className="mt-3 text-sm leading-6 text-muted-foreground">No intent records yet.</p>}</div></CardContent></Card></section>

    <section className="grid gap-6 xl:grid-cols-[1.05fr_0.95fr]"><Card><CardHeader className="border-b border-border pb-4"><div className="flex items-start justify-between gap-4"><div><p className="font-mono-system text-[10px] uppercase tracking-[0.16em] text-primary">05 / Stance + challenge</p><CardTitle className="mt-2">Opinion is separate from execution.</CardTitle></div><MessageSquareWarning className="h-5 w-5 text-primary" /></div></CardHeader><CardContent className="p-5"><form onSubmit={handlePublishStance} className="grid gap-3"><div className="grid gap-3 sm:grid-cols-3"><Input value={stanceSymbol} onChange={(event) => setStanceSymbol(event.target.value)} placeholder="Symbol" maxLength={20} /><Select value={stanceAssetClass} onValueChange={(value) => setStanceAssetClass(value as AssetClass)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="equity">Equity</SelectItem><SelectItem value="crypto">Crypto</SelectItem></SelectContent></Select><Select value={stanceSide} onValueChange={(value) => setStanceSide(value as StanceSide)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{STANCE_SIDES.map((item) => <SelectItem key={item.value} value={item.value}>{item.label}</SelectItem>)}</SelectContent></Select></div><Textarea value={stanceRationale} onChange={(event) => setStanceRationale(event.target.value)} placeholder="Operator rationale for Camaro’s published opinion (10–1200 characters)" rows={3} /><Button type="submit" disabled={isPublishingStance} className="w-fit rounded-sm font-mono-system text-[10px] uppercase tracking-wide">{isPublishingStance ? <Loader2 className="animate-spin" /> : <MessageSquareWarning />} Publish stance</Button></form><div className="mt-5 border-t border-border pt-4"><p className="font-mono-system text-[10px] uppercase tracking-[0.14em] text-muted-foreground">Published stances</p>{runtime?.stances.length ? <div className="mt-3 space-y-2">{runtime.stances.map((stance) => <div key={stance._id} className="border border-border bg-background/45 p-3"><div className="flex flex-wrap items-center justify-between gap-2"><p className="font-mono-system text-sm font-medium">{stance.symbol} <span className="text-muted-foreground">/ {stance.side}</span></p><div className="flex items-center gap-2"><span className="font-mono-system text-[10px] uppercase tracking-[0.1em] text-muted-foreground">{stance.resolution}</span><Button type="button" variant="ghost" size="sm" onClick={() => void handleChallenge(stance._id)} disabled={challengingId === stance._id} className="h-7 rounded-sm px-2 font-mono-system text-[9px] uppercase tracking-wide">{challengingId === stance._id ? <Loader2 className="animate-spin" /> : <MessageSquareWarning />} Challenge</Button></div></div><p className="mt-2 text-sm leading-6 text-muted-foreground">{stance.rationale}</p></div>)}</div> : <p className="mt-3 text-sm leading-6 text-muted-foreground">No Camaro opinions have been published.</p>}</div></CardContent></Card>
      <Card><CardHeader className="border-b border-border pb-4"><div className="flex items-start justify-between gap-4"><div><p className="font-mono-system text-[10px] uppercase tracking-[0.16em] text-primary">06 / Doctrine + risk</p><CardTitle className="mt-2">Routes stay separate; authority stays explicit.</CardTitle></div><LockKeyhole className="h-5 w-5 text-primary" /></div></CardHeader><CardContent className="space-y-3 p-5">{runtime?.doctrineChecks.map((check) => <GateRow key={check.name} icon={check.name.includes("authority") ? LockKeyhole : check.name.includes("Broker") ? Landmark : Gauge} title={check.name} detail={check.detail} state={check.state} />)}<div className="grid gap-2 sm:grid-cols-2"><RouteBoundary label="Equity doctrine" detail={runtime?.routes.equity.detail ?? "Loading route boundary."} /><RouteBoundary label="Crypto doctrine" detail={runtime?.routes.crypto.detail ?? "Loading route boundary."} /></div></CardContent></Card></section>

    <section className="grid gap-6 xl:grid-cols-[0.95fr_1.05fr]"><Card><CardHeader className="border-b border-border pb-4"><div className="flex items-start justify-between gap-4"><div><p className="font-mono-system text-[10px] uppercase tracking-[0.16em] text-primary">07 / Outcomes + learning</p><CardTitle className="mt-2">Append-only review without invented returns.</CardTitle></div><ReceiptText className="h-5 w-5 text-primary" /></div></CardHeader><CardContent className="p-5"><form onSubmit={handleRecordOutcome} className="space-y-3"><Textarea value={outcomeSummary} onChange={(event) => setOutcomeSummary(event.target.value)} placeholder="Record a verified operator observation, unresolved review, or block reason" rows={3} /><Button type="submit" disabled={isRecordingOutcome} className="rounded-sm font-mono-system text-[10px] uppercase tracking-wide">{isRecordingOutcome ? <Loader2 className="animate-spin" /> : <ReceiptText />} Record outcome</Button></form><div className="mt-5 border-t border-border pt-4"><p className="font-mono-system text-[10px] uppercase tracking-[0.14em] text-muted-foreground">Outcome records</p>{runtime?.outcomes.length ? <div className="mt-3 divide-y divide-border border border-border">{runtime.outcomes.map((outcome) => <div key={outcome._id} className="p-3"><div className="flex items-center justify-between gap-2"><span className="font-mono-system text-[10px] uppercase tracking-[0.12em] text-muted-foreground">{outcome.disposition}</span><span className="font-mono-system text-[10px] uppercase tracking-[0.12em] text-muted-foreground">{formatTime(outcome.createdAt)}</span></div><p className="mt-2 text-sm leading-6 text-muted-foreground">{outcome.summary}</p></div>)}</div> : <p className="mt-3 text-sm leading-6 text-muted-foreground">No outcomes recorded. Training is a future seam until verified resolved evidence is available.</p>}</div></CardContent></Card>
      <Card><CardHeader className="border-b border-border pb-4"><div className="flex items-start justify-between gap-4"><div><p className="font-mono-system text-[10px] uppercase tracking-[0.16em] text-primary">08 / Promotion ladder</p><CardTitle className="mt-2">Inspection before readiness.</CardTitle></div><Link2 className="h-5 w-5 text-primary" /></div></CardHeader><CardContent className="p-5"><form onSubmit={handlePromotionInspection} className="flex flex-col gap-3 sm:flex-row"><Input value={promotionArtifact} onChange={(event) => setPromotionArtifact(event.target.value)} maxLength={100} /><Button type="submit" disabled={isInspectingPromotion} className="rounded-sm font-mono-system text-[10px] uppercase tracking-wide">{isInspectingPromotion ? <Loader2 className="animate-spin" /> : <ShieldCheck />} Inspect readiness</Button></form><p className="mt-4 text-sm leading-6 text-muted-foreground">The learning ladder records a not-ready checkpoint until a future evidence package, token verification, and sidecar/Mission Control gate are actually implemented.</p>{runtime?.promotions.length ? <div className="mt-4 space-y-2">{runtime.promotions.map((promotion) => <div key={promotion._id} className="border border-border bg-background/45 p-3"><div className="flex items-center justify-between gap-2"><p className="text-sm font-medium">{promotion.artifactName}</p><Badge variant="outline" className="rounded-sm border-alert/50 font-mono-system text-[9px] uppercase tracking-[0.1em] text-alert">{promotion.status.replaceAll("_", " ")}</Badge></div><p className="mt-2 text-xs leading-5 text-muted-foreground">{promotion.blockers.join(" ")}</p></div>)}</div> : null}</CardContent></Card></section>

    <section className="grid gap-6 xl:grid-cols-[1fr_1fr]"><Card><CardHeader className="border-b border-border pb-4"><div className="flex items-start justify-between gap-4"><div><p className="font-mono-system text-[10px] uppercase tracking-[0.16em] text-primary">09 / Provider + broker boundary</p><CardTitle className="mt-2">Public read-only, consent before connectivity.</CardTitle></div><Landmark className="h-5 w-5 text-primary" /></div></CardHeader><CardContent className="p-5"><div className="border border-primary/30 bg-primary/5 p-4"><div className="flex items-start justify-between gap-3"><div><p className="font-medium">Public.com read-only connector</p><p className="mt-1 text-sm leading-6 text-muted-foreground">Only the server uses Public&apos;s Personal Secret Token to obtain a short-lived access token and discover authenticated accounts. The cockpit never requests, shows, or stores a Public secret, account ID, or workspace ID. No balances or positions are live until a verified snapshot is recorded.</p></div><Badge variant="outline" className="rounded-sm border-primary/40 font-mono-system text-[10px] uppercase tracking-wide text-primary">{publicConnection?.status.replaceAll("_", " ") ?? "not connected"}</Badge></div><p className="mt-3 font-mono-system text-[10px] uppercase tracking-[0.12em] text-muted-foreground">Consent / {connections?.publicConsent.isCurrent ? "current" : "required"} · {connections?.publicConsent.currentTermsVersion ?? "loading"}</p>{connections?.executionControl ? <ExecutionModeControl workspaceId={workspaceId} selectedMode={connections.executionControl.selectedMode} explicitlySelected={connections.executionControl.explicitlySelected} liveOrderGateEnabled={connections.executionControl.liveOrderGateEnabled} publicConsentCurrent={connections.publicConsent.isCurrent} onReviewConsent={() => setIsPublicConsentOpen(true)} /> : null}{publicConnection ? <div className="mt-4 space-y-3 text-sm leading-6 text-muted-foreground"><div className="border border-border bg-background/45 p-3"><p className="font-mono-system text-[10px] uppercase tracking-[0.12em] text-primary">Broker health / {connections?.publicHealth.state ?? "unavailable"}</p><p className="mt-1">{connections?.publicHealth.detail}</p>{connections?.publicHealth.lastSyncedAt ? <p className="mt-2 font-medium text-foreground">Last verified snapshot: {formatTime(connections.publicHealth.lastSyncedAt)}.</p> : null}</div><p>Scope: documented account and portfolio reads remain the reconciliation source. Operator-confirmed equity order status is retrieved only for submitted Camaro intents; no broad order or fill import is asserted.</p>{connections?.latestSnapshot?.providerId === "public" ? <p className="font-medium text-foreground">Normalized snapshot: {connections.latestSnapshot.accounts.length} account(s), {connections.latestSnapshot.positions.length} position(s).</p> : <p>No verified Public snapshot yet. Camaro remains fail-closed until a server-side read succeeds.</p>}<Button type="button" variant="outline" size="sm" onClick={() => void handleSyncPublicReadOnly()} disabled={isSyncingPublic || !connections?.publicConsent.isCurrent} className="rounded-sm font-mono-system text-[10px] uppercase tracking-wide">{isSyncingPublic ? <Loader2 className="animate-spin" /> : <RefreshCw />} Sync read-only state</Button>{!connections?.publicConsent.isCurrent ? <Button type="button" variant="outline" size="sm" onClick={() => setIsPublicConsentOpen(true)} disabled={isEnablingPublic} className="ml-2 rounded-sm font-mono-system text-[10px] uppercase tracking-wide"><Link2 /> Renew consent</Button> : null}</div> : <Button type="button" variant="outline" size="sm" onClick={() => setIsPublicConsentOpen(true)} disabled={isEnablingPublic} className="mt-4 rounded-sm font-mono-system text-[10px] uppercase tracking-wide">{isEnablingPublic ? <Loader2 className="animate-spin" /> : <Link2 />} Review and enable Public</Button>}</div><div className="mt-4 grid gap-3 sm:grid-cols-2">{connections?.catalog.filter((provider) => provider.id !== "public").map((provider) => <ProviderCard key={provider.id} provider={provider as ProviderCatalogItem} isManualImportReady={provider.id === "csv_manual_import" && Boolean(manualImportConnection)} isEnabling={isEnablingImport} onEnableManualImport={() => void handleEnableManualImport()} />)}</div>{manualImportConnection ? <div className="mt-4 border border-primary/30 bg-primary/5 p-4"><div className="flex items-start justify-between gap-3"><div><p className="font-medium">Manual-import setup recorded</p><p className="mt-1 text-sm leading-6 text-muted-foreground">Account, position, order, and fill data remain unavailable until a validated import parser exists.</p></div><Badge variant="outline" className="rounded-sm border-primary/40 font-mono-system text-[10px] uppercase tracking-wide text-primary">{manualImportConnection.status.replaceAll("_", " ")}</Badge></div><Button type="button" variant="outline" size="sm" onClick={() => void handleRecordBoundary(manualImportConnection._id)} disabled={reconcilingId === manualImportConnection._id} className="mt-4 rounded-sm font-mono-system text-[10px] uppercase tracking-wide">{reconcilingId === manualImportConnection._id ? <Loader2 className="animate-spin" /> : <ReceiptText />} Record no-data receipt</Button></div> : <div className="mt-4 border border-dashed border-border bg-muted/20 p-5"><Landmark className="h-5 w-5 text-muted-foreground" /><p className="mt-3 font-medium">CSV / Manual import remains the fallback.</p><p className="mt-2 text-sm leading-6 text-muted-foreground">It creates a workspace-scoped setup record without storing credentials or asserting account data.</p></div>}</CardContent></Card>
      <Card id="camaro-receipts"><CardHeader className="border-b border-border pb-4"><div className="flex items-start justify-between gap-4"><div><p className="font-mono-system text-[10px] uppercase tracking-[0.16em] text-primary">10 / Append-only receipts</p><CardTitle className="mt-2">Operational trail, not a performance ledger.</CardTitle></div><ReceiptText className="h-5 w-5 text-primary" /></div></CardHeader><CardContent className="p-5"><p className="text-sm leading-6 text-muted-foreground">Runtime receipts cover heartbeats, stances, challenges, outcomes, and promotion checks. Existing intent and broker-boundary receipts remain separately auditable.</p><div className="mt-4 divide-y divide-border border border-border">{runtime?.receipts.length ? runtime.receipts.map((receipt) => <div key={receipt._id} className="p-3"><div className="flex items-center justify-between gap-2"><span className="font-mono-system text-[10px] uppercase tracking-[0.12em] text-primary">{receipt.receiptType}</span><span className="font-mono-system text-[10px] uppercase tracking-[0.12em] text-muted-foreground">{formatTime(receipt.createdAt)}</span></div><p className="mt-2 text-sm leading-6 text-muted-foreground">{receipt.summary}</p></div>) : <EmptyPanel icon={ReceiptText} title="No runtime receipts yet" description="Record a heartbeat, stance, outcome, or readiness inspection to start the runtime trail." />}</div><div className="mt-4 border-t border-border pt-4"><p className="font-mono-system text-[10px] uppercase tracking-[0.14em] text-muted-foreground">Prior cockpit audit</p>{cockpit.audit.length ? <div className="mt-3 space-y-2">{cockpit.audit.slice(0, 4).map((entry) => <div key={entry._id} className="border border-border bg-background/45 p-3"><p className="font-mono-system text-[10px] uppercase tracking-[0.12em] text-muted-foreground">{entry.eventType.replaceAll("_", " ")} · {formatTime(entry.createdAt)}</p><p className="mt-1 text-sm leading-6 text-muted-foreground">{entry.summary}</p></div>)}</div> : null}</div></CardContent></Card></section>

    <OpportunityCommandBoard workspaceId={workspaceId} />

    <aside className="flex gap-3 border border-primary/30 bg-primary/5 p-4 text-sm leading-6 text-muted-foreground"><CircleAlert className="mt-0.5 h-5 w-5 shrink-0 text-primary" /><p><span className="font-medium text-foreground">Operational trading software, not investment advice.</span> Camaro only submits a broker order after documented preflight, explicit bounded authority, fresh reconciled state, a separately enabled live gate, and final operator confirmation. It does not promise performance or place autonomous orders.</p></aside>
  </div>;
}

function StatusCell({ label, value, tone }: { label: string; value: string; tone: "primary" | "signal" | "alert" | "muted" }) { return <div className="min-w-24 border border-border bg-background/50 px-3 py-2"><div className="flex items-center gap-2"><StatusDot tone={tone} /><span className="font-mono-system text-[9px] uppercase tracking-[0.12em] text-muted-foreground">{label}</span></div><p className="mt-1 text-sm font-medium capitalize">{value}</p></div>; }
function SpineStep({ label, detail, state }: { label: string; detail: string; state: "represented" | "unconnected" }) { return <div className="border border-border bg-background/45 p-3"><p className="font-mono-system text-[10px] uppercase tracking-[0.12em] text-primary">{label}</p><p className="mt-2 text-xs leading-5 text-muted-foreground">{detail}</p><p className="mt-3 font-mono-system text-[9px] uppercase tracking-[0.1em] text-muted-foreground">{state}</p></div>; }
function RouteBoundary({ label, detail }: { label: string; detail: string }) { return <div className="border border-border bg-background/45 p-3"><p className="font-mono-system text-[10px] uppercase tracking-[0.12em] text-primary">{label}</p><p className="mt-2 text-xs leading-5 text-muted-foreground">{detail}</p></div>; }
function ProviderCard({ provider, isManualImportReady, isEnabling, onEnableManualImport }: { provider: ProviderCatalogItem; isManualImportReady: boolean; isEnabling: boolean; onEnableManualImport: () => void }) { const statusLabel = provider.status === "manual_import" ? "Manual import" : provider.status === "available" ? "Available" : "Coming soon"; const statusClass = provider.status === "manual_import" ? "border-primary/50 text-primary" : provider.status === "available" ? "border-signal/50 text-signal" : "border-border text-muted-foreground"; return <article className="border border-border bg-background/35 p-4"><div className="flex items-start justify-between gap-3"><div><p className="font-medium">{provider.name}</p><p className="mt-1 text-sm leading-5 text-muted-foreground">{provider.description}</p></div><Badge variant="outline" className={`shrink-0 rounded-sm font-mono-system text-[9px] uppercase tracking-[0.1em] ${statusClass}`}>{isManualImportReady ? "Setup ready" : statusLabel}</Badge></div><div className="mt-3 flex flex-wrap gap-1.5">{provider.assetClasses.map((item) => <span key={item} className="border border-border px-2 py-1 font-mono-system text-[9px] uppercase tracking-[0.1em] text-muted-foreground">{item}</span>)}</div><p className="mt-3 text-xs leading-5 text-muted-foreground">{provider.setupGuidance}</p>{provider.status === "manual_import" ? <Button type="button" variant="outline" size="sm" disabled={isEnabling || isManualImportReady} onClick={onEnableManualImport} className="mt-4 rounded-sm font-mono-system text-[10px] uppercase tracking-wide">{isEnabling ? <Loader2 className="animate-spin" /> : <FileUp />}{isManualImportReady ? "Setup recorded" : "Enable setup"}</Button> : <p className="mt-4 font-mono-system text-[10px] uppercase tracking-[0.12em] text-muted-foreground">No connection flow enabled</p>}</article>; }
function WatchlistGroup({ label, entries, onRemove }: { label: string; entries: WatchlistEntry[]; onRemove: (id: Id<"camaroWatchlist">) => void }) { if (entries.length === 0) return null; return <div><p className="mb-2 font-mono-system text-[10px] uppercase tracking-[0.14em] text-muted-foreground">{label}</p><div className="space-y-2">{entries.map((entry) => <div key={entry._id} className="flex items-center justify-between border border-border bg-background/50 px-3 py-2"><div><p className="font-mono-system text-sm font-medium tracking-wide">{entry.symbol}</p><p className="text-[11px] text-muted-foreground">{entry.assetClass} · quote unavailable</p></div><Button type="button" variant="ghost" size="icon" onClick={() => void onRemove(entry._id)} className="h-8 w-8 text-muted-foreground hover:text-alert" aria-label={`Remove ${entry.symbol}`}><Trash2 className="h-4 w-4" /></Button></div>)}</div></div>; }
function GateRow({ icon: Icon, title, detail, state }: { icon: typeof LockKeyhole; title: string; detail: string; state: "blocked" | "unavailable" | "clear" }) { const isBlocked = state === "blocked"; return <div className="flex gap-3 border border-border bg-background/45 p-4"><Icon className="mt-0.5 h-4 w-4 shrink-0 text-primary" /><div className="min-w-0 flex-1"><div className="flex flex-wrap items-center justify-between gap-2"><p className="font-medium">{title}</p><span className={`font-mono-system text-[10px] uppercase tracking-[0.14em] ${isBlocked ? "text-alert" : "text-muted-foreground"}`}>{state}</span></div><p className="mt-1 text-sm leading-6 text-muted-foreground">{detail}</p></div></div>; }
function EmptyPanel({ icon: Icon, title, description }: { icon: typeof ReceiptText; title: string; description: string }) { return <div className="p-6"><Icon className="h-5 w-5 text-muted-foreground" /><p className="mt-3 font-medium">{title}</p><p className="mt-2 text-sm leading-6 text-muted-foreground">{description}</p></div>; }
