import { Button } from "@/components/ui/button";
import Link from "next/link";

export default function AboutPage() {
  const productName = "IGNISpilot";

  return (
    <div className="mx-auto max-w-3xl px-4 py-16 sm:px-6 lg:px-8">
      <p className="text-sm font-semibold uppercase tracking-[0.2em] text-primary">Tactical intelligence, governed</p>
      <h1 className="mb-8 mt-4 font-[family-name:var(--font-heading)] text-3xl font-bold tracking-tight text-foreground sm:text-5xl">
        About {productName}
      </h1>

      <div className="space-y-5 text-lg leading-8 text-muted-foreground">
        <p>
          {productName} is a tactical decision runtime for operators who need independent machine reasoning without surrendering execution control. It combines market inputs, peer stances, memory, and risk context into a clear operational decision.
        </p>
        <p>
          The runtime can publish its own stance, challenge another runtime, manage a position lifecycle, and create execution intent. Authority remains explicit: live orders require separate policy, risk, broker, and live-order gates.
        </p>
        <p>
          Our operating principle is simple: every decision, blocked action, override, and broker fill should leave an inspectable receipt. Intent is useful; reconciled reality is authoritative.
        </p>
      </div>

      {/* CTA */}
      <div className="mt-16 rounded-[2rem] border border-border bg-muted/30 p-8 text-center sm:p-10">
        <h2 className="font-[family-name:var(--font-heading)] text-2xl font-semibold text-foreground">
          Prove the path in simulation.
        </h2>
        <p className="mt-3 text-muted-foreground">
          Evaluate {productName} with dry-run decisions and auditable receipts before enabling execution workflows.
        </p>
        <div className="mt-6 flex flex-col justify-center gap-4 sm:flex-row">
          <Button asChild>
            <Link href="/sign-up">Start Simulation</Link>
          </Button>
          <Button asChild variant="outline">
            <Link href="/pricing">See Pricing</Link>
          </Button>
        </div>
      </div>
    </div>
  );
}
