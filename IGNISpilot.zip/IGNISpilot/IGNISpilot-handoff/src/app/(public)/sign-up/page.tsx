"use client";

import { useAuthActions } from "@convex-dev/auth/react";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import posthog from "posthog-js";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import Link from "next/link";

const BUSINESS_ID = process.env.NEXT_PUBLIC_BUSINESS_ID;
const MINIMUM_PASSWORD_LENGTH = 8;

function getSignUpErrorMessage(error: unknown) {
  const message = error instanceof Error ? error.message : "";

  if (message.includes("Invalid password")) {
    return `Use a password with at least ${MINIMUM_PASSWORD_LENGTH} characters.`;
  }

  if (message.includes("already exists") || message.includes("already in use")) {
    return "An account already exists for this email. Sign in instead.";
  }

  if (message.includes("valid email")) {
    return "Enter a valid email address.";
  }

  if (message.includes("Operator name")) {
    return message;
  }

  return "We couldn’t create your account. Check your details and try again.";
}

export default function SignUpPage() {
  const { signIn } = useAuthActions();
  const router = useRouter();
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    posthog.capture("sign_up_started", {
      $groups: { business: BUSINESS_ID },
    });
  }, []);

  return (
    <div className="flex min-h-[60vh] items-center justify-center px-4 py-16">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl">Get Started</CardTitle>
          <CardDescription>
            Create an account to get started
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form
            className="space-y-4"
            onSubmit={async (e) => {
              e.preventDefault();
              setError("");
              const formData = new FormData(e.currentTarget);

              const email = String(formData.get("email") ?? "").trim();
              const password = String(formData.get("password") ?? "");
              const name = String(formData.get("name") ?? "").trim();

              if (!email) {
                setError("Enter your email address.");
                return;
              }

              if (password.length < MINIMUM_PASSWORD_LENGTH) {
                setError(`Use a password with at least ${MINIMUM_PASSWORD_LENGTH} characters.`);
                return;
              }

              if (name.length > 80) {
                setError("Operator name must be 80 characters or fewer.");
                return;
              }

              setLoading(true);
              try {
                await signIn("password", formData);
                posthog.capture("sign_up_completed", {
                  $groups: { business: BUSINESS_ID },
                });
                router.push("/app");
              } catch (error) {
                setError(getSignUpErrorMessage(error));
              } finally {
                setLoading(false);
              }
            }}
          >
            <div className="space-y-2">
              <Label htmlFor="name">Name</Label>
              <Input
                id="name"
                name="name"
                type="text"
                placeholder="Operator name (optional)"
                autoComplete="name"
                maxLength={80}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                name="email"
                type="email"
                placeholder="you@example.com"
                autoComplete="email"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                name="password"
                type="password"
                placeholder="At least 8 characters"
                autoComplete="new-password"
                minLength={MINIMUM_PASSWORD_LENGTH}
                required
              />
            </div>
            <input name="flow" type="hidden" value="signUp" />
            {error && (
              <p className="text-sm text-destructive" role="alert" aria-live="polite">{error}</p>
            )}
            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? "Creating account..." : "Get Started"}
            </Button>
          </form>
          <p className="mt-4 text-center text-sm text-muted-foreground">
            Already have an account?{" "}
            <Link href="/sign-in" className="font-medium text-primary hover:underline">
              Sign In
            </Link>
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
