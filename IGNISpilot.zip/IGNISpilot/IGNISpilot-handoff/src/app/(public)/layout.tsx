import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";

export default function PublicLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader productName="IGNISpilot" logoUrl={process.env.NEXT_PUBLIC_BRAND_LOGO} />
      <main className="flex-1">{children}</main>
      <SiteFooter
        productName="IGNISpilot"
        footerText="Governed tactical decisions, auditable from stance to broker reality."
      />
    </div>
  );
}
