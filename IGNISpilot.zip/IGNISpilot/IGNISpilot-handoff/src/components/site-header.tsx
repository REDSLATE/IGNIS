"use client";

import { useState } from "react";
import Link from "next/link";
import { useConvexAuth } from "convex/react";
import { Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface SiteHeaderProps {
  productName?: string;
  logoUrl?: string;
  className?: string;
}

const navLinks = [
  { label: "Runtime", href: "/#runtime" },
  { label: "Stances", href: "/#runtime" },
  { label: "Risk", href: "/#console" },
  { label: "Audit", href: "/#console" },
];

export function SiteHeader({ productName = "IGNISpilot", logoUrl, className }: SiteHeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { isAuthenticated } = useConvexAuth();

  return (
    <header className={cn("sticky top-0 z-40 w-full border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80", className)}>
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <Link href="/" className="flex items-center gap-3" aria-label={`${productName} home`}>
          {logoUrl ? <img src={logoUrl} alt="" className="h-9 w-9 rounded-lg object-contain" /> : <img src="/brand/ignispilot-icon-orange.png" alt="" className="h-9 w-9 rounded-lg object-contain" />}
          <span className="font-[family-name:var(--font-heading)] text-lg font-semibold tracking-[-0.04em] text-foreground">IGNIS<span className="font-normal text-muted-foreground">pilot</span></span>
        </Link>

        <nav className="hidden items-center gap-6 lg:flex">
          {navLinks.map((link) => <Link key={link.label} href={link.href} className="font-mono-system text-[11px] uppercase tracking-[0.12em] text-muted-foreground transition-colors hover:text-primary">{link.label}</Link>)}
        </nav>

        <div className="hidden items-center gap-2 md:flex">
          {isAuthenticated ? <Button asChild size="sm" className="rounded-sm"><Link href="/app">Open console</Link></Button> : <><Button asChild variant="ghost" size="sm" className="font-mono-system text-[11px] uppercase tracking-wide"><Link href="/sign-in">Sign in</Link></Button><Button asChild size="sm" className="rounded-sm font-mono-system text-[11px] uppercase tracking-wide"><Link href="/sign-up">Run simulation</Link></Button></>}
        </div>

        <button onClick={() => setMobileMenuOpen((open) => !open)} className="inline-flex items-center justify-center border border-border p-2 text-muted-foreground transition-colors hover:border-primary hover:text-primary md:hidden" aria-label="Toggle menu">
          {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>
      {mobileMenuOpen && <div className="border-t border-border bg-background md:hidden"><nav className="mx-auto max-w-7xl space-y-1 px-4 py-4 sm:px-6">{navLinks.map((link) => <Link key={link.label} href={link.href} onClick={() => setMobileMenuOpen(false)} className="block border border-transparent px-3 py-2 font-mono-system text-xs uppercase tracking-wider text-muted-foreground hover:border-border hover:text-primary">{link.label}</Link>)}<div className="mt-3 border-t border-border pt-3">{isAuthenticated ? <Link href="/app" onClick={() => setMobileMenuOpen(false)} className="block px-3 py-2 font-mono-system text-xs uppercase tracking-wider text-primary">Open console</Link> : <><Link href="/sign-in" onClick={() => setMobileMenuOpen(false)} className="block px-3 py-2 font-mono-system text-xs uppercase tracking-wider text-muted-foreground">Sign in</Link><Link href="/sign-up" onClick={() => setMobileMenuOpen(false)} className="block px-3 py-2 font-mono-system text-xs uppercase tracking-wider text-primary">Run simulation</Link></>}</div></nav></div>}
    </header>
  );
}
