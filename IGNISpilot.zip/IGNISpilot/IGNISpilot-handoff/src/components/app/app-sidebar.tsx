"use client";

import { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { usePathname } from "next/navigation";
import { useAuthActions } from "@convex-dev/auth/react";
import {
  Activity,
  CandlestickChart,
  Link2,
  Settings,
  Users,
  CreditCard,
  ArrowLeft,
  Menu,
  X,
  LogOut,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";

const navItems = [
  { href: "/app", label: "Camaro Cockpit", icon: Activity },
  { href: "/app/live-trade", label: "Manual Live Trade", icon: CandlestickChart },
  { href: "/app#connections", label: "Connections", icon: Link2 },
  { href: "/app/settings", label: "Settings", icon: Settings },
  { href: "/app/settings/team", label: "Team", icon: Users },
  { href: "/app/settings/billing", label: "Billing", icon: CreditCard },
];

export function AppSidebar() {
  const pathname = usePathname();
  const [mobileOpen, setMobileOpen] = useState(false);
  const { signOut } = useAuthActions();

  function isActive(href: string) {
    if (href.includes("#")) {
      return false;
    }
    if (href === "/app") {
      return pathname === "/app";
    }
    return pathname === href;
  }

  const sidebarContent = (
    <div className="flex h-full flex-col">
      {/* App name */}
      <div className="px-4 py-5">
        <Link href="/app" className="flex items-center gap-3" aria-label="IGNISpilot console">
          <Image src="/brand/ignispilot-icon-orange.png" alt="" width={42} height={42} className="rounded-xl border border-primary/20" priority />
          <div>
            <h2 className="font-[family-name:var(--font-heading)] text-lg font-semibold tracking-[-0.04em]">IGNIS<span className="font-normal text-muted-foreground">pilot</span></h2>
            <p className="font-mono-system text-[9px] uppercase tracking-[0.14em] text-primary">Tactical trading runtime</p>
          </div>
        </Link>
      </div>

      <Separator />

      {/* Navigation */}
      <nav className="flex-1 space-y-1 px-3 py-4">
        {navItems.map((item) => {
          const Icon = item.icon;
          const active = isActive(item.href);

          return (
            <Link
              key={item.href}
              href={item.href}
              onClick={() => setMobileOpen(false)}
              className={cn(
                "flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors",
                active
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
              )}
            >
              <Icon className="h-4 w-4 shrink-0" />
              {item.label}
            </Link>
          );
        })}
      </nav>

      <Separator />

      {/* Bottom actions */}
      <div className="space-y-1 px-3 py-4">
        <Link
          href="/"
          onClick={() => setMobileOpen(false)}
          className="flex items-center gap-2 rounded-md px-3 py-2 text-sm text-muted-foreground transition-colors hover:bg-accent hover:text-accent-foreground"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to Site
        </Link>
        <button
          onClick={() => void signOut()}
          className="flex w-full items-center gap-2 rounded-md px-3 py-2 text-sm text-muted-foreground transition-colors hover:bg-accent hover:text-accent-foreground"
        >
          <LogOut className="h-4 w-4" />
          Sign Out
        </button>
      </div>
    </div>
  );

  return (
    <>
      {/* Mobile toggle button */}
      <Button
        variant="ghost"
        size="icon"
        className="fixed left-4 top-4 z-50 md:hidden"
        onClick={() => setMobileOpen(!mobileOpen)}
      >
        {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
      </Button>

      {/* Mobile overlay */}
      {mobileOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/50 md:hidden"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Sidebar — mobile (slide-over) */}
      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-40 w-64 border-r bg-card transition-transform md:hidden",
          mobileOpen ? "translate-x-0" : "-translate-x-full"
        )}
      >
        {sidebarContent}
      </aside>

      {/* Sidebar — desktop (static) */}
      <aside className="hidden w-64 shrink-0 border-r bg-card md:block">
        {sidebarContent}
      </aside>
    </>
  );
}
