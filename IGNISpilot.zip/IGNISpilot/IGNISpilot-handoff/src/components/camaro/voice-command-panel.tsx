"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import type { Id } from "@convex/_generated/dataModel";
import { AudioLines, CheckCircle2, ClipboardCheck, Ear, FileSearch, Mic, MicOff, Radio, ShieldCheck, Volume2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { parseVoiceCommand, selectBritishVoice, speakCamaroResponse, type VoiceCommand } from "@/lib/camaro/voice";

type VoiceCommandPanelProps = {
  workspaceId: Id<"workspaces">;
  watchlist: Array<{ symbol: string }>;
  onHistoricalDryRun: (symbol: string) => Promise<void>;
};

type SpeechRecognitionInstance = {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  onresult: ((event: SpeechRecognitionEvent) => void) | null;
  onerror: ((event: SpeechRecognitionErrorEvent) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
};

type SpeechRecognitionConstructor = new () => SpeechRecognitionInstance;

declare global {
  interface Window {
    SpeechRecognition?: SpeechRecognitionConstructor;
    webkitSpeechRecognition?: SpeechRecognitionConstructor;
  }

  interface SpeechRecognitionEvent extends Event {
    results: { [index: number]: { [index: number]: { transcript: string } }; length: number };
  }

  interface SpeechRecognitionErrorEvent extends Event {
    error: string;
  }
}

function responseFor(command: VoiceCommand, positionsCount: number) {
  if (command.kind === "show_positions") return positionsCount ? `Camaro has ${positionsCount} reconciled position records available for read-only review.` : "Camaro has no reconciled position records available yet.";
  if (command.kind === "inspect_symbol") return `Inspection ready for ${command.symbol}. Camaro will show only existing read-only cockpit records, including any deterministic bearish-pattern research context and its corresponding bullish-pattern research context.`;
  if (command.kind === "show_receipts") return "Receipt trail ready. Camaro will show existing append-only decision and runtime receipts.";
  return `Historical dry run ready${command.symbol ? ` for ${command.symbol}` : ""}. Confirmation creates a receipt only and never sends a broker order.`;
}

export function VoiceCommandPanel({ workspaceId: _workspaceId, watchlist, onHistoricalDryRun }: VoiceCommandPanelProps) {
  const recognitionRef = useRef<SpeechRecognitionInstance | null>(null);
  const [recognitionAvailable, setRecognitionAvailable] = useState<boolean | null>(null);
  const [synthesisAvailable, setSynthesisAvailable] = useState<boolean | null>(null);
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [pendingCommand, setPendingCommand] = useState<VoiceCommand | null>(null);
  const [blockedReason, setBlockedReason] = useState<string | null>(null);
  const [confirmedMessage, setConfirmedMessage] = useState<string | null>(null);
  const [voice, setVoice] = useState<SpeechSynthesisVoice | null>(null);
  const [voiceLabel, setVoiceLabel] = useState("Checking installed voices");
  const [isRunningDryRun, setIsRunningDryRun] = useState(false);

  const defaultSymbol = watchlist[0]?.symbol ?? "CAMARO";
  const positionsCount = 0;
  const parsed = useMemo(() => parseVoiceCommand(transcript), [transcript]);

  useEffect(() => {
    const Recognition = window.SpeechRecognition ?? window.webkitSpeechRecognition;
    setRecognitionAvailable(Boolean(Recognition));
    setSynthesisAvailable("speechSynthesis" in window && typeof SpeechSynthesisUtterance !== "undefined");
    if (!("speechSynthesis" in window)) {
      setVoiceLabel("Text-only responses");
      return;
    }
    const updateVoice = () => {
      const selectedVoice = selectBritishVoice(window.speechSynthesis.getVoices());
      setVoice(selectedVoice);
      setVoiceLabel(selectedVoice ? `${selectedVoice.name} (${selectedVoice.lang})` : "No en-GB system voice installed");
    };
    updateVoice();
    window.speechSynthesis.addEventListener("voiceschanged", updateVoice);
    return () => window.speechSynthesis.removeEventListener("voiceschanged", updateVoice);
  }, []);

  useEffect(() => () => recognitionRef.current?.stop(), []);

  function reviewTranscript() {
    setConfirmedMessage(null);
    if (parsed.status === "blocked") {
      setPendingCommand(null);
      setBlockedReason(parsed.reason);
      return;
    }
    setPendingCommand(parsed.command);
    setBlockedReason(null);
  }

  function startListening() {
    const Recognition = window.SpeechRecognition ?? window.webkitSpeechRecognition;
    if (!Recognition) {
      setRecognitionAvailable(false);
      setBlockedReason("Speech recognition is unavailable in this browser. Type a command for the same confirmation-gated read-only flow.");
      return;
    }
    setBlockedReason(null);
    setConfirmedMessage(null);
    const recognition = new Recognition();
    recognition.lang = "en-GB";
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.onresult = (event) => {
      const lastResult = event.results[event.results.length - 1];
      setTranscript(lastResult[0].transcript.trim());
      setIsListening(false);
    };
    recognition.onerror = (event) => {
      setIsListening(false);
      setBlockedReason(event.error === "not-allowed" ? "Microphone access was not granted. Type a command to continue in text-only mode." : "Camaro could not hear a command. Type it instead to use the same safe review flow.");
    };
    recognition.onend = () => setIsListening(false);
    recognitionRef.current = recognition;
    setIsListening(true);
    recognition.start();
  }

  async function confirmCommand() {
    if (!pendingCommand) return;
    const response = responseFor(pendingCommand, positionsCount);
    if (pendingCommand.kind === "historical_dry_run") {
      setIsRunningDryRun(true);
      try {
        await onHistoricalDryRun(pendingCommand.symbol ?? defaultSymbol);
      } finally {
        setIsRunningDryRun(false);
      }
    } else if (pendingCommand.kind === "show_positions") {
      document.getElementById("camaro-position-state")?.scrollIntoView({ behavior: "smooth", block: "start" });
    } else if (pendingCommand.kind === "inspect_symbol") {
      document.getElementById("camaro-voice-inspection")?.scrollIntoView({ behavior: "smooth", block: "start" });
    } else {
      document.getElementById("camaro-receipts")?.scrollIntoView({ behavior: "smooth", block: "start" });
    }
    setConfirmedMessage(response);
    setPendingCommand(null);
    if (synthesisAvailable) speakCamaroResponse(response, voice);
  }

  return <section aria-label="Camaro voice command interface">
    <Card className="border-primary/35 panel-surface">
      <CardHeader className="border-b border-border pb-4"><div className="flex flex-wrap items-start justify-between gap-3"><div><p className="font-mono-system text-[10px] uppercase tracking-[0.16em] text-primary">Read-only voice console / en-GB preference</p><CardTitle className="mt-2">Speak to Camaro. Review every transcript.</CardTitle></div><div className="flex items-center gap-2"><Badge variant="outline" className="rounded-sm border-signal/50 font-mono-system text-[10px] uppercase tracking-wide text-signal"><ShieldCheck /> Read-only</Badge><Badge variant="outline" className="rounded-sm border-border font-mono-system text-[10px] uppercase tracking-wide text-muted-foreground"><Volume2 /> {voice ? "en-GB selected" : "text fallback"}</Badge></div></div></CardHeader>
      <CardContent className="p-5">
        <p className="max-w-3xl text-sm leading-6 text-muted-foreground">Ask Camaro to show positions, inspect a symbol, show receipts, or run a historical dry run. Voice never enables trading, creates or cancels orders, changes authority or consent, or triggers kill, halt, or flatten actions.</p>
        <div className="mt-4 grid gap-3 lg:grid-cols-[1fr_auto]"><div><Label htmlFor="camaro-voice-transcript">Visible transcript</Label><Input id="camaro-voice-transcript" value={transcript} onChange={(event) => { setTranscript(event.target.value); setPendingCommand(null); setBlockedReason(null); setConfirmedMessage(null); }} placeholder="Try: inspect NVDA" className="mt-1 rounded-sm" /></div><div className="flex items-end gap-2"><Button type="button" variant="outline" onClick={startListening} disabled={recognitionAvailable === false || isListening} className="rounded-sm font-mono-system text-[10px] uppercase tracking-wide">{isListening ? <MicOff className="animate-pulse" /> : <Mic />}{isListening ? "Listening" : "Speak"}</Button><Button type="button" onClick={reviewTranscript} disabled={!transcript.trim()} className="rounded-sm font-mono-system text-[10px] uppercase tracking-wide"><ClipboardCheck /> Review command</Button></div></div>
        <div className="mt-4 grid gap-3 md:grid-cols-2"><div className="border border-border bg-background/45 p-3"><div className="flex items-center gap-2"><Ear className="h-4 w-4 text-primary" /><p className="font-mono-system text-[10px] uppercase tracking-[0.13em] text-muted-foreground">Speech input</p></div><p className="mt-2 text-sm leading-6 text-muted-foreground">{recognitionAvailable === false ? "Unavailable here. Text input remains fully available." : recognitionAvailable === null ? "Checking browser support…" : "Browser-native recognition is ready when microphone permission is granted."}</p></div><div className="border border-border bg-background/45 p-3"><div className="flex items-center gap-2"><AudioLines className="h-4 w-4 text-primary" /><p className="font-mono-system text-[10px] uppercase tracking-[0.13em] text-muted-foreground">Spoken response</p></div><p className="mt-2 text-sm leading-6 text-muted-foreground">{synthesisAvailable === false ? "Unavailable here. Camaro will use text-only responses." : `${voiceLabel}. British feminine voice preference depends on voices installed by this device; Camaro cannot guarantee a system voice.`}</p></div></div>
        {blockedReason ? <div role="alert" className="mt-4 border border-alert/50 bg-alert/10 p-4"><p className="font-mono-system text-[10px] uppercase tracking-[0.14em] text-alert">Voice command blocked</p><p className="mt-2 text-sm leading-6 text-muted-foreground">{blockedReason}</p></div> : null}
        {pendingCommand ? <div className="mt-4 border border-primary/40 bg-primary/5 p-4"><div className="flex items-start gap-3"><FileSearch className="mt-0.5 h-5 w-5 shrink-0 text-primary" /><div className="min-w-0 flex-1"><p className="font-mono-system text-[10px] uppercase tracking-[0.14em] text-primary">Transcript held for confirmation</p><p className="mt-2 font-medium">{pendingCommand.label}{"symbol" in pendingCommand && pendingCommand.symbol ? ` · ${pendingCommand.symbol}` : ""}</p><p className="mt-1 text-sm leading-6 text-muted-foreground">{parsed.status === "ready" ? parsed.summary : "Review the visible transcript before proceeding."}</p><div className="mt-4 flex flex-wrap gap-2"><Button type="button" onClick={() => void confirmCommand()} disabled={isRunningDryRun} className="rounded-sm font-mono-system text-[10px] uppercase tracking-wide"><CheckCircle2 />{isRunningDryRun ? "Creating receipt" : "Confirm read-only action"}</Button><Button type="button" variant="outline" onClick={() => setPendingCommand(null)} className="rounded-sm font-mono-system text-[10px] uppercase tracking-wide">Discard</Button></div></div></div></div> : null}
        {confirmedMessage ? <div role="status" className="mt-4 border border-signal/50 bg-signal/10 p-4"><div className="flex gap-3"><Radio className="mt-0.5 h-5 w-5 shrink-0 text-signal" /><div><p className="font-mono-system text-[10px] uppercase tracking-[0.14em] text-signal">Confirmed response</p><p className="mt-2 text-sm leading-6 text-muted-foreground">{confirmedMessage}</p></div></div></div> : null}
      </CardContent>
    </Card>
  </section>;
}
