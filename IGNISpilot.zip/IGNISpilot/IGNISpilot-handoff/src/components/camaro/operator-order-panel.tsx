"use client";

import { useState } from "react";
import { useAction, useMutation } from "convex/react";
import { api } from "@convex/_generated/api";
import type { Id } from "@convex/_generated/dataModel";
import { AlertTriangle, CheckCircle2, LockKeyhole, RefreshCw, XCircle } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/components/ui/use-toast";
import { normalizeCashEquitySymbol, validateCashEquityIntentForm } from "@/lib/camaro/execution-intent";

type Intent = {
  _id: Id<"camaroExecutionIntents">;
  intentHash: string;
  symbol: string;
  side: "buy" | "sell";
  quantity?: number;
  notional?: number;
  orderType: "market" | "limit";
  limitPrice?: number;
  authorityScope: string;
  orderId?: string;
  preflightStatus: "pending" | "passed" | "failed";
  ownerApprovalStatus: "pending" | "approved" | "rejected";
  riskStatus: "pending" | "passed" | "failed";
  riskSummary: string;
  status: string;
  orderStatus?: string;
  expiresAt: number;
};

function actionableError(error: unknown) {
  const message = error instanceof Error ? error.message : "";
  if (message.includes("Current Public consent")) return "Review and record the current Public disclosure before broker preflight or submission.";
  if (message.includes("OWNER_APPROVAL_REQUIRED")) return "Only a workspace owner can approve this exact immutable intent.";
  return "The requested control did not complete. Review the immutable intent and current execution controls.";
}

function Gate({ label, passed, detail }: { label: string; passed: boolean; detail: string }) {
  return <li className="flex items-start gap-2 border-b border-border/70 py-2 last:border-0"><span className={passed ? "mt-0.5 text-signal" : "mt-0.5 text-alert"}>{passed ? "✓" : "×"}</span><span><strong className="font-mono-system text-[10px] uppercase tracking-wide text-foreground">{label}</strong><span className="block text-xs leading-5 text-muted-foreground">{detail}</span></span></li>;
}

export function OperatorOrderPanel({ workspaceId, liveOrderGateEnabled, publicConsentCurrent, executionMode, intents, onReviewConsent }: { workspaceId: Id<"workspaces">; liveOrderGateEnabled: boolean; publicConsentCurrent: boolean; executionMode: "READ_ONLY" | "PAPER" | "OPERATOR_CONFIRM_REQUIRED" | "LIVE_DISABLED_PENDING_ENABLEMENT"; intents: Intent[]; onReviewConsent: () => void }) {
  const { toast } = useToast();
  const createIntent = useMutation(api.camaroBroker.createManualLiveExecutionIntent);
  const preflight = useAction(api.camaroBroker.preflightPublicExecutionIntent);
  const submit = useAction(api.camaroBroker.submitPublicExecutionIntent);
  const refresh = useAction(api.camaroBroker.refreshPublicExecutionOrder);
  const cancel = useAction(api.camaroBroker.cancelPublicExecutionOrder);
  const [symbol, setSymbol] = useState("AAPL");
  const [side, setSide] = useState<"buy" | "sell">("buy");
  const [amountKind, setAmountKind] = useState<"quantity" | "notional">("quantity");
  const [amount, setAmount] = useState("2");
  const [orderType, setOrderType] = useState<"market" | "limit">("market");
  const [limitPrice, setLimitPrice] = useState("");
  const [authorityScope, setAuthorityScope] = useState("Manual live order entered and confirmed by workspace owner");
  const [busy, setBusy] = useState(false);
  const formError = validateCashEquityIntentForm({ symbol, amount, orderType, limitPrice, authorityScope });

  async function create() {
    if (formError) return;
    setBusy(true);
    try {
      const normalizedSymbol = normalizeCashEquitySymbol(symbol);
      const numericAmount = Number(amount);
      await createIntent({ workspaceId, symbol: normalizedSymbol, side, orderType, limitPrice: orderType === "limit" ? Number(limitPrice) : undefined, authorityScope: authorityScope.trim(), ...(amountKind === "quantity" ? { quantity: numericAmount } : { notional: numericAmount }) });
      toast({ title: "Manual live ticket created", description: "Owner approval is bound to this ticket. Run preflight, review it, then submit live." });
    } catch (error) {
      toast({ variant: "destructive", title: "Unable to record intent", description: actionableError(error) });
    } finally {
      setBusy(false);
    }
  }

  async function run(operation: () => Promise<unknown>, success: string) {
    setBusy(true);
    try {
      await operation();
      toast({ title: success, description: "This is the manual live-order path; no autonomous submission is used." });
    } catch (error) {
      toast({ variant: "destructive", title: "Execution control held", description: actionableError(error) });
    } finally {
      setBusy(false);
    }
  }

  return <section className="panel-surface border border-primary/30 p-5 sm:p-6">
    <div className="flex flex-wrap items-start justify-between gap-3"><div><p className="font-mono-system text-[10px] uppercase tracking-[0.14em] text-primary">Camaro / execution review</p><h2 className="mt-1 font-heading text-xl font-semibold">Manual live Public order ticket</h2><p className="mt-2 max-w-2xl text-sm leading-6 text-muted-foreground">Enter a live cash-equity order as the workspace owner, run broker preflight, review the immutable ticket, and press the final live-submit button. No paper order is created.</p></div><Badge variant="outline" className="rounded-sm border-alert/40 font-mono-system text-[10px] uppercase tracking-wide text-alert">live submission {liveOrderGateEnabled ? "armed" : "disabled by default"}</Badge></div>
    {!publicConsentCurrent ? <div className="mt-4 border border-alert/40 bg-alert/5 p-3 text-sm text-muted-foreground">Current Public consent is required before broker preflight or submission. Live ticket creation and submission remain disabled until consent is current.<Button type="button" variant="outline" size="sm" onClick={onReviewConsent} className="ml-3 rounded-sm font-mono-system text-[10px] uppercase tracking-wide">Review Public consent</Button></div> : null}
    <div className="mt-5 grid gap-3 md:grid-cols-2"><div><Label htmlFor="order-symbol">Symbol</Label><Input id="order-symbol" value={symbol} onChange={(event) => setSymbol(normalizeCashEquitySymbol(event.target.value))} className="mt-1 rounded-sm" /></div><div><Label>Side</Label><Select value={side} onValueChange={(value) => setSide(value as "buy" | "sell")}><SelectTrigger className="mt-1 rounded-sm"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="buy">Buy</SelectItem><SelectItem value="sell">Sell</SelectItem></SelectContent></Select></div><div><Label>Quantity or notional</Label><div className="mt-1 flex gap-2"><Select value={amountKind} onValueChange={(value) => setAmountKind(value as "quantity" | "notional")}><SelectTrigger className="w-32 rounded-sm"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="quantity">Quantity</SelectItem><SelectItem value="notional">Notional</SelectItem></SelectContent></Select><Input value={amount} onChange={(event) => setAmount(event.target.value)} inputMode="decimal" className="rounded-sm" /></div></div><div><Label>Order type</Label><Select value={orderType} onValueChange={(value) => setOrderType(value as "market" | "limit")}><SelectTrigger className="mt-1 rounded-sm"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="market">Market</SelectItem><SelectItem value="limit">Limit</SelectItem></SelectContent></Select></div>{orderType === "limit" ? <div><Label htmlFor="limit-price">Limit price</Label><Input id="limit-price" value={limitPrice} onChange={(event) => setLimitPrice(event.target.value)} inputMode="decimal" className="mt-1 rounded-sm" /></div> : null}<div className="md:col-span-2"><Label htmlFor="authority-scope">Bounded authority scope</Label><Input id="authority-scope" value={authorityScope} onChange={(event) => setAuthorityScope(event.target.value)} maxLength={240} className="mt-1 rounded-sm" /></div></div>
    {formError ? <p className="mt-3 text-sm leading-6 text-alert">{formError}</p> : null}
    <Button type="button" disabled={busy || Boolean(formError)} onClick={() => void create()} className="mt-4 rounded-sm font-mono-system text-[10px] uppercase tracking-wide">Create manual live ticket</Button>
    <div className="mt-6 space-y-4">{intents.map((intent) => {
      const ownerApproved = intent.ownerApprovalStatus === "approved";
      const preflightPassed = intent.preflightStatus === "passed";
      const riskPassed = intent.riskStatus === "passed";
      const submitEnabled = publicConsentCurrent && liveOrderGateEnabled && executionMode === "OPERATOR_CONFIRM_REQUIRED" && ownerApproved && riskPassed && preflightPassed && intent.status === "awaiting_confirmation";
      return <article key={intent._id} className="border border-border bg-background/50 p-4"><div className="flex flex-wrap items-start justify-between gap-3"><div><p className="font-mono-system text-sm tracking-wide">{intent.side.toUpperCase()} {intent.symbol} · {intent.quantity ?? `$${intent.notional}`}</p><p className="mt-1 text-sm text-muted-foreground">{intent.orderType.toUpperCase()}{intent.limitPrice ? ` @ $${intent.limitPrice}` : ""} · DAY · expires {new Date(intent.expiresAt).toLocaleTimeString()}</p></div><Badge variant="outline" className="rounded-sm font-mono-system text-[10px] uppercase tracking-wide">{intent.orderStatus ?? intent.status}</Badge></div><div className="mt-4 grid gap-4 lg:grid-cols-[1fr_1.2fr]"><div className="border border-primary/25 bg-primary/5 p-3"><p className="font-mono-system text-[10px] uppercase tracking-[0.12em] text-primary">Immutable order record</p><dl className="mt-2 space-y-1 text-sm text-muted-foreground"><div><dt className="inline text-foreground">Order ID: </dt><dd className="inline font-mono-system text-xs">{intent.orderId ?? "not assigned"}</dd></div><div><dt className="inline text-foreground">Scope: </dt><dd className="inline">{intent.authorityScope}</dd></div><div><dt className="inline text-foreground">Risk: </dt><dd className="inline">{intent.riskSummary}</dd></div></dl></div><div><p className="font-mono-system text-[10px] uppercase tracking-[0.12em] text-primary">Submission gates</p><ul className="mt-1"><Gate label="Owner confirmation" passed={ownerApproved} detail={ownerApproved ? "The workspace owner created and approved this exact manual ticket." : "Only a workspace owner can create an approved live ticket."} /><Gate label="Risk / sizing" passed={riskPassed} detail={intent.riskSummary} /><Gate label="Broker preflight" passed={preflightPassed} detail={preflightPassed ? "Public preflight receipt recorded." : "Preflight must pass before submission."} /><Gate label="Live server flag" passed={liveOrderGateEnabled && executionMode === "OPERATOR_CONFIRM_REQUIRED"} detail={liveOrderGateEnabled ? "Server flag and operator-required mode detected." : "Disabled by default. No UI action can enable it."} /></ul></div></div><div className="mt-4 flex flex-wrap gap-2"><Button type="button" variant="outline" size="sm" disabled={!publicConsentCurrent || busy || !ownerApproved || intent.status !== "awaiting_confirmation" || intent.preflightStatus !== "pending"} onClick={() => void run(() => preflight({ workspaceId, intentId: intent._id }), "Public preflight passed")} className="rounded-sm font-mono-system text-[10px] uppercase tracking-wide"><CheckCircle2 /> Preflight</Button><Button type="button" variant="outline" size="sm" disabled={!submitEnabled} aria-disabled={!submitEnabled} title="Submission is unavailable until the authorized server live flag and every per-intent gate pass." onClick={() => void run(() => submit({ workspaceId, intentId: intent._id }), "Submission request accepted")} className="rounded-sm font-mono-system text-[10px] uppercase tracking-wide"><LockKeyhole /> {submitEnabled ? "Submit live order" : "Live submit unavailable"}</Button><Button type="button" variant="outline" size="sm" disabled={!publicConsentCurrent || busy || !["submitted", "accepted", "partially_filled", "cancel_pending"].includes(intent.status)} onClick={() => void run(() => refresh({ workspaceId, intentId: intent._id }), "Broker status refreshed")} className="rounded-sm font-mono-system text-[10px] uppercase tracking-wide"><RefreshCw /> Refresh</Button><Button type="button" variant="outline" size="sm" disabled={!publicConsentCurrent || busy || !["submitted", "accepted", "partially_filled"].includes(intent.status)} onClick={() => void run(() => cancel({ workspaceId, intentId: intent._id }), "Cancellation requested")} className="rounded-sm font-mono-system text-[10px] uppercase tracking-wide"><XCircle /> Cancel</Button></div><p className="mt-3 flex gap-2 text-xs leading-5 text-alert"><AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />Creating a ticket does not send an order. The final Submit live order button calls the connected Public broker only after preflight and every server-side live control passes.</p></article>;
    })}</div>
  </section>;
}
