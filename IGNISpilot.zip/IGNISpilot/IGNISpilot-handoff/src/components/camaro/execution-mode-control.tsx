"use client";

import { useState } from "react";
import { useMutation } from "convex/react";
import { api } from "@convex/_generated/api";
import type { Id } from "@convex/_generated/dataModel";
import { LockKeyhole } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/components/ui/use-toast";

const EXECUTION_MODES = [
  { value: "READ_ONLY", label: "Read only" },
  { value: "PAPER", label: "Paper" },
  { value: "OPERATOR_CONFIRM_REQUIRED", label: "Operator confirmation required" },
  { value: "LIVE_DISABLED_PENDING_ENABLEMENT", label: "Live disabled pending enablement" },
] as const;

type ExecutionMode = (typeof EXECUTION_MODES)[number]["value"];

export function ExecutionModeControl({ workspaceId, selectedMode, explicitlySelected, liveOrderGateEnabled, publicConsentCurrent, onReviewConsent }: {
  workspaceId: Id<"workspaces">;
  selectedMode: ExecutionMode;
  explicitlySelected: boolean;
  liveOrderGateEnabled: boolean;
  publicConsentCurrent: boolean;
  onReviewConsent: () => void;
}) {
  const { toast } = useToast();
  const requestMode = useMutation(api.camaroBroker.requestPublicExecutionMode);
  const [mode, setMode] = useState<ExecutionMode>(selectedMode);
  const [isSaving, setIsSaving] = useState(false);
  const consentBlocked = !publicConsentCurrent;

  async function saveMode() {
    if (consentBlocked) {
      toast({ variant: "destructive", title: "Public consent required", description: "Review and record the current Public disclosure before changing authority mode." });
      return;
    }
    setIsSaving(true);
    try {
      await requestMode({ workspaceId, mode });
      toast({ title: "Execution mode recorded", description: "Broker order placement remains disabled." });
    } catch (error) {
      toast({ variant: "destructive", title: "Unable to change execution mode", description: error instanceof Error ? error.message : "Try again." });
    } finally {
      setIsSaving(false);
    }
  }

  return <div className="mt-4 border border-signal/35 bg-signal/5 p-4">
    <div className="flex items-start justify-between gap-3"><div><p className="font-mono-system text-[10px] uppercase tracking-[0.12em] text-signal">Operator-controlled authority</p><p className="mt-1 text-sm leading-6 text-muted-foreground">The operator selects the mode. Seat or role assignment never grants broker authority. Camaro is operational software, not investment advice; the operator remains responsible for confirmations.</p></div><LockKeyhole className="h-5 w-5 shrink-0 text-signal" /></div>
    {consentBlocked ? <div className="mt-3 border border-alert/40 bg-alert/5 p-3 text-sm leading-6 text-muted-foreground"><span className="font-medium text-foreground">Authority controls are held.</span> Record the current Public disclosure before Camaro can accept any authority-mode or execution-control change.<Button type="button" variant="outline" size="sm" onClick={onReviewConsent} className="mt-3 rounded-sm font-mono-system text-[10px] uppercase tracking-wide">Review Public consent</Button></div> : null}
    <div className="mt-3 flex flex-col gap-2 sm:flex-row"><Select value={mode} onValueChange={(value) => setMode(value as ExecutionMode)} disabled={consentBlocked || isSaving}><SelectTrigger className="rounded-sm"><SelectValue /></SelectTrigger><SelectContent>{EXECUTION_MODES.map((option) => <SelectItem key={option.value} value={option.value}>{option.label}</SelectItem>)}</SelectContent></Select><Button type="button" variant="outline" size="sm" onClick={() => void saveMode()} disabled={consentBlocked || isSaving || mode === selectedMode && explicitlySelected} className="rounded-sm font-mono-system text-[10px] uppercase tracking-wide">{isSaving ? "Recording" : "Record mode"}</Button></div>
    <div className="mt-3 flex flex-wrap gap-2"><Badge variant="outline" className="rounded-sm border-signal/40 font-mono-system text-[10px] uppercase tracking-wide text-signal">{explicitlySelected ? "operator selected" : "selection required"}</Badge><Badge variant="outline" className="rounded-sm border-alert/40 font-mono-system text-[10px] uppercase tracking-wide text-alert">consent {publicConsentCurrent ? "current" : "required"}</Badge><Badge variant="outline" className="rounded-sm border-alert/40 font-mono-system text-[10px] uppercase tracking-wide text-alert">live order gate {liveOrderGateEnabled ? "on" : "off"}</Badge></div>
  </div>;
}
