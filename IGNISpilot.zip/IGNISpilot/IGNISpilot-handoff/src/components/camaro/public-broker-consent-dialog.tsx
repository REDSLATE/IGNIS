"use client";

import { useState } from "react";
import { ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";

export const PUBLIC_BROKER_DISCLOSURE = 'The Software is provided on an "as-is" and "as-available" basis. The Company does not guarantee any specific financial outcome, profits, or success rates. You retain ultimate responsibility for monitoring your Brokerage Account activity and managing your risk settings.';

export function PublicBrokerConsentDialog({
  open,
  onOpenChange,
  onConfirm,
  isSaving,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onConfirm: () => Promise<void>;
  isSaving: boolean;
}) {
  const [agreed, setAgreed] = useState(false);

  async function confirm() {
    if (!agreed) return;
    await onConfirm();
    setAgreed(false);
  }

  return <Dialog open={open} onOpenChange={(nextOpen) => { if (!nextOpen) setAgreed(false); onOpenChange(nextOpen); }}>
    <DialogContent className="max-h-[90vh] max-w-xl overflow-y-auto rounded-sm border-primary/40 bg-card p-5 sm:p-6">
      <DialogHeader>
        <div className="flex items-center gap-2 font-mono-system text-[10px] uppercase tracking-[0.16em] text-primary"><ShieldCheck className="h-4 w-4" /> Public broker connection</div>
        <DialogTitle className="font-[family-name:var(--font-heading)] text-2xl tracking-[-0.04em]">Review before enabling read-only connectivity.</DialogTitle>
        <DialogDescription className="leading-6">This consent is recorded server-side for the current disclosure version before Public connectivity can be enabled.</DialogDescription>
      </DialogHeader>
      <div className="space-y-4 border-y border-border py-4 text-sm leading-6 text-muted-foreground">
        <p>{PUBLIC_BROKER_DISCLOSURE}</p>
        <p>You are authorizing Public broker connectivity in read-only mode and retain responsibility for monitoring your Brokerage Account activity.</p>
      </div>
      <label className="flex cursor-pointer items-start gap-3 border border-border bg-background/45 p-4 text-sm leading-6 text-foreground">
        <input
          type="checkbox"
          checked={agreed}
          onChange={(event) => setAgreed(event.target.checked)}
          className="mt-1 h-4 w-4 accent-[var(--primary)]"
        />
        <span>I have read the disclosure and authorize this read-only Public broker connection.</span>
      </label>
      <div className="flex flex-col gap-2 sm:flex-row sm:justify-end">
        <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={isSaving} className="rounded-sm font-mono-system text-[10px] uppercase tracking-wide">Cancel</Button>
        <Button type="button" onClick={() => void confirm()} disabled={!agreed || isSaving} className="rounded-sm font-mono-system text-[10px] uppercase tracking-wide">{isSaving ? "Recording consent…" : "Continue to connect"}</Button>
      </div>
    </DialogContent>
  </Dialog>;
}
