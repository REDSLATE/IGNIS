import Link from "next/link";
import { ShieldCheck } from "lucide-react";
import { cn } from "@/lib/utils";

interface SiteFooterProps {
  productName?: string;
  supportEmail?: string;
  footerText?: string;
  className?: string;
}

export function SiteFooter({ productName = "IGNISpilot", supportEmail = "team@ignispilot.madethis.app", footerText = "Governed tactical decisions, auditable from stance to broker reality.", className }: SiteFooterProps) {
  const currentYear = new Date().getFullYear();
  return <footer className={cn("border-t border-border bg-background", className)}><div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8"><div className="grid gap-10 md:grid-cols-[1.5fr_0.7fr_0.7fr]"><div><div className="flex items-center gap-3"><span className="flex h-8 w-8 items-center justify-center border border-primary text-primary"><ShieldCheck className="h-5 w-5" /></span><p className="font-[family-name:var(--font-heading)] text-xl font-semibold tracking-[-0.04em]">IGNIS<span className="font-normal text-muted-foreground">pilot</span></p></div><p className="mt-4 max-w-sm text-sm leading-6 text-muted-foreground">{footerText}</p></div><div><p className="font-mono-system text-[11px] uppercase tracking-[0.16em] text-primary">Runtime</p><nav className="mt-4 space-y-3"><Link href="/#runtime" className="block text-sm text-muted-foreground transition-colors hover:text-foreground">Capabilities</Link><Link href="/about" className="block text-sm text-muted-foreground transition-colors hover:text-foreground">Doctrine</Link><Link href="/blog" className="block text-sm text-muted-foreground transition-colors hover:text-foreground">Briefings</Link></nav></div><div><p className="font-mono-system text-[11px] uppercase tracking-[0.16em] text-primary">Access</p><nav className="mt-4 space-y-3"><Link href="/sign-in" className="block text-sm text-muted-foreground transition-colors hover:text-foreground">Sign in</Link><Link href="/sign-up" className="block text-sm text-muted-foreground transition-colors hover:text-foreground">Start simulation</Link><a href={`mailto:${supportEmail}`} className="block text-sm text-muted-foreground transition-colors hover:text-foreground">Contact support</a></nav></div></div><div className="mt-12 flex flex-col gap-4 border-t border-border pt-6 sm:flex-row sm:items-center sm:justify-between"><p className="font-mono-system text-[10px] uppercase tracking-wider text-muted-foreground">© {currentYear} {productName}. Built for intent + approval.</p><a href="https://madethis.com" className="inline-flex w-fit items-center border border-border px-3 py-2 font-mono-system text-[10px] uppercase tracking-[0.12em] text-muted-foreground transition-colors hover:border-primary hover:text-primary">Built with MadeThis</a></div></div></footer>;
}
