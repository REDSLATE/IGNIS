export const MAX_AUTHORITY_SCOPE_LENGTH = 240;

export function normalizeCashEquitySymbol(symbol: string) {
  return symbol.trim().toUpperCase();
}

function isPositiveDecimal(value: string) {
  const trimmedValue = value.trim();
  return /^(?:\d+|\d*\.\d+)$/.test(trimmedValue) && Number(trimmedValue) > 0 && Number.isFinite(Number(trimmedValue));
}

export function validateCashEquityIntentForm({ symbol, amount, orderType, limitPrice, authorityScope }: { symbol: string; amount: string; orderType: "market" | "limit"; limitPrice: string; authorityScope: string }) {
  if (!/^[A-Z][A-Z0-9.\-]{0,9}$/.test(normalizeCashEquitySymbol(symbol))) return "Enter a valid U.S. equity or ETF symbol.";
  if (!isPositiveDecimal(amount)) return "Enter a quantity or dollar notional greater than zero.";
  if (orderType === "limit" && !isPositiveDecimal(limitPrice)) return "Enter a limit price greater than zero.";

  const boundedScope = authorityScope.trim();
  if (!boundedScope) return "Describe the bounded authority scope before recording this intent.";
  if (boundedScope.length > MAX_AUTHORITY_SCOPE_LENGTH) return `Keep the authority scope to ${MAX_AUTHORITY_SCOPE_LENGTH} characters or fewer.`;

  return null;
}
