export type VoiceCommand =
  | { kind: "show_positions"; label: "Show positions" }
  | { kind: "inspect_symbol"; label: "Inspect symbol"; symbol: string }
  | { kind: "show_receipts"; label: "Show receipts" }
  | { kind: "historical_dry_run"; label: "Historical dry run"; symbol?: string };

export type VoiceCommandParseResult =
  | { status: "ready"; command: VoiceCommand; summary: string }
  | { status: "blocked"; reason: string };

const BLOCKED_COMMAND_PATTERN = /\b(enable\s+(?:live\s+)?trading|(?:submit|place|create|cancel)\s+(?:an?\s+)?order|change\s+(?:authority|consent)|(?:grant|revoke)\s+(?:authority|consent)|\b(?:kill|halt|flatten)\b)/i;
const SYMBOL_PATTERN = /\b([A-Z]{1,10}(?:[-.][A-Z]{1,10})?)\b/g;
const RESERVED_TOKENS = new Set(["SHOW", "POSITIONS", "POSITION", "INSPECT", "SYMBOL", "RECEIPTS", "RECEIPT", "HISTORICAL", "DRY", "RUN", "SIMULATION", "SIMULATE", "PLEASE", "CAMARO"]);

export function parseVoiceCommand(transcript: string): VoiceCommandParseResult {
  const normalized = transcript.trim().replace(/\s+/g, " ");
  if (!normalized) return { status: "blocked", reason: "Say or type a read-only Camaro command before continuing." };
  if (BLOCKED_COMMAND_PATTERN.test(normalized)) return { status: "blocked", reason: "Voice commands cannot enable trading, handle orders, change authority or consent, or trigger kill, halt, or flatten actions." };

  const symbol = extractSymbol(normalized);
  if (/\b(show|list|read)\b.*\b(position|positions|holding|holdings)\b/i.test(normalized)) {
    return { status: "ready", command: { kind: "show_positions", label: "Show positions" }, summary: "Open the read-only position state." };
  }
  if (/\b(inspect|review|show)\b.*\b(symbol|ticker|asset)\b/i.test(normalized) || (/\b(inspect|review)\b/i.test(normalized) && Boolean(symbol))) {
    if (!symbol) return { status: "blocked", reason: "Name a symbol to inspect, for example: inspect NVDA." };
    return { status: "ready", command: { kind: "inspect_symbol", label: "Inspect symbol", symbol }, summary: `Open the read-only inspection view for ${symbol}.` };
  }
  if (/\b(show|list|read)\b.*\b(receipt|receipts|audit|audits)\b/i.test(normalized)) {
    return { status: "ready", command: { kind: "show_receipts", label: "Show receipts" }, summary: "Open the append-only receipt trail." };
  }
  if (/\b(historical|history)\b.*\b(dry[ -]?run|simulation|simulate|replay)\b|\b(dry[ -]?run|simulation|simulate|replay)\b.*\b(historical|history)\b/i.test(normalized)) {
    return { status: "ready", command: { kind: "historical_dry_run", label: "Historical dry run", ...(symbol ? { symbol } : {}) }, summary: symbol ? `Create a receipt-only historical dry run for ${symbol}.` : "Create a receipt-only historical dry run for the selected symbol." };
  }

  return { status: "blocked", reason: "Camaro voice supports only: show positions, inspect a symbol, show receipts, and historical dry run." };
}

export function extractSymbol(transcript: string) {
  const matches = transcript.toUpperCase().matchAll(SYMBOL_PATTERN);
  for (const match of matches) {
    const candidate = match[1];
    if (!RESERVED_TOKENS.has(candidate)) return candidate;
  }
  return undefined;
}

export function selectBritishVoice(voices: SpeechSynthesisVoice[]) {
  const britishVoices = voices.filter((voice) => voice.lang.toLowerCase().startsWith("en-gb"));
  const feminineHint = /female|woman|zira|hazel|susan|serena|libby|sonia|kate|emma|olivia|samantha/i;
  return britishVoices.find((voice) => feminineHint.test(voice.name)) ?? britishVoices[0] ?? null;
}

export function speakCamaroResponse(text: string, voice: SpeechSynthesisVoice | null) {
  if (typeof window === "undefined" || !("speechSynthesis" in window) || typeof SpeechSynthesisUtterance === "undefined") return false;
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = "en-GB";
  utterance.rate = 0.96;
  utterance.pitch = 1.08;
  if (voice) utterance.voice = voice;
  window.speechSynthesis.speak(utterance);
  return true;
}
