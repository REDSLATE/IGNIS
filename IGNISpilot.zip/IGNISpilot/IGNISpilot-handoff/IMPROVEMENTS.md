# Trading Path Improvements

## What changed

- Added the missing live-readiness variables to `.env.example.template`.
- Added `PUBLIC_ACCOUNT_ID` as the preferred account selector while retaining `PUBLIC_READ_ONLY_WORKSPACE_ID` as a backward-compatible alias.
- Added a complete live activation runbook and machine-readable blocker guide to `README.md`.
- Changed Public preflight to perform one automatic read-only refresh when connectivity is stale or reconciliation is not current.
- Preserved every existing server-side gate, immutable intent, owner approval, risk check, preflight, idempotency, and reconciliation requirement.

## Validation

- `npm test`: 79/79 tests passed.
- TypeScript/build validation could not be completed in this environment because the configured npm registry returned 404 for `zwitch@2.0.4`; dependencies were therefore unavailable. This is an environment/package-mirror issue, not a reported compiler failure in the changed files.

## Required server variables for live operator-confirmed orders

```text
PUBLIC_PERSONAL_SECRET_TOKEN=<secret manager value>
PUBLIC_ACCOUNT_ID=<verified Public account id>
PUBLIC_TRADING_PERMISSION_VERIFIED=true
PUBLIC_PDT_LIVE_CONSTRAINTS_VERIFIED=true
PUBLIC_LIVE_ORDER_GATE_ENABLED=true
```

The workspace owner must additionally record current consent, select `OPERATOR_CONFIRM_REQUIRED`, and explicitly arm the workspace live gate in the application.

## Manual live trading update

- Added an owner-only manual live order ticket that records owner confirmation at creation.
- Removed the redundant second owner-approval click from the manual workflow.
- Preserved separate broker preflight and final live-submit actions.
- Expanded symbol entry from a five-symbol hardcoded list to validated U.S. equity/ETF ticker syntax; broker preflight remains authoritative.
- No paper order is created by the manual live ticket.
