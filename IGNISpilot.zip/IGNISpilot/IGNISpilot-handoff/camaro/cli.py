"""CLI-compatible Camaro execution surface. It never calls Public directly."""
from __future__ import annotations

import argparse
import json
import os
import sys


def execute(args: argparse.Namespace) -> int:
    result = {
        "command": "execute",
        "intent_id": args.intent_id,
        "submitted": False,
        "broker_endpoint_invoked": False,
        "block_reason": "LIVE_FLAG_OFF" if os.getenv("PUBLIC_LIVE_ORDER_GATE_ENABLED") != "true" else "SERVER_EXECUTION_GATE_REQUIRED",
        "detail": "CLI records no broker action; server-side owner approval and policy gates are required.",
    }
    print(json.dumps(result))
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(prog="python -m camaro.cli")
    commands = parser.add_subparsers(dest="verb", required=True)
    execute_parser = commands.add_parser("execute")
    execute_parser.add_argument("--intent-id", required=True)
    execute_parser.set_defaults(handler=execute)
    args = parser.parse_args()
    return args.handler(args)


if __name__ == "__main__":
    sys.exit(main())
