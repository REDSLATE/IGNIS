"""Camaro safe execution command surface."""
