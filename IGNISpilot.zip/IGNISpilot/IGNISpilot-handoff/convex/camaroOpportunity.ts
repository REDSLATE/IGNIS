import { query } from "./_generated/server";
import type { QueryCtx } from "./_generated/server";
import type { Id } from "./_generated/dataModel";
import { getAuthUserId } from "@convex-dev/auth/server";
import { v } from "convex/values";

async function requireMembership(ctx: QueryCtx, workspaceId: Id<"workspaces">) {
  const userId = await getAuthUserId(ctx);
  if (!userId) return null;
  return ctx.db
    .query("workspaceMembers")
    .withIndex("by_workspaceId_userId", (index) => index.eq("workspaceId", workspaceId).eq("userId", userId))
    .unique();
}

export const getCommandBoard = query({
  args: { workspaceId: v.id("workspaces") },
  handler: async (ctx, args) => {
    const membership = await requireMembership(ctx, args.workspaceId);
    if (!membership) return null;

    const [watchlist, intents, audit, receipts, publicConnection, scans, config, kernelUpdates, patterns] = await Promise.all([
      ctx.db.query("camaroWatchlist").withIndex("by_workspaceId", (index) => index.eq("workspaceId", args.workspaceId)).collect(),
      ctx.db.query("camaroIntents").withIndex("by_workspaceId_createdAt", (index) => index.eq("workspaceId", args.workspaceId)).order("desc").take(12),
      ctx.db.query("camaroAudit").withIndex("by_workspaceId_createdAt", (index) => index.eq("workspaceId", args.workspaceId)).order("desc").take(30),
      ctx.db.query("camaroRuntimeReceipts").withIndex("by_workspaceId_createdAt", (index) => index.eq("workspaceId", args.workspaceId)).order("desc").take(30),
      ctx.db.query("camaroProviderConnections").withIndex("by_workspaceId_providerId", (index) => index.eq("workspaceId", args.workspaceId).eq("providerId", "public")).unique(),
      ctx.db.query("camaroOpportunityScans").withIndex("by_workspaceId_createdAt", (index) => index.eq("workspaceId", args.workspaceId)).order("desc").take(24),
      ctx.db.query("camaroOpportunityConfig").withIndex("by_workspaceId", (index) => index.eq("workspaceId", args.workspaceId)).unique(),
      ctx.db.query("camaroAdaptiveKernelUpdates").withIndex("by_workspaceId_createdAt", (index) => index.eq("workspaceId", args.workspaceId)).order("desc").take(1),
      ctx.db.query("camaroPatternResearch").withIndex("by_workspaceId_createdAt", (index) => index.eq("workspaceId", args.workspaceId)).order("desc").take(30),
    ]);

    const latestScanAt = scans[0]?.createdAt;
    const latestOpportunities = latestScanAt ? scans.filter((scan) => scan.createdAt === latestScanAt).sort((left, right) => left.rank - right.rank) : [];

    const brokerFresh = Boolean(publicConnection?.lastSyncedAt && Date.now() - publicConnection.lastSyncedAt <= 15 * 60 * 1000);
    const reconciliationState = brokerFresh ? "recorded" : "unavailable";
    const reconciliationDetail = brokerFresh
      ? "Read-only broker state is recent, but no position-level opportunity contract is connected."
      : "Broker state is missing or stale; reconciliation remains unavailable for decision review.";

    return {
      scan: {
        status: latestOpportunities.length ? "recorded" as const : "unavailable" as const,
        freshness: latestScanAt && Date.now() - latestScanAt <= 15 * 60 * 1000 ? "recent" as const : "unavailable" as const,
        detail: latestOpportunities.length
          ? `OpportunityEngine ranked the full configured universe and sent the top ${config?.topN ?? 0} entries to Forven cognition. Discovery records do not create execution authority.`
          : "The pending OpportunityEngine has not published a ranked scan contract. Watchlist symbols remain visible, but no score, model contribution, direction, or rationale is inferred by this board.",
        watchlist,
        opportunities: latestOpportunities,
        adaptiveKernel: config ? { weights: config.modelWeights, resolvedLoopCount: config.resolvedLoopCount, latestUpdate: kernelUpdates[0] ?? null } : null,
      },
      bearishPatterns: {
        status: patterns.length ? "recorded" as const : "unavailable" as const,
        detail: patterns.length
          ? "Deterministic bearish-chart research is inspectable context only. It never creates a trade signal, investment advice, execution intent, broker call, authority change, or live-order action."
          : "No bearish-pattern research receipt has been recorded. Camaro will not infer a pattern without explicit ordered OHLC research input.",
        records: patterns,
      },
      bullishPatterns: {
        status: patterns.length ? "recorded" as const : "unavailable" as const,
        detail: patterns.length ? "Deterministic bullish-chart research is inspectable context only. It never creates a trade signal, investment advice, execution intent, broker call, authority change, or live-order action." : "No bullish-pattern research receipt has been recorded. Camaro will not infer a pattern without explicit ordered OHLC research input.",
        records: patterns.filter((pattern) => ["double_bottom", "inverse_head_and_shoulders", "falling_wedge"].includes(pattern.pattern)),
      },
      capitalPressure: {
        status: "recorded" as const,
        detail: "CapitalPressure may pair a new discovery plan with a non-executing REDUCE recommendation when its edge exceeds the weakest reconciled expected edge. It will not infer or execute a REDUCE recommendation without those inputs, never closes a position, and never submits a broker order.",
        recommendation: null,
      },
      decisions: intents.map((intent) => {
        const relatedAudit = audit.filter((entry) => entry.intentId === intent._id);
        const relatedRuntimeReceipts = receipts.filter((receipt) => receipt.subjectType === "intent" && receipt.subjectId === intent._id);
        return {
          intent,
          timeline: [
            { stage: "scan", state: intent.strategy ? "recorded" as const : "unavailable" as const, detail: intent.strategy ? `Discovery plan: ${intent.strategy} ${intent.direction ?? ""} at entry zone ${intent.entryZone ?? "unavailable"}.` : "No ranked opportunity record is available for this intent." },
            { stage: "thesis", state: "recorded" as const, detail: intent.thesis },
            { stage: "sizing", state: "unavailable" as const, detail: "No sizing service or account state is connected to this intent." },
            {
              stage: "risk_authority",
              state: intent.riskChecks.some((check) => check.state === "blocked") ? "blocked" as const : "recorded" as const,
              detail: intent.riskChecks.map((check) => `${check.name}: ${check.detail}`).join(" "),
            },
            { stage: "reconciliation", state: reconciliationState, detail: reconciliationDetail },
            {
              stage: "intent",
              state: intent.status === "blocked" ? "blocked" as const : "ready" as const,
              detail: intent.status === "blocked" ? intent.blockedReasons.join(" ") : "Intent remains approval-gated; no broker submission is implied.",
            },
          ],
          receipts: [
            ...relatedAudit.map((entry) => ({ id: entry._id, source: "audit" as const, type: entry.eventType, summary: entry.summary, createdAt: entry.createdAt })),
            ...relatedRuntimeReceipts.map((receipt) => ({ id: receipt._id, source: "runtime" as const, type: receipt.receiptType, summary: receipt.summary, createdAt: receipt.createdAt })),
          ].sort((left, right) => right.createdAt - left.createdAt),
        };
      }),
      replay: {
        status: "available" as const,
        detail: "Historical simulation records a dry-run receipt through the existing credit ledger. It does not enable, create, confirm, submit, or route a broker order.",
      },
    };
  },
});
