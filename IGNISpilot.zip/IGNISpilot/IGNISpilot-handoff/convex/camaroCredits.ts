import { internalMutation, mutation, query } from "./_generated/server";
import type { MutationCtx } from "./_generated/server";
import type { Id } from "./_generated/dataModel";
import { getAuthUserId } from "@convex-dev/auth/server";
import { v } from "convex/values";
import { CAMARO_CREDIT_DOCTRINE, currentCreditPeriod, type CamaroCreditAction } from "./camaroDoctrine";
import { debitOptionalCompute } from "./camaroCreditCore";
import { availableCamaroCreditPacks, findCamaroCreditPack } from "./camaroCreditPacks";

const creditAction = v.union(
  v.literal("historical_simulation"),
  v.literal("extended_replay"),
  v.literal("resolved_outcome_training"),
  v.literal("advanced_challenge_pack")
);

async function requireMembership(ctx: MutationCtx, workspaceId: Id<"workspaces">) {
  const userId = await getAuthUserId(ctx);
  if (!userId) throw new Error("Not authenticated");
  const membership = await ctx.db
    .query("workspaceMembers")
    .withIndex("by_workspaceId_userId", (index) => index.eq("workspaceId", workspaceId).eq("userId", userId))
    .unique();
  if (!membership) throw new Error("Workspace access denied");
  return { userId, membership };
}

export const getOverview = query({
  args: { workspaceId: v.id("workspaces") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return null;
    const membership = await ctx.db.query("workspaceMembers").withIndex("by_workspaceId_userId", (index) => index.eq("workspaceId", args.workspaceId).eq("userId", userId)).unique();
    if (!membership) return null;
    const [balance, entries] = await Promise.all([
      ctx.db.query("camaroCreditBalances").withIndex("by_workspaceId", (index) => index.eq("workspaceId", args.workspaceId)).unique(),
      ctx.db.query("camaroCreditLedger").withIndex("by_workspaceId_createdAt", (index) => index.eq("workspaceId", args.workspaceId)).order("desc").take(20),
    ]);
    const period = currentCreditPeriod();
    const pendingIncludedGrant = balance?.lastIncludedGrantPeriod !== period;
    return {
      availableCredits: (balance?.availableCredits ?? 0) + (pendingIncludedGrant ? CAMARO_CREDIT_DOCTRINE.monthlyIncludedCredits : 0),
      pendingIncludedGrant,
      monthlyIncludedCredits: CAMARO_CREDIT_DOCTRINE.monthlyIncludedCredits,
      actions: Object.entries(CAMARO_CREDIT_DOCTRINE.actions).map(([id, detail]) => ({ id: id as CamaroCreditAction, ...detail })),
      entries,
      creditPacks: availableCamaroCreditPacks().map(({ productId: _productId, ...pack }) => pack),
      includedCapabilities: ["Risk and authority checks", "Broker reconciliation", "Audit receipts", "Position visibility", "Unsafe or unapproved intent blocks"],
    };
  },
});

async function runOptionalAction(
  ctx: MutationCtx,
  args: { workspaceId: Id<"workspaces">; action: CamaroCreditAction; idempotencyKey: string; reference: string; summary: string }
) {
  const { userId } = await requireMembership(ctx, args.workspaceId);
  const charge = await debitOptionalCompute(ctx, { ...args, userId });
  if (charge.state === "insufficient" || charge.alreadyProcessed) return { ...charge, started: false };
  const now = Date.now();
  await ctx.db.insert("camaroRuntimeReceipts", {
    workspaceId: args.workspaceId,
    receiptType: "doctrine_check",
    summary: args.summary,
    subjectType: "runtime",
    subjectId: charge.receiptId,
    createdBy: userId,
    createdAt: now,
  });
  return { ...charge, started: true };
}

export const runHistoricalSimulation = mutation({
  args: { workspaceId: v.id("workspaces"), symbol: v.string(), idempotencyKey: v.string() },
  handler: async (ctx, args) => {
    const symbol = args.symbol.trim().toUpperCase();
    if (!/^[A-Z0-9._-]{1,20}$/.test(symbol)) throw new Error("Provide a valid symbol");
    return runOptionalAction(ctx, { ...args, action: "historical_simulation", reference: symbol, summary: `Historical simulation receipt created for ${symbol}; dry-run only, with no broker execution path.` });
  },
});

export const runExtendedReplay = mutation({
  args: { workspaceId: v.id("workspaces"), idempotencyKey: v.string() },
  handler: async (ctx, args) => runOptionalAction(ctx, { ...args, action: "extended_replay", reference: "cockpit", summary: "Extended replay analysis receipt created; the underlying audit trail remains included and unchanged." }),
});

export const runOutcomeTraining = mutation({
  args: { workspaceId: v.id("workspaces"), idempotencyKey: v.string() },
  handler: async (ctx, args) => runOptionalAction(ctx, { ...args, action: "resolved_outcome_training", reference: "resolved_outcomes", summary: "Resolved-outcome training preparation receipt created; no autonomous execution authority was granted." }),
});

export const runAdvancedChallengePack = mutation({
  args: { workspaceId: v.id("workspaces"), idempotencyKey: v.string() },
  handler: async (ctx, args) => runOptionalAction(ctx, { ...args, action: "advanced_challenge_pack", reference: "runtime_challenge", summary: "Advanced multi-runtime challenge pack receipt created for operator review." }),
});

export const grantManualTopUp = internalMutation({
  args: { workspaceId: v.id("workspaces"), grantedBy: v.id("users"), amount: v.number(), idempotencyKey: v.string(), note: v.string() },
  handler: async (ctx, args) => {
    if (!Number.isInteger(args.amount) || args.amount < 1 || args.amount > 10000) throw new Error("Grant amount must be between 1 and 10000 credits");
    if (!/^[A-Za-z0-9:_-]{12,160}$/.test(args.idempotencyKey)) throw new Error("Provide a valid idempotency key");
    const existing = await ctx.db.query("camaroCreditLedger").withIndex("by_workspaceId_idempotencyKey", (index) => index.eq("workspaceId", args.workspaceId).eq("idempotencyKey", args.idempotencyKey)).unique();
    if (existing) return existing._id;
    const balance = await ctx.db.query("camaroCreditBalances").withIndex("by_workspaceId", (index) => index.eq("workspaceId", args.workspaceId)).unique();
    const now = Date.now();
    const balanceAfter = (balance?.availableCredits ?? 0) + args.amount;
    if (balance) await ctx.db.patch(balance._id, { availableCredits: balanceAfter, updatedAt: now });
    else await ctx.db.insert("camaroCreditBalances", { workspaceId: args.workspaceId, availableCredits: balanceAfter, updatedAt: now });
    const receiptId = await ctx.db.insert("camaroCreditLedger", { workspaceId: args.workspaceId, entryType: "manual_grant", amount: args.amount, balanceAfter, idempotencyKey: args.idempotencyKey, source: "manual_top_up", summary: `Manual credit grant: ${args.note.trim().slice(0, 200) || "operator adjustment"}.`, createdBy: args.grantedBy, createdAt: now });
    await ctx.db.insert("camaroAudit", { workspaceId: args.workspaceId, eventType: "credit_manual_grant", summary: `Manual credit grant of ${args.amount} credits recorded.`, createdBy: args.grantedBy, createdAt: now });
    return receiptId;
  },
});

export const processPlatformCreditOrder = internalMutation({
  args: {
    workspaceId: v.id("workspaces"),
    productId: v.string(),
    orderId: v.string(),
    checkoutSessionId: v.optional(v.string()),
    paymentStatus: v.union(v.literal("paid"), v.literal("completed"), v.literal("pending"), v.literal("canceled")),
  },
  handler: async (ctx, args) => {
    const orderId = args.orderId.trim();
    if (!/^[A-Za-z0-9:_-]{6,200}$/.test(orderId)) throw new Error("Invalid platform order identifier");
    const workspace = await ctx.db.get(args.workspaceId);
    if (!workspace) throw new Error("Workspace not found");
    const now = Date.now();
    const createdBy = workspace.ownerId;
    const audit = async (eventType: string, summary: string) => ctx.db.insert("camaroAudit", { workspaceId: args.workspaceId, eventType, summary, createdBy, createdAt: now });

    if (args.paymentStatus === "pending" || args.paymentStatus === "canceled") {
      await audit(`credit_checkout_${args.paymentStatus}`, `Platform checkout ${args.paymentStatus} for order ${orderId}; no credits granted.`);
      return { state: args.paymentStatus, granted: false };
    }

    const existing = await ctx.db.query("camaroCreditLedger").withIndex("by_platformOrderId", (index) => index.eq("platformOrderId", orderId)).unique();
    if (existing) {
      if (existing.workspaceId !== args.workspaceId) {
        await audit("credit_checkout_workspace_denied", `Platform order ${orderId} was denied because it is already bound to another workspace.`);
        return { state: "wrong_workspace", granted: false };
      }
      await audit("credit_checkout_duplicate", `Duplicate verified platform fulfillment ignored for order ${orderId}.`);
      return { state: "duplicate", granted: false, receiptId: existing._id };
    }

    const pack = findCamaroCreditPack(args.productId.trim());
    if (!pack) {
      await audit("credit_checkout_unknown_pack", `Verified platform order ${orderId} referenced an unavailable or unknown credit pack.`);
      return { state: "unknown_pack", granted: false };
    }

    const balance = await ctx.db.query("camaroCreditBalances").withIndex("by_workspaceId", (index) => index.eq("workspaceId", args.workspaceId)).unique();
    const balanceAfter = (balance?.availableCredits ?? 0) + pack.credits;
    if (balance) await ctx.db.patch(balance._id, { availableCredits: balanceAfter, updatedAt: now });
    else await ctx.db.insert("camaroCreditBalances", { workspaceId: args.workspaceId, availableCredits: balanceAfter, updatedAt: now });
    const receiptId = await ctx.db.insert("camaroCreditLedger", {
      workspaceId: args.workspaceId,
      entryType: "platform_grant",
      amount: pack.credits,
      balanceAfter,
      idempotencyKey: `platform-order:${orderId}`,
      source: "platform_checkout",
      summary: `${pack.credits} credits granted after verified paid platform order ${orderId}.`,
      reference: args.checkoutSessionId,
      packId: pack.id,
      platformOrderId: orderId,
      checkoutSessionId: args.checkoutSessionId,
      actorSource: "platform_fulfillment",
      createdBy,
      createdAt: now,
    });
    await audit("credit_platform_grant", `${pack.credits} credits granted from verified platform order ${orderId}.`);
    return { state: "granted", granted: true, receiptId };
  },
});
