export const CAMARO_CREDIT_DOCTRINE = {
  monthlyIncludedCredits: 100,
  actions: {
    historical_simulation: {
      cost: 4,
      label: "Historical simulation",
      description: "Run a dry-run tactical decision against a recorded market snapshot.",
    },
    extended_replay: {
      cost: 2,
      label: "Extended replay / audit analysis",
      description: "Expand the decision and receipt trail for an operator review.",
    },
    resolved_outcome_training: {
      cost: 8,
      label: "Resolved-outcome model training",
      description: "Prepare a governed training pass from resolved outcomes only.",
    },
    advanced_challenge_pack: {
      cost: 3,
      label: "Advanced multi-runtime challenge pack",
      description: "Create a structured tactical counter-stance package for peer review.",
    },
  },
} as const;

export type CamaroCreditAction = keyof typeof CAMARO_CREDIT_DOCTRINE.actions;

export function currentCreditPeriod(timestamp = Date.now()) {
  const date = new Date(timestamp);
  return `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, "0")}`;
}

export function creditCost(action: CamaroCreditAction) {
  return CAMARO_CREDIT_DOCTRINE.actions[action].cost;
}
