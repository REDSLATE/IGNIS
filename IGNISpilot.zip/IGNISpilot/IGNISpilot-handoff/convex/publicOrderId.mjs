const UUID_V4_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

export function assertPublicOrderId(orderId) {
  if (typeof orderId !== "string" || !UUID_V4_PATTERN.test(orderId)) {
    throw new Error("Public orderId must be a canonical UUID v4.");
  }
  return orderId.toLowerCase();
}

export function createPublicOrderId(randomUUID = globalThis.crypto?.randomUUID?.bind(globalThis.crypto)) {
  if (!randomUUID) throw new Error("Secure UUID generation is unavailable for Public order submission.");
  return assertPublicOrderId(randomUUID());
}

export function createPublicOrderPayload(intent, includeOrderId = true) {
  return {
    ...(includeOrderId ? { orderId: assertPublicOrderId(intent.orderId) } : {}),
    instrument: { symbol: intent.symbol, type: "EQUITY" },
    orderSide: intent.side.toUpperCase(),
    orderType: intent.orderType.toUpperCase(),
    expiration: { timeInForce: "DAY" },
    ...(intent.quantity ? { quantity: String(intent.quantity) } : { amount: String(intent.notional) }),
    ...(intent.orderType === "limit" ? { limitPrice: String(intent.limitPrice) } : {}),
    validateOrder: true,
    useMargin: false,
  };
}

export async function sendPublicJsonRequest(fetchImplementation, url, method, token, payload) {
  return fetchImplementation(url, {
    method,
    headers: { Authorization: `Bearer ${token}`, Accept: "application/json", ...(payload ? { "Content-Type": "application/json" } : {}) },
    body: payload ? JSON.stringify(payload) : undefined,
  });
}
