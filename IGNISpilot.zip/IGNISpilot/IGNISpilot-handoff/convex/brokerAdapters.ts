export type BrokerAssetClass = "equity" | "crypto";

export type BrokerCapability =
  | "read_accounts"
  | "read_positions"
  | "read_orders"
  | "read_fills"
  | "trade_orders"
  | "oauth"
  | "api_key"
  | "personal_access_token"
  | "manual_import";

export type BrokerProviderStatus = "available" | "coming_soon" | "manual_import";

export type NormalizedBalance = {
  currency: string;
  available?: number;
  total?: number;
};

export type NormalizedAccount = {
  externalAccountId: string;
  label?: string;
  accountType?: string;
  balances: NormalizedBalance[];
};

export type NormalizedPosition = {
  externalPositionId?: string;
  symbol: string;
  assetClass: BrokerAssetClass;
  quantity: number;
  averageEntryPrice?: number;
  marketValue?: number;
};

export type NormalizedOrder = {
  externalOrderId: string;
  symbol: string;
  assetClass: BrokerAssetClass;
  side: "buy" | "sell";
  status: string;
  quantity: number;
  filledQuantity?: number;
  submittedAt?: number;
};

export type NormalizedFill = {
  externalFillId: string;
  externalOrderId?: string;
  symbol: string;
  assetClass: BrokerAssetClass;
  side: "buy" | "sell";
  quantity: number;
  price: number;
  filledAt: number;
};

export type NormalizedBrokerSnapshot = {
  providerId: string;
  syncedAt: number;
  accounts: NormalizedAccount[];
  positions: NormalizedPosition[];
  orders: NormalizedOrder[];
  fills: NormalizedFill[];
};

export type ReconciliationResult = {
  status: "unavailable" | "no_data" | "reconciled" | "attention";
  summary: string;
  comparedIntentCount: number;
  externalPositionCount: number;
  externalOrderCount: number;
  discrepancyCount: number;
};

export type ReconciliationIntent = {
  symbol: string;
};

export type BrokerAdapter = {
  id: BrokerProviderId;
  name: string;
  status: BrokerProviderStatus;
  description: string;
  assetClasses: BrokerAssetClass[];
  capabilities: BrokerCapability[];
  connectionMode: "oauth" | "api_key" | "personal_access_token" | "manual_import" | "none";
  setupGuidance: string;
  normalize?: (source: unknown) => NormalizedBrokerSnapshot;
};

export const BROKER_PROVIDER_IDS = [
  "public",
  "alpaca",
  "interactive_brokers",
  "coinbase",
  "kraken",
  "generic_rest",
  "csv_manual_import",
] as const;

export type BrokerProviderId = (typeof BROKER_PROVIDER_IDS)[number];

export const brokerProviderRegistry: Record<BrokerProviderId, BrokerAdapter> = {
  public: {
    id: "public",
    name: "Public.com",
    status: "available",
    description: "Server-only Public account sync with narrowly scoped, operator-confirmed equity order support.",
    assetClasses: ["equity", "crypto"],
    capabilities: ["read_accounts", "read_positions", "personal_access_token", "trade_orders"],
    connectionMode: "personal_access_token",
    setupGuidance: "Public Secret Token stays server-side. Camaro requests no browser credential. Equity orders require current consent, operator-confirm-required mode, fresh reconciliation, Public preflight, an explicit owner-enabled live gate, and final confirmation.",
  },
  alpaca: {
    id: "alpaca",
    name: "Alpaca",
    status: "coming_soon",
    description: "Read-only equities and crypto adapter placeholder.",
    assetClasses: ["equity", "crypto"],
    capabilities: ["read_accounts", "read_positions", "read_orders", "read_fills", "api_key"],
    connectionMode: "api_key",
    setupGuidance: "Direct setup is not implemented. Camaro will request server-side read-only credentials only when this adapter is released.",
  },
  interactive_brokers: {
    id: "interactive_brokers",
    name: "Interactive Brokers",
    status: "coming_soon",
    description: "Read-only equities adapter placeholder.",
    assetClasses: ["equity"],
    capabilities: ["read_accounts", "read_positions", "read_orders", "read_fills", "api_key"],
    connectionMode: "api_key",
    setupGuidance: "Direct setup is not implemented. Camaro will request server-side read-only credentials only when this adapter is released.",
  },
  coinbase: {
    id: "coinbase",
    name: "Coinbase",
    status: "coming_soon",
    description: "Read-only crypto adapter placeholder.",
    assetClasses: ["crypto"],
    capabilities: ["read_accounts", "read_positions", "read_orders", "read_fills", "oauth", "api_key"],
    connectionMode: "oauth",
    setupGuidance: "Direct setup is not implemented. Camaro will request server-side read-only authorization only when this adapter is released.",
  },
  kraken: {
    id: "kraken",
    name: "Kraken",
    status: "coming_soon",
    description: "Read-only crypto adapter placeholder.",
    assetClasses: ["crypto"],
    capabilities: ["read_accounts", "read_positions", "read_orders", "read_fills", "api_key"],
    connectionMode: "api_key",
    setupGuidance: "Direct setup is not implemented. Camaro will request server-side read-only credentials only when this adapter is released.",
  },
  generic_rest: {
    id: "generic_rest",
    name: "Generic REST / API",
    status: "coming_soon",
    description: "Adapter extension point for providers with compatible read-only APIs.",
    assetClasses: ["equity", "crypto"],
    capabilities: ["read_accounts", "read_positions", "read_orders", "read_fills", "oauth", "api_key"],
    connectionMode: "none",
    setupGuidance: "A provider-specific adapter and server-side secret mapping are required before this flow can be enabled.",
  },
  csv_manual_import: {
    id: "csv_manual_import",
    name: "CSV / Manual import",
    status: "manual_import",
    description: "Workspace setup for brokers and exchanges that permit account exports.",
    assetClasses: ["equity", "crypto"],
    capabilities: ["read_accounts", "read_positions", "read_orders", "read_fills", "manual_import"],
    connectionMode: "manual_import",
    setupGuidance: "Manual-import setup records no account data. A future import parser will validate supported exports before normalizing them into Camaro's read-only reconciliation boundary.",
  },
};

export function getBrokerProvider(providerId: BrokerProviderId) {
  return brokerProviderRegistry[providerId];
}

export function reconcileBrokerSnapshot(
  snapshot: NormalizedBrokerSnapshot | null,
  intents: ReconciliationIntent[]
): ReconciliationResult {
  if (!snapshot) {
    return {
      status: "no_data",
      summary: "No external account, position, order, or fill data has been synced. Reconciliation remains unavailable.",
      comparedIntentCount: intents.length,
      externalPositionCount: 0,
      externalOrderCount: 0,
      discrepancyCount: 0,
    };
  }

  const intentSymbols = new Set(intents.map((intent) => intent.symbol.toUpperCase()));
  const unmatchedPositions = snapshot.positions.filter(
    (position) => !intentSymbols.has(position.symbol.toUpperCase())
  );
  const discrepancyCount = unmatchedPositions.length;

  return {
    status: discrepancyCount > 0 ? "attention" : "reconciled",
    summary:
      discrepancyCount > 0
        ? `${discrepancyCount} broker position(s) are not represented by a Camaro intent. Orders and fills were not queried because read permissions and response semantics are not verified.`
        : "Broker positions match Camaro intent symbols. Orders and fills were not queried because read permissions and response semantics are not verified.",
    comparedIntentCount: intents.length,
    externalPositionCount: snapshot.positions.length,
    externalOrderCount: snapshot.orders.length,
    discrepancyCount,
  };
}
