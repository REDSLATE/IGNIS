import type { MutationCtx } from "./_generated/server";
import type { Id } from "./_generated/dataModel";
import { CAMARO_CREDIT_DOCTRINE, creditCost, currentCreditPeriod, type CamaroCreditAction } from "./camaroDoctrine";

type CreditMutationCtx = Pick<MutationCtx, "db">;

export type CreditChargeResult = {
  state: "charged" | "insufficient";
  balance: number;
  required: number;
  receiptId: Id<"camaroCreditLedger">;
  alreadyProcessed: boolean;
};

function validateIdempotencyKey(idempotencyKey: string) {
  if (!/^[A-Za-z0-9:_-]{12,160}$/.test(idempotencyKey)) {
    throw new Error("Provide a valid idempotency key for this credit action");
  }
}

async function writeAuditReceipt(
  ctx: CreditMutationCtx,
  workspaceId: Id<"workspaces">,
  eventType: string,
  summary: string,
  createdBy: Id<"users">,
  createdAt: number
) {
  await ctx.db.insert("camaroAudit", { workspaceId, eventType, summary, createdBy, createdAt });
}

async function ensureIncludedGrant(
  ctx: CreditMutationCtx,
  workspaceId: Id<"workspaces">,
  userId: Id<"users">,
  now: number
) {
  const period = currentCreditPeriod(now);
  const balance = await ctx.db
    .query("camaroCreditBalances")
    .withIndex("by_workspaceId", (index) => index.eq("workspaceId", workspaceId))
    .unique();

  if (balance?.lastIncludedGrantPeriod === period) return balance;

  const nextBalance = (balance?.availableCredits ?? 0) + CAMARO_CREDIT_DOCTRINE.monthlyIncludedCredits;
  if (balance) {
    await ctx.db.patch(balance._id, {
      availableCredits: nextBalance,
      lastIncludedGrantPeriod: period,
      updatedAt: now,
    });
  } else {
    await ctx.db.insert("camaroCreditBalances", {
      workspaceId,
      availableCredits: nextBalance,
      lastIncludedGrantPeriod: period,
      updatedAt: now,
    });
  }

  await ctx.db.insert("camaroCreditLedger", {
    workspaceId,
    entryType: "included_grant",
    amount: CAMARO_CREDIT_DOCTRINE.monthlyIncludedCredits,
    balanceAfter: nextBalance,
    idempotencyKey: `included:${period}`,
    source: "monthly_included",
    summary: `${CAMARO_CREDIT_DOCTRINE.monthlyIncludedCredits} included monthly analysis credits granted for ${period}.`,
    createdBy: userId,
    createdAt: now,
  });
  await writeAuditReceipt(ctx, workspaceId, "credit_included_grant", `Included monthly credit grant posted for ${period}.`, userId, now);

  return { availableCredits: nextBalance, lastIncludedGrantPeriod: period };
}

export async function debitOptionalCompute(
  ctx: CreditMutationCtx,
  args: {
    workspaceId: Id<"workspaces">;
    userId: Id<"users">;
    action: CamaroCreditAction;
    idempotencyKey: string;
    reference?: string;
  }
): Promise<CreditChargeResult> {
  validateIdempotencyKey(args.idempotencyKey);
  const existing = await ctx.db
    .query("camaroCreditLedger")
    .withIndex("by_workspaceId_idempotencyKey", (index) =>
      index.eq("workspaceId", args.workspaceId).eq("idempotencyKey", args.idempotencyKey)
    )
    .unique();

  if (existing) {
    return {
      state: existing.entryType === "blocked" ? "insufficient" : "charged",
      balance: existing.balanceAfter,
      required: creditCost(args.action),
      receiptId: existing._id,
      alreadyProcessed: true,
    };
  }

  const now = Date.now();
  const balance = await ensureIncludedGrant(ctx, args.workspaceId, args.userId, now);
  const required = creditCost(args.action);
  const actionName = CAMARO_CREDIT_DOCTRINE.actions[args.action].label;

  if (balance.availableCredits < required) {
    const receiptId = await ctx.db.insert("camaroCreditLedger", {
      workspaceId: args.workspaceId,
      entryType: "blocked",
      action: args.action,
      amount: 0,
      balanceAfter: balance.availableCredits,
      idempotencyKey: args.idempotencyKey,
      source: "optional_compute",
      summary: `${actionName} was not started: ${required} credits required; ${balance.availableCredits} available.`,
      reference: args.reference,
      createdBy: args.userId,
      createdAt: now,
    });
    await writeAuditReceipt(ctx, args.workspaceId, "credit_action_blocked", `${actionName} was blocked for insufficient credits; no safety gate changed.`, args.userId, now);
    return { state: "insufficient", balance: balance.availableCredits, required, receiptId, alreadyProcessed: false };
  }

  const nextBalance = balance.availableCredits - required;
  const persistedBalance = await ctx.db
    .query("camaroCreditBalances")
    .withIndex("by_workspaceId", (index) => index.eq("workspaceId", args.workspaceId))
    .unique();
  if (!persistedBalance) throw new Error("Credit balance could not be initialized");
  await ctx.db.patch(persistedBalance._id, { availableCredits: nextBalance, updatedAt: now });
  const receiptId = await ctx.db.insert("camaroCreditLedger", {
    workspaceId: args.workspaceId,
    entryType: "debit",
    action: args.action,
    amount: -required,
    balanceAfter: nextBalance,
    idempotencyKey: args.idempotencyKey,
    source: "optional_compute",
    summary: `${required} credits debited for ${actionName}.`,
    reference: args.reference,
    createdBy: args.userId,
    createdAt: now,
  });
  await writeAuditReceipt(ctx, args.workspaceId, "credit_debit", `${required} credits debited for ${actionName}.`, args.userId, now);
  return { state: "charged", balance: nextBalance, required, receiptId, alreadyProcessed: false };
}
