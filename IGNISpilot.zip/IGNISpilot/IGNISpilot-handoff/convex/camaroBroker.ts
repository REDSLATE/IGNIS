// Deployment marker: preserves the current human-approved Public execution-gate source for backend publication.
import { action, mutation, query } from "./_generated/server";
import { api, internal } from "./_generated/api";
import type { MutationCtx } from "./_generated/server";
import type { Id } from "./_generated/dataModel";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";
import {
  BROKER_PROVIDER_IDS,
  brokerProviderRegistry,
  getBrokerProvider,
  reconcileBrokerSnapshot,
} from "./brokerAdapters";
import {
  PUBLIC_BROKER_DISCLOSURE,
  PUBLIC_BROKER_DISCLOSURE_SHA256,
  PUBLIC_BROKER_DISCLOSURE_VERSION,
  PUBLIC_CONNECTION_REFERENCE,
  isCurrentPublicConsent,
} from "./brokerConsent";
import {
  createIntentHash,
  EXECUTION_INTENT_TTL_MS,
  EXECUTION_MODES,
  liveOrderGateEnabled,
  MAX_PUBLIC_ORDER_NOTIONAL,
  MAX_PUBLIC_ORDER_QUANTITY,
} from "./camaroExecution";
import { MAX_AUTHORITY_SCOPE_LENGTH, normalizeCashEquitySymbol } from "../src/lib/camaro/execution-intent";
import { createPublicOrderId } from "./publicOrderId.mjs";

const providerId = v.union(...BROKER_PROVIDER_IDS.map((id) => v.literal(id)));
const executionMode = v.union(...EXECUTION_MODES.map((mode) => v.literal(mode)));

async function recordExecutionReceipt(
  ctx: MutationCtx,
  input: { workspaceId: Id<"workspaces">; eventType: "mode_changed" | "intent_created" | "preflight_passed" | "preflight_failed" | "confirmation_requested" | "owner_approval_recorded" | "confirmation_rejected" | "intent_timed_out" | "execution_blocked" | "live_order_gate_changed"; summary: string; createdBy: Id<"users">; intentId?: Id<"camaroExecutionIntents">; orderId?: string; retryState?: "initial" | "retry" | "duplicate_blocked"; outboundAttemptResult?: "started" | "accepted" | "rejected" | "failed" | "not_sent"; blockReason?: string }
) {
  await ctx.db.insert("camaroExecutionReceipts", { providerId: "public", createdAt: Date.now(), ...input });
}

async function requireMembership(
  ctx: MutationCtx,
  workspaceId: Id<"workspaces">
) {
  const userId = await getAuthUserId(ctx);
  if (!userId) throw new Error("Not authenticated");

  const membership = await ctx.db
    .query("workspaceMembers")
    .withIndex("by_workspaceId_userId", (index) =>
      index.eq("workspaceId", workspaceId).eq("userId", userId)
    )
    .unique();

  if (!membership) throw new Error("Workspace access denied");
  return { userId, membership };
}

async function requireCurrentPublicConsent(
  ctx: MutationCtx,
  workspaceId: Id<"workspaces">,
  userId: Id<"users">
) {
  const latestConsent = await ctx.db
    .query("camaroBrokerConsents")
    .withIndex("by_workspaceId_userId_createdAt", (index) =>
      index.eq("workspaceId", workspaceId).eq("userId", userId)
    )
    .order("desc")
    .first();
  if (!latestConsent || !isCurrentPublicConsent(latestConsent)) {
    throw new Error("Current Public broker consent is required before connectivity can be activated.");
  }
  return latestConsent;
}

async function approvePublicExecutionIntentRecord(
  ctx: MutationCtx,
  args: { workspaceId: Id<"workspaces">; intentHash: string; authorityScope: string }
) {
  const { userId, membership } = await requireMembership(ctx, args.workspaceId);
  if (membership.role !== "owner") throw new Error("OWNER_APPROVAL_REQUIRED: only a workspace owner may approve this immutable execution intent.");
  const intent = await ctx.db.query("camaroExecutionIntents").withIndex("by_workspaceId_intentHash", (index) => index.eq("workspaceId", args.workspaceId).eq("intentHash", args.intentHash)).unique();
  if (!intent) throw new Error("Execution intent was not found.");
  if (intent.authorityScope !== args.authorityScope.trim()) throw new Error("Final confirmation authority scope does not match the immutable intent.");
  if (intent.status !== "awaiting_confirmation" || intent.expiresAt <= Date.now()) throw new Error("INTENT_NOT_APPROVABLE: the immutable intent is no longer awaiting approval.");
  const now = Date.now();
  await ctx.db.patch(intent._id, { ownerApprovalStatus: "approved", ownerApprovedBy: userId, ownerApprovedAt: now });
  await recordExecutionReceipt(ctx, { workspaceId: args.workspaceId, intentId: intent._id, eventType: "owner_approval_recorded", orderId: intent.orderId, summary: `Workspace owner approved immutable intent ${intent.intentHash}; Public submission remains unavailable until every server gate passes.`, createdBy: userId, outboundAttemptResult: "not_sent" });
  return { status: "approved" };
}

export const getConnections = query({
  args: { workspaceId: v.id("workspaces") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return null;

    const membership = await ctx.db
      .query("workspaceMembers")
      .withIndex("by_workspaceId_userId", (index) =>
        index.eq("workspaceId", args.workspaceId).eq("userId", userId)
      )
      .unique();
    if (!membership) return null;

    const [connections, receipts, snapshots, executionSettings, executionReceipts, consents, executionIntents] = await Promise.all([
      ctx.db
        .query("camaroProviderConnections")
        .withIndex("by_workspaceId", (index) => index.eq("workspaceId", args.workspaceId))
        .collect(),
      ctx.db
        .query("camaroReconciliationReceipts")
        .withIndex("by_workspaceId_createdAt", (index) => index.eq("workspaceId", args.workspaceId))
        .order("desc")
        .take(8),
      ctx.db
        .query("camaroBrokerSnapshots")
        .withIndex("by_workspaceId_syncedAt", (index) => index.eq("workspaceId", args.workspaceId))
        .order("desc")
        .take(1),
      ctx.db
        .query("camaroExecutionSettings")
        .withIndex("by_workspaceId_providerId", (index) => index.eq("workspaceId", args.workspaceId).eq("providerId", "public"))
        .unique(),
      ctx.db
        .query("camaroExecutionReceipts")
        .withIndex("by_workspaceId_createdAt", (index) => index.eq("workspaceId", args.workspaceId))
        .order("desc")
        .take(8),
      ctx.db
        .query("camaroBrokerConsents")
        .withIndex("by_workspaceId_userId_createdAt", (index) =>
          index.eq("workspaceId", args.workspaceId).eq("userId", userId)
        )
        .order("desc")
        .take(1),
      ctx.db
        .query("camaroExecutionIntents")
        .withIndex("by_workspaceId_createdAt", (index) => index.eq("workspaceId", args.workspaceId))
        .order("desc")
        .take(8),
    ]);

    const publicConnection = connections.find((connection) => connection.providerId === "public");
    const latestPublicReceipt = receipts.find((receipt) => receipt.providerId === "public");
    const snapshotAgeMs = publicConnection?.lastSyncedAt ? Date.now() - publicConnection.lastSyncedAt : null;
    const health = !publicConnection
      ? { state: "unavailable" as const, detail: "Public read-only monitoring has not been enabled." }
      : publicConnection.status === "sync_unavailable"
        ? { state: "error" as const, detail: "The last Public sync failed or was denied. Existing data is inspection-only." }
        : snapshotAgeMs === null
          ? { state: "unavailable" as const, detail: "Public is enabled, but no verified snapshot has been recorded." }
          : snapshotAgeMs > 15 * 60 * 1000
            ? { state: "stale" as const, detail: "The last verified Public snapshot is older than 15 minutes." }
            : { state: "degraded" as const, detail: "Account and position data are verified. Order and fill reads are intentionally unavailable." };

    return {
      catalog: Object.values(brokerProviderRegistry).map(({ normalize, ...provider }) => provider),
      connections,
      receipts,
      latestSnapshot: snapshots[0] ?? null,
      publicHealth: {
        ...health,
        latestReceiptStatus: latestPublicReceipt?.status ?? null,
        lastSyncedAt: publicConnection?.lastSyncedAt ?? null,
      },
      publicConsent: {
        isCurrent: Boolean(consents[0] && isCurrentPublicConsent(consents[0])),
        currentTermsVersion: PUBLIC_BROKER_DISCLOSURE_VERSION,
        acceptedTermsVersion: consents[0]?.termsVersion ?? null,
      },
      executionControl: {
        selectedMode: executionSettings?.mode ?? "READ_ONLY",
        explicitlySelected: Boolean(executionSettings),
        liveOrderGateEnabled: Boolean(executionSettings?.liveOrderGateEnabled && liveOrderGateEnabled()),
        receipts: executionReceipts,
        intents: executionIntents,
      },
    };
  },
});

export const authorizePublicReadOnlySync = query({
  args: { workspaceId: v.id("workspaces") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return false;
    const membership = await ctx.db
      .query("workspaceMembers")
      .withIndex("by_workspaceId_userId", (index) =>
        index.eq("workspaceId", args.workspaceId).eq("userId", userId)
      )
      .unique();
    if (!membership) return false;
    const consent = await ctx.db
      .query("camaroBrokerConsents")
      .withIndex("by_workspaceId_userId_createdAt", (index) =>
        index.eq("workspaceId", args.workspaceId).eq("userId", userId)
      )
      .order("desc")
      .first();
    return Boolean(consent && isCurrentPublicConsent(consent));
  },
});

export const authorizePublicExecutionAction = query({
  args: { workspaceId: v.id("workspaces"), intentId: v.id("camaroExecutionIntents") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return false;
    const membership = await ctx.db.query("workspaceMembers").withIndex("by_workspaceId_userId", (index) => index.eq("workspaceId", args.workspaceId).eq("userId", userId)).unique();
    if (!membership) return false;
    const consent = await ctx.db.query("camaroBrokerConsents").withIndex("by_workspaceId_userId_createdAt", (index) => index.eq("workspaceId", args.workspaceId).eq("userId", userId)).order("desc").first();
    const intent = await ctx.db.get(args.intentId);
    return Boolean(intent && intent.workspaceId === args.workspaceId && consent && isCurrentPublicConsent(consent));
  },
});

export const recordPublicBrokerConsent = mutation({
  args: { workspaceId: v.id("workspaces"), agreed: v.boolean() },
  handler: async (ctx, args) => {
    const { userId } = await requireMembership(ctx, args.workspaceId);
    if (!args.agreed) throw new Error("Agreement is required before Public broker connectivity can be authorized.");
    const now = Date.now();
    const consentId = await ctx.db.insert("camaroBrokerConsents", {
      workspaceId: args.workspaceId,
      userId,
      providerId: "public",
      connectionReference: PUBLIC_CONNECTION_REFERENCE,
      modeRequested: "read_only",
      termsVersion: PUBLIC_BROKER_DISCLOSURE_VERSION,
      disclosureVersion: PUBLIC_BROKER_DISCLOSURE_VERSION,
      disclosureText: PUBLIC_BROKER_DISCLOSURE,
      disclosureHash: PUBLIC_BROKER_DISCLOSURE_SHA256,
      createdAt: now,
    });
    await ctx.db.insert("camaroAudit", {
      workspaceId: args.workspaceId,
      eventType: "public_broker_consent_recorded",
      summary: `Public broker connectivity consent recorded for ${PUBLIC_BROKER_DISCLOSURE_VERSION}; no credential, secret, or account identifier was stored in the audit trail.`,
      createdBy: userId,
      createdAt: now,
    });
    return consentId;
  },
});

export const requestPublicExecutionMode = mutation({
  args: {
    workspaceId: v.id("workspaces"),
    mode: executionMode,
  },
  handler: async (ctx, args) => {
    const { userId } = await requireMembership(ctx, args.workspaceId);
    await requireCurrentPublicConsent(ctx, args.workspaceId, userId);
    const existing = await ctx.db
      .query("camaroExecutionSettings")
      .withIndex("by_workspaceId_providerId", (index) => index.eq("workspaceId", args.workspaceId).eq("providerId", "public"))
      .unique();
    const now = Date.now();
    if (existing) await ctx.db.patch(existing._id, { mode: args.mode, selectedBy: userId, selectedAt: now, updatedAt: now });
    else await ctx.db.insert("camaroExecutionSettings", { workspaceId: args.workspaceId, providerId: "public", mode: args.mode, selectedBy: userId, selectedAt: now, updatedAt: now });
    await recordExecutionReceipt(ctx, {
      workspaceId: args.workspaceId,
      eventType: "mode_changed",
      summary: `Operator explicitly selected ${args.mode}. Seat and role assignments do not grant broker authority; the live-order gate remains off unless separately enabled.`,
      createdBy: userId,
    });
    return args.mode;
  },
});

export const setPublicLiveOrderGate = mutation({
  args: { workspaceId: v.id("workspaces"), confirmed: v.boolean() },
  handler: async (ctx, args) => {
    const { userId, membership } = await requireMembership(ctx, args.workspaceId);
    if (membership.role !== "owner") throw new Error("Only a workspace owner may change the live-order gate.");
    await requireCurrentPublicConsent(ctx, args.workspaceId, userId);
    if (!args.confirmed) throw new Error("A second explicit confirmation is required to enable the live-order gate.");
    if (!liveOrderGateEnabled()) throw new Error("Live order submission remains unavailable because PUBLIC_LIVE_ORDER_GATE_ENABLED is not true in the server environment.");
    const setting = await ctx.db.query("camaroExecutionSettings").withIndex("by_workspaceId_providerId", (index) => index.eq("workspaceId", args.workspaceId).eq("providerId", "public")).unique();
    if (!setting || setting.mode !== "OPERATOR_CONFIRM_REQUIRED") throw new Error("Select OPERATOR_CONFIRM_REQUIRED before enabling the live-order gate.");
    const now = Date.now();
    await ctx.db.patch(setting._id, { liveOrderGateEnabled: true, liveOrderGateEnabledBy: userId, liveOrderGateEnabledAt: now, updatedAt: now });
    await recordExecutionReceipt(ctx, { workspaceId: args.workspaceId, eventType: "live_order_gate_changed", summary: "Workspace owner explicitly enabled the live-order gate. Each order still requires preflight and final confirmation.", createdBy: userId });
    return true;
  },
});

export const createPublicExecutionIntent = mutation({
  args: {
    workspaceId: v.id("workspaces"),
    symbol: v.string(),
    side: v.union(v.literal("buy"), v.literal("sell")),
    quantity: v.optional(v.number()),
    notional: v.optional(v.number()),
    orderType: v.union(v.literal("market"), v.literal("limit")),
    limitPrice: v.optional(v.number()),
    authorityScope: v.string(),
  },
  handler: async (ctx, args) => {
    const { userId } = await requireMembership(ctx, args.workspaceId);
    const now = Date.now();
    const blockers: string[] = [];
    if (!args.authorityScope.trim()) blockers.push("An explicit operator authority scope is required.");
    if (args.authorityScope.trim().length > MAX_AUTHORITY_SCOPE_LENGTH) blockers.push(`The authority scope must be ${MAX_AUTHORITY_SCOPE_LENGTH} characters or fewer.`);
    const symbol = normalizeCashEquitySymbol(args.symbol);
    const active = await ctx.db.query("camaroExecutionIntents")
      .withIndex("by_workspaceId_symbol_status", (index) => index.eq("workspaceId", args.workspaceId).eq("symbol", symbol).eq("status", "awaiting_confirmation")).first();
    if (active && active.expiresAt > now) blockers.push("A duplicate active execution intent already exists for this symbol.");
    const hasQuantity = Number.isFinite(args.quantity) && (args.quantity ?? 0) > 0;
    const hasNotional = Number.isFinite(args.notional) && (args.notional ?? 0) > 0;
    if (!/^[A-Z][A-Z0-9.\-]{0,9}$/.test(symbol)) blockers.push("Enter a valid U.S. equity or ETF symbol.");
    if (hasQuantity === hasNotional) blockers.push("Provide exactly one positive quantity or dollar notional.");
    if (args.orderType === "limit" && (!args.limitPrice || args.limitPrice <= 0)) blockers.push("A positive limit price is required for limit orders.");
    if (hasQuantity && (args.quantity ?? 0) > MAX_PUBLIC_ORDER_QUANTITY) blockers.push(`Quantity exceeds the ${MAX_PUBLIC_ORDER_QUANTITY}-share tactical sizing limit.`);
    if (hasNotional && (args.notional ?? 0) > MAX_PUBLIC_ORDER_NOTIONAL) blockers.push(`Notional exceeds the $${MAX_PUBLIC_ORDER_NOTIONAL.toLocaleString()} tactical sizing limit.`);
    const expiresAt = now + EXECUTION_INTENT_TTL_MS;
    const intentHash = createIntentHash({ workspaceId: args.workspaceId, symbol, side: args.side, quantity: args.quantity, notional: args.notional, orderType: args.orderType, timeInForce: "day", limitPrice: args.limitPrice, accountReference: "public:server-selected-account", authorityScope: args.authorityScope.trim(), preflightedAt: now, expiresAt });
    const orderId = createPublicOrderId();
    const intentId = await ctx.db.insert("camaroExecutionIntents", {
      workspaceId: args.workspaceId, providerId: "public", intentHash, symbol, side: args.side,
      quantity: args.quantity, notional: args.notional, orderType: args.orderType, timeInForce: "day", limitPrice: args.limitPrice, accountReference: "public:server-selected-account", authorityScope: args.authorityScope.trim(), idempotencyKey: intentHash, orderId,
      preflightStatus: blockers.length ? "failed" : "pending", ownerApprovalStatus: "pending", riskStatus: blockers.length ? "failed" : "passed", riskSummary: blockers.length ? blockers.join(" ") : "Static sizing and duplicate-symbol checks passed. Fresh buying power, broker readiness, reconciliation, permissions, and live controls are revalidated at preflight.", submissionAttemptCount: 0, preflightedAt: now, expiresAt, status: blockers.length ? "blocked" : "awaiting_confirmation", createdBy: userId, createdAt: now,
    });
    await recordExecutionReceipt(ctx, { workspaceId: args.workspaceId, intentId, eventType: "intent_created", orderId, retryState: "initial", outboundAttemptResult: "not_sent", summary: `Immutable intent ${intentHash} recorded with Public orderId ${orderId}. No broker order was submitted.`, createdBy: userId });
    await recordExecutionReceipt(ctx, { workspaceId: args.workspaceId, intentId, eventType: blockers.length ? "preflight_failed" : "confirmation_requested", summary: blockers.length ? `Intent validation rejected: ${blockers.join(" ")}` : `Immutable intent ${intentHash} is ready for owner approval. Broker readiness is checked only at documented preflight.`, createdBy: userId });
    if (blockers.length) await recordExecutionReceipt(ctx, { workspaceId: args.workspaceId, intentId, eventType: "execution_blocked", blockReason: "RISK_OR_READINESS_BLOCKED", summary: `No broker write occurred: ${blockers.join(" ")}`, createdBy: userId });
    return { intentId, intentHash, status: blockers.length ? "blocked" : "awaiting_confirmation", blockers };
  },
});


export const createManualLiveExecutionIntent = mutation({
  args: {
    workspaceId: v.id("workspaces"),
    symbol: v.string(),
    side: v.union(v.literal("buy"), v.literal("sell")),
    quantity: v.optional(v.number()),
    notional: v.optional(v.number()),
    orderType: v.union(v.literal("market"), v.literal("limit")),
    limitPrice: v.optional(v.number()),
    authorityScope: v.string(),
  },
  handler: async (ctx, args) => {
    const { userId, membership } = await requireMembership(ctx, args.workspaceId);
    if (membership.role !== "owner") throw new Error("OWNER_APPROVAL_REQUIRED: only a workspace owner may create a manual live order ticket.");
    await requireCurrentPublicConsent(ctx, args.workspaceId, userId);
    const now = Date.now();
    const blockers: string[] = [];
    const symbol = normalizeCashEquitySymbol(args.symbol);
    if (!args.authorityScope.trim()) blockers.push("An explicit operator authority scope is required.");
    if (args.authorityScope.trim().length > MAX_AUTHORITY_SCOPE_LENGTH) blockers.push(`The authority scope must be ${MAX_AUTHORITY_SCOPE_LENGTH} characters or fewer.`);
    if (!/^[A-Z][A-Z0-9.\-]{0,9}$/.test(symbol)) blockers.push("Enter a valid U.S. equity or ETF symbol.");
    const active = await ctx.db.query("camaroExecutionIntents").withIndex("by_workspaceId_symbol_status", (index) => index.eq("workspaceId", args.workspaceId).eq("symbol", symbol).eq("status", "awaiting_confirmation")).first();
    if (active && active.expiresAt > now) blockers.push("A duplicate active execution intent already exists for this symbol.");
    const hasQuantity = Number.isFinite(args.quantity) && (args.quantity ?? 0) > 0;
    const hasNotional = Number.isFinite(args.notional) && (args.notional ?? 0) > 0;
    if (hasQuantity === hasNotional) blockers.push("Provide exactly one positive quantity or dollar notional.");
    if (args.orderType === "limit" && (!args.limitPrice || args.limitPrice <= 0)) blockers.push("A positive limit price is required for limit orders.");
    if (hasQuantity && (args.quantity ?? 0) > MAX_PUBLIC_ORDER_QUANTITY) blockers.push(`Quantity exceeds the ${MAX_PUBLIC_ORDER_QUANTITY}-share tactical sizing limit.`);
    if (hasNotional && (args.notional ?? 0) > MAX_PUBLIC_ORDER_NOTIONAL) blockers.push(`Notional exceeds the $${MAX_PUBLIC_ORDER_NOTIONAL.toLocaleString()} tactical sizing limit.`);
    const expiresAt = now + EXECUTION_INTENT_TTL_MS;
    const authorityScope = args.authorityScope.trim();
    const intentHash = createIntentHash({ workspaceId: args.workspaceId, symbol, side: args.side, quantity: args.quantity, notional: args.notional, orderType: args.orderType, timeInForce: "day", limitPrice: args.limitPrice, accountReference: "public:server-selected-account", authorityScope, preflightedAt: now, expiresAt });
    const orderId = createPublicOrderId();
    const intentId = await ctx.db.insert("camaroExecutionIntents", {
      workspaceId: args.workspaceId, providerId: "public", intentHash, symbol, side: args.side, quantity: args.quantity, notional: args.notional, orderType: args.orderType, timeInForce: "day", limitPrice: args.limitPrice, accountReference: "public:server-selected-account", authorityScope, idempotencyKey: intentHash, orderId,
      preflightStatus: blockers.length ? "failed" : "pending", ownerApprovalStatus: blockers.length ? "pending" : "approved", ownerApprovedBy: blockers.length ? undefined : userId, ownerApprovedAt: blockers.length ? undefined : now, riskStatus: blockers.length ? "failed" : "passed", riskSummary: blockers.length ? blockers.join(" ") : "Manual owner ticket validated. Fresh buying power, broker readiness, reconciliation, permissions, and live controls are revalidated at preflight.", submissionAttemptCount: 0, preflightedAt: now, expiresAt, status: blockers.length ? "blocked" : "awaiting_confirmation", createdBy: userId, createdAt: now,
    });
    await recordExecutionReceipt(ctx, { workspaceId: args.workspaceId, intentId, eventType: "intent_created", orderId, retryState: "initial", outboundAttemptResult: "not_sent", summary: `Manual live ticket ${intentHash} recorded with Public orderId ${orderId}. No broker order was submitted.`, createdBy: userId });
    if (!blockers.length) await recordExecutionReceipt(ctx, { workspaceId: args.workspaceId, intentId, eventType: "owner_approval_recorded", orderId, outboundAttemptResult: "not_sent", summary: `Workspace owner created and approved manual live ticket ${intentHash}. Preflight and final submit are still required.`, createdBy: userId });
    if (blockers.length) await recordExecutionReceipt(ctx, { workspaceId: args.workspaceId, intentId, eventType: "execution_blocked", blockReason: "RISK_OR_READINESS_BLOCKED", summary: `No broker write occurred: ${blockers.join(" ")}`, createdBy: userId });
    return { intentId, intentHash, status: blockers.length ? "blocked" : "awaiting_confirmation", blockers };
  },
});

export const approvePublicExecutionIntent = mutation({
  args: { workspaceId: v.id("workspaces"), intentHash: v.string(), authorityScope: v.string() },
  handler: (ctx, args) => approvePublicExecutionIntentRecord(ctx, args),
});

// Compatibility alias: this records owner approval only; Public submission remains server-gated.
export const confirmPublicExecutionIntent = mutation({
  args: { workspaceId: v.id("workspaces"), intentHash: v.string(), authorityScope: v.string() },
  handler: (ctx, args) => approvePublicExecutionIntentRecord(ctx, args),
});

export const submitPublicExecutionIntent = action({
  args: { workspaceId: v.id("workspaces"), intentId: v.id("camaroExecutionIntents") },
  handler: async (ctx, args): Promise<{ status: string }> => {
    const userId = await getAuthUserId(ctx);
    if (!userId || !await ctx.runQuery(internal.camaroBrokerInternal.authorizeExecutionAction, { ...args, userId })) {
      throw new Error("AUTHORITY_CONSENT_REQUIRED: current Public consent and workspace access are required.");
    }
    return ctx.runAction(internal.publicTrading.submit as any, { intentId: args.intentId }) as Promise<{ status: string }>;
  },
});

export const preflightPublicExecutionIntent = action({
  args: { workspaceId: v.id("workspaces"), intentId: v.id("camaroExecutionIntents") },
  handler: async (ctx, args): Promise<{ accepted: boolean }> => {
    const userId = await getAuthUserId(ctx);
    if (!userId || !await ctx.runQuery(internal.camaroBrokerInternal.authorizeExecutionAction, { ...args, userId })) throw new Error("Current Public consent and workspace access are required.");
    return ctx.runAction(internal.publicTrading.preflight as any, { intentId: args.intentId }) as Promise<{ accepted: boolean }>;
  },
});

export const refreshPublicExecutionOrder = action({
  args: { workspaceId: v.id("workspaces"), intentId: v.id("camaroExecutionIntents") },
  handler: async (ctx, args): Promise<{ status: string }> => {
    const intent = await ctx.runQuery(internal.camaroBrokerInternal.getExecutionIntentForBroker as any, { intentId: args.intentId }) as any;
    if (!intent || intent.intent.workspaceId !== args.workspaceId) throw new Error("Execution intent was not found.");
    const userId = await getAuthUserId(ctx);
    if (!userId || !await ctx.runQuery(internal.camaroBrokerInternal.authorizeExecutionAction, { ...args, userId })) throw new Error("Current Public consent and workspace access are required.");
    return ctx.runAction(internal.publicTrading.refreshStatus as any, { intentId: args.intentId }) as Promise<{ status: string }>;
  },
});

export const cancelPublicExecutionOrder = action({
  args: { workspaceId: v.id("workspaces"), intentId: v.id("camaroExecutionIntents") },
  handler: async (ctx, args): Promise<{ status: string }> => {
    const intent = await ctx.runQuery(internal.camaroBrokerInternal.getExecutionIntentForBroker as any, { intentId: args.intentId }) as any;
    if (!intent || intent.intent.workspaceId !== args.workspaceId) throw new Error("Execution intent was not found.");
    const userId = await getAuthUserId(ctx);
    if (!userId || !await ctx.runQuery(internal.camaroBrokerInternal.authorizeExecutionAction, { ...args, userId })) throw new Error("Current Public consent and workspace access are required.");
    return ctx.runAction(internal.publicTrading.cancel as any, { intentId: args.intentId }) as Promise<{ status: string }>;
  },
});

export const enablePublicReadOnly = mutation({
  args: { workspaceId: v.id("workspaces") },
  handler: async (ctx, args) => {
    const { userId } = await requireMembership(ctx, args.workspaceId);
    await requireCurrentPublicConsent(ctx, args.workspaceId, userId);
    const provider = getBrokerProvider("public");
    const existing = await ctx.db
      .query("camaroProviderConnections")
      .withIndex("by_workspaceId_providerId", (index) => index.eq("workspaceId", args.workspaceId).eq("providerId", "public"))
      .unique();
    const now = Date.now();

    if (existing) {
      await ctx.db.patch(existing._id, { status: "not_connected", updatedAt: now });
      return existing._id;
    }

    const connectionId = await ctx.db.insert("camaroProviderConnections", {
      workspaceId: args.workspaceId,
      providerId: provider.id,
      providerName: provider.name,
      connectionMode: "personal_access_token",
      status: "not_connected",
      createdBy: userId,
      createdAt: now,
      updatedAt: now,
    });
    await ctx.db.insert("camaroAudit", {
      workspaceId: args.workspaceId,
      eventType: "public_read_only_connection_enabled",
      summary: "Public.com read-only connector was enabled. No Public credential was requested, returned, or stored in the workspace.",
      createdBy: userId,
      createdAt: now,
    });
    return connectionId;
  },
});

export const enableManualImport = mutation({
  args: { workspaceId: v.id("workspaces"), providerId },
  handler: async (ctx, args) => {
    const { userId } = await requireMembership(ctx, args.workspaceId);
    const provider = getBrokerProvider(args.providerId);
    if (provider.connectionMode !== "manual_import") {
      throw new Error("This provider does not have an enabled connection flow.");
    }

    const existing = await ctx.db
      .query("camaroProviderConnections")
      .withIndex("by_workspaceId_providerId", (index) =>
        index.eq("workspaceId", args.workspaceId).eq("providerId", args.providerId)
      )
      .unique();
    const now = Date.now();

    if (existing) {
      await ctx.db.patch(existing._id, {
        status: "manual_import_ready",
        updatedAt: now,
      });
      return existing._id;
    }

    const connectionId = await ctx.db.insert("camaroProviderConnections", {
      workspaceId: args.workspaceId,
      providerId: provider.id,
      providerName: provider.name,
      connectionMode: provider.connectionMode,
      status: "manual_import_ready",
      createdBy: userId,
      createdAt: now,
      updatedAt: now,
    });

    await ctx.db.insert("camaroAudit", {
      workspaceId: args.workspaceId,
      eventType: "broker_manual_import_enabled",
      summary: "CSV / Manual import setup enabled. No broker credentials or account data were stored.",
      createdBy: userId,
      createdAt: now,
    });

    return connectionId;
  },
});

export const recordReconciliationBoundary = mutation({
  args: { connectionId: v.id("camaroProviderConnections") },
  handler: async (ctx, args) => {
    const connection = await ctx.db.get(args.connectionId);
    if (!connection) throw new Error("Provider connection not found");
    const { userId } = await requireMembership(ctx, connection.workspaceId);

    const intents = await ctx.db
      .query("camaroIntents")
      .withIndex("by_workspaceId_createdAt", (index) => index.eq("workspaceId", connection.workspaceId))
      .collect();
    const result = reconcileBrokerSnapshot(null, intents.map((intent) => ({ symbol: intent.symbol })));
    const now = Date.now();

    const receiptId = await ctx.db.insert("camaroReconciliationReceipts", {
      workspaceId: connection.workspaceId,
      connectionId: connection._id,
      providerId: connection.providerId,
      ...result,
      createdBy: userId,
      createdAt: now,
    });

    await ctx.db.patch(connection._id, { status: "sync_unavailable", updatedAt: now });
    await ctx.db.insert("camaroAudit", {
      workspaceId: connection.workspaceId,
      eventType: "broker_reconciliation_no_data",
      summary: "Reconciliation receipt recorded: no external broker data is available to compare.",
      createdBy: userId,
      createdAt: now,
    });

    return receiptId;
  },
});

export const syncPublicReadOnly = action({
  args: { workspaceId: v.id("workspaces") },
  handler: async (ctx, args): Promise<Id<"camaroProviderConnections"> | null> => {
    const authorized = await ctx.runQuery(api.camaroBroker.authorizePublicReadOnlySync, args);
    if (!authorized) throw new Error("Current Public broker consent is required before read-only sync can run.");
    return ctx.runAction(internal.publicConnector.syncReadOnly, args);
  },
});
