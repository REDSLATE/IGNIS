const MAX_STALE_MS = 15 * 60 * 1000;
const TROUGH_TOLERANCE = 0.03;
const INVALIDATION_BUFFER = 0.01;

function clampConfidence(value) {
  return Math.round(Math.max(0, Math.min(1, value)) * 100) / 100;
}

function freshnessFor(bars, now) {
  return now - bars[bars.length - 1].timestamp <= MAX_STALE_MS
    ? "recent"
    : "stale";
}

function noPattern(pattern, latestClose, freshness, detail) {
  return {
    pattern,
    state: "blocked",
    confidence: 0,
    freshness,
    latestClose,
    detail,
    criteria: [{ label: "Evidence", met: false, detail }],
  };
}

function isFiniteBar(bar) {
  return (
    Number.isFinite(bar.timestamp) &&
    Number.isFinite(bar.high) &&
    Number.isFinite(bar.low) &&
    Number.isFinite(bar.close) &&
    bar.high >= bar.low
  );
}

function regression(points) {
  const averageIndex =
    points.reduce((total, point) => total + point.index, 0) / points.length;
  const averageValue =
    points.reduce((total, point) => total + point.value, 0) / points.length;
  const denominator = points.reduce(
    (total, point) => total + (point.index - averageIndex) ** 2,
    0,
  );
  const slope =
    denominator === 0
      ? 0
      : points.reduce(
          (total, point) =>
            total + (point.index - averageIndex) * (point.value - averageValue),
          0,
        ) / denominator;
  return {
    slope,
    at: (index) => averageValue + slope * (index - averageIndex),
  };
}

export function assessBullishPatterns(bars, now = Date.now()) {
  if (bars.length === 0) return [];
  const latest = bars[bars.length - 1];
  const freshness = freshnessFor(bars, now);
  if (!bars.every(isFiniteBar)) {
    return ["double_bottom", "inverse_head_and_shoulders", "falling_wedge"].map(
      (pattern) =>
        noPattern(
          pattern,
          latest.close,
          freshness,
          "Malformed OHLC research input was blocked; no pattern conclusion was recorded.",
        ),
    );
  }
  return [
    assessDoubleBottom(bars, freshness),
    assessInverseHeadAndShoulders(bars, freshness),
    assessFallingWedge(bars, freshness),
  ];
}

function assessDoubleBottom(bars, freshness) {
  const latest = bars[bars.length - 1];
  if (bars.length < 5)
    return noPattern(
      "double_bottom",
      latest.close,
      freshness,
      "At least five ordered bars are required to inspect two troughs and a neckline.",
    );
  const window = bars.slice(-5);
  const [firstTrough, necklineBar, secondTrough] = window;
  const troughDifference =
    Math.abs(firstTrough.low - secondTrough.low) /
    Math.max(firstTrough.low, secondTrough.low);
  const troughsComparable = troughDifference <= TROUGH_TOLERANCE;
  const neckline = necklineBar.high;
  const invalidation =
    Math.min(firstTrough.low, secondTrough.low) * (1 - INVALIDATION_BUFFER);
  const brokeNeckline = latest.close > neckline;
  const invalidated =
    latest.low <= invalidation || latest.close <= invalidation;
  const state = invalidated
    ? "invalidated"
    : troughsComparable && brokeNeckline
      ? "confirmed"
      : troughsComparable
        ? "forming"
        : "blocked";
  const criteria = [
    {
      label: "Comparable troughs",
      met: troughsComparable,
      detail: `Trough separation ${(troughDifference * 100).toFixed(1)}% (maximum ${(TROUGH_TOLERANCE * 100).toFixed(0)}%).`,
    },
    {
      label: "Neckline breakout",
      met: brokeNeckline,
      detail: `Latest close ${latest.close.toFixed(2)} versus neckline ${neckline.toFixed(2)}.`,
    },
    {
      label: "Invalidation",
      met: invalidated,
      detail: `Invalidation below ${invalidation.toFixed(2)}; latest low ${latest.low.toFixed(2)}.`,
    },
  ];
  const detail =
    state === "confirmed"
      ? "Double Bottom neckline breakout is recorded as bullish research context only; it does not create a signal, advice, intent, or order."
      : state === "invalidated"
        ? "Double Bottom structure was invalidated below its trough buffer; this is an append-only research record."
        : state === "forming"
          ? "Double Bottom geometry is forming but remains unconfirmed until a close breaks the neckline."
          : "Double Bottom evidence is ambiguous and was blocked from research promotion.";
  return {
    pattern: "double_bottom",
    state,
    confidence: clampConfidence(
      troughsComparable ? (brokeNeckline ? 0.78 : 0.52) : 0.18,
    ),
    freshness,
    necklineOrSupport: neckline,
    invalidationLevel: invalidation,
    latestClose: latest.close,
    detail,
    criteria,
  };
}

function assessInverseHeadAndShoulders(bars, freshness) {
  const latest = bars[bars.length - 1];
  if (bars.length < 7)
    return noPattern(
      "inverse_head_and_shoulders",
      latest.close,
      freshness,
      "At least seven ordered bars are required to inspect inverse shoulders, head, and neckline.",
    );
  const window = bars.slice(-7);
  const leftShoulder = window[0];
  const leftPeak = window[1];
  const head = window[2];
  const rightPeak = window[3];
  const rightShoulder = window[4];
  const neckline = (leftPeak.high + rightPeak.high) / 2;
  const shoulderDifference =
    Math.abs(leftShoulder.low - rightShoulder.low) /
    Math.max(leftShoulder.low, rightShoulder.low);
  const shouldersComparable = shoulderDifference <= 0.05;
  const headDominant =
    head.low < leftShoulder.low && head.low < rightShoulder.low;
  const invalidation = head.low * (1 - INVALIDATION_BUFFER);
  const brokeNeckline = latest.close > neckline;
  const invalidated =
    latest.low <= invalidation || latest.close <= invalidation;
  const geometry = shouldersComparable && headDominant;
  const state = invalidated
    ? "invalidated"
    : geometry && brokeNeckline
      ? "confirmed"
      : geometry
        ? "forming"
        : "blocked";
  const criteria = [
    {
      label: "Shoulder symmetry",
      met: shouldersComparable,
      detail: `Shoulder separation ${(shoulderDifference * 100).toFixed(1)}% (maximum 5%).`,
    },
    {
      label: "Head dominance",
      met: headDominant,
      detail: `Head ${head.low.toFixed(2)} versus shoulders ${leftShoulder.low.toFixed(2)} / ${rightShoulder.low.toFixed(2)}.`,
    },
    {
      label: "Neckline breakout",
      met: brokeNeckline,
      detail: `Latest close ${latest.close.toFixed(2)} versus neckline ${neckline.toFixed(2)}.`,
    },
    {
      label: "Invalidation",
      met: invalidated,
      detail: `Invalidation below ${invalidation.toFixed(2)}; latest low ${latest.low.toFixed(2)}.`,
    },
  ];
  const detail =
    state === "confirmed"
      ? "Inverse Head & Shoulders neckline breakout is research-only context; Camaro cannot convert it into advice, intent, authority, or execution."
      : state === "invalidated"
        ? "Inverse Head & Shoulders structure was invalidated below the head buffer; this is an append-only research record."
        : state === "forming"
          ? "Inverse Head & Shoulders geometry is forming but remains unconfirmed until a close breaks the neckline."
          : "Inverse Head & Shoulders geometry is ambiguous and was blocked from research promotion.";
  return {
    pattern: "inverse_head_and_shoulders",
    state,
    confidence: clampConfidence(
      geometry ? (brokeNeckline ? 0.81 : 0.56) : 0.17,
    ),
    freshness,
    necklineOrSupport: neckline,
    invalidationLevel: invalidation,
    latestClose: latest.close,
    detail,
    criteria,
  };
}

function assessFallingWedge(bars, freshness) {
  const latest = bars[bars.length - 1];
  if (bars.length < 6)
    return noPattern(
      "falling_wedge",
      latest.close,
      freshness,
      "At least six ordered bars are required to inspect converging falling support and resistance.",
    );
  const window = bars.slice(-6);
  const indexes = window.map((_, index) => index);
  const resistance = regression(
    indexes.map((index) => ({ index, value: window[index].high })),
  );
  const support = regression(
    indexes.map((index) => ({ index, value: window[index].low })),
  );
  const startWidth = resistance.at(0) - support.at(0);
  const endWidth =
    resistance.at(window.length - 1) - support.at(window.length - 1);
  const falling = resistance.slope < 0 && support.slope < 0;
  const converging =
    endWidth > 0 && endWidth < startWidth && resistance.slope < support.slope;
  const resistanceLevel = resistance.at(window.length - 1);
  const supportLevel = support.at(window.length - 1);
  const invalidation = supportLevel * (1 - INVALIDATION_BUFFER);
  const brokeResistance = latest.close > resistanceLevel;
  const invalidated =
    latest.low <= invalidation || latest.close <= invalidation;
  const geometry = falling && converging;
  const state = invalidated
    ? "invalidated"
    : geometry && brokeResistance
      ? "confirmed"
      : geometry
        ? "forming"
        : "blocked";
  const criteria = [
    {
      label: "Falling boundaries",
      met: falling,
      detail: `Resistance slope ${resistance.slope.toFixed(3)}, support slope ${support.slope.toFixed(3)}.`,
    },
    {
      label: "Convergence",
      met: converging,
      detail: `Channel width ${startWidth.toFixed(2)} → ${endWidth.toFixed(2)}.`,
    },
    {
      label: "Resistance breakout",
      met: brokeResistance,
      detail: `Latest close ${latest.close.toFixed(2)} versus resistance ${resistanceLevel.toFixed(2)}.`,
    },
    {
      label: "Invalidation",
      met: invalidated,
      detail: `Invalidation below ${invalidation.toFixed(2)}; latest low ${latest.low.toFixed(2)}.`,
    },
  ];
  const detail =
    state === "confirmed"
      ? "Falling Wedge resistance breakout is research-only context; it is never a trade signal, recommendation, intent, or broker call."
      : state === "invalidated"
        ? "Falling Wedge structure was invalidated below support; this is an append-only research record."
        : state === "forming"
          ? "Falling Wedge geometry is forming but remains unconfirmed until a close breaks resistance."
          : "Falling Wedge geometry is ambiguous and was blocked from research promotion.";
  return {
    pattern: "falling_wedge",
    state,
    confidence: clampConfidence(
      geometry ? (brokeResistance ? 0.74 : 0.49) : 0.16,
    ),
    freshness,
    necklineOrSupport: resistanceLevel,
    invalidationLevel: invalidation,
    latestClose: latest.close,
    detail,
    criteria,
  };
}
