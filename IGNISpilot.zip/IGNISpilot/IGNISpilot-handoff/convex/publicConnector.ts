"use node";

import { internalAction } from "./_generated/server";
import { internal } from "./_generated/api";
import type { Id } from "./_generated/dataModel";
import { v } from "convex/values";

const PUBLIC_API_BASE_URL = "https://api.public.com";
const PUBLIC_ACCESS_TOKEN_PATH = "/userapiauthservice/personal/access-tokens";
const PUBLIC_ACCOUNTS_PATH = "/userapigateway/trading/account";

type PublicAccount = { accountId?: string; accountType?: string };
type PublicPortfolioPosition = { symbol?: string; quantity?: string | number; averagePrice?: string | number; marketValue?: string | number; instrument?: { symbol?: string; type?: string } };
type PublicPortfolio = { positions?: PublicPortfolioPosition[]; buyingPower?: { buyingPower?: string | number }; equity?: string | number; totalEquity?: string | number };
type PublicFailure = "unauthorized" | "error";

function asNumber(value: unknown) {
  if (typeof value === "number") return Number.isFinite(value) ? value : undefined;
  if (typeof value === "string") {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : undefined;
  }
  return undefined;
}

function assetClass(type?: string) {
  return type === "CRYPTO" ? "crypto" as const : "equity" as const;
}

function publicFailure(status: number): PublicFailure {
  return status === 401 || status === 403 ? "unauthorized" : "error";
}

async function publicFetch(path: string, accessToken: string) {
  const response = await fetch(`${PUBLIC_API_BASE_URL}${path}`, {
    headers: { Authorization: `Bearer ${accessToken}`, Accept: "application/json" },
  });
  if (!response.ok) throw publicFailure(response.status);
  try {
    return await response.json() as unknown;
  } catch {
    throw "error" as const;
  }
}

export const syncReadOnly = internalAction({
  args: { workspaceId: v.id("workspaces") },
  handler: async (ctx, args): Promise<Id<"camaroProviderConnections"> | null> => {
    const secret = process.env.PUBLIC_PERSONAL_SECRET_TOKEN;
    const selectedAccountId = process.env.PUBLIC_ACCOUNT_ID ?? process.env.PUBLIC_READ_ONLY_WORKSPACE_ID;
    if (!secret || !selectedAccountId) {
      return ctx.runMutation(internal.camaroBrokerInternal.recordPublicSyncUnavailable, {
        workspaceId: args.workspaceId,
        reason: "error",
      });
    }

    try {
      const tokenResponse = await fetch(`${PUBLIC_API_BASE_URL}${PUBLIC_ACCESS_TOKEN_PATH}`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json" },
        body: JSON.stringify({ secret, validityInMinutes: 15 }),
      });
      if (!tokenResponse.ok) throw publicFailure(tokenResponse.status);
      const tokenPayload = await tokenResponse.json() as { accessToken?: unknown };
      if (typeof tokenPayload.accessToken !== "string" || !tokenPayload.accessToken) throw "error" as const;

      const accountsPayload = await publicFetch(PUBLIC_ACCOUNTS_PATH, tokenPayload.accessToken) as { accounts?: unknown };
      if (!Array.isArray(accountsPayload.accounts)) throw "error" as const;
      const account = accountsPayload.accounts.find((candidate): candidate is PublicAccount =>
        typeof candidate === "object" && candidate !== null && (candidate as PublicAccount).accountId === selectedAccountId
      );
      if (!account?.accountId) throw "unauthorized" as const;

      const portfolio = await publicFetch(`/userapigateway/trading/${encodeURIComponent(account.accountId)}/portfolio/v2`, tokenPayload.accessToken) as PublicPortfolio;
      const accountLabel = account.accountType ? `Public ${account.accountType.toLowerCase()} account` : "Public account";
      return ctx.runMutation(internal.camaroBrokerInternal.recordPublicReadOnlySync, {
        workspaceId: args.workspaceId,
        accounts: [{
          accountLabel,
          accountType: account.accountType,
          available: asNumber(portfolio.buyingPower?.buyingPower),
          total: asNumber(portfolio.totalEquity ?? portfolio.equity),
        }],
        positions: (portfolio.positions ?? []).flatMap((position) => {
          const symbol = position.symbol ?? position.instrument?.symbol;
          const quantity = asNumber(position.quantity);
          if (!symbol || quantity === undefined) return [];
          return [{
            symbol: symbol.toUpperCase(),
            assetClass: assetClass(position.instrument?.type),
            quantity,
            averageEntryPrice: asNumber(position.averagePrice),
            marketValue: asNumber(position.marketValue),
          }];
        }),
      });
    } catch (error) {
      return ctx.runMutation(internal.camaroBrokerInternal.recordPublicSyncUnavailable, {
        workspaceId: args.workspaceId,
        reason: error === "unauthorized" ? "unauthorized" : "error",
      });
    }
  },
});
