"use node";

import { internalAction } from "./_generated/server";
import { internal } from "./_generated/api";
import type { Id } from "./_generated/dataModel";
import { v } from "convex/values";
import { liveOrderGateEnabled, publicPdtLiveConstraintsVerified, publicTradingPermissionVerified } from "./camaroExecution";
import { createPublicOrderPayload, sendPublicJsonRequest } from "./publicOrderId.mjs";
import { evaluatePublicPreflightGate } from "./publicOrderGate.mjs";

const PUBLIC_API_BASE_URL = "https://api.public.com";
const ACCESS_TOKEN_PATH = "/userapiauthservice/personal/access-tokens";

function safeError(status: number) {
  if (status === 401 || status === 403) return "Public credential is unavailable for trading. Verify the server-side credential has the required trading permission.";
  return "Public did not accept the order request. No raw provider response was stored.";
}

async function accessToken() {
  const secret = process.env.PUBLIC_PERSONAL_SECRET_TOKEN;
  if (!secret) throw new Error("Public trading credential is not configured.");
  const response = await fetch(`${PUBLIC_API_BASE_URL}${ACCESS_TOKEN_PATH}`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body: JSON.stringify({ secret, validityInMinutes: 5 }),
  });
  if (!response.ok) throw new Error(safeError(response.status));
  const payload = await response.json() as { accessToken?: unknown };
  if (typeof payload.accessToken !== "string" || !payload.accessToken) throw new Error("Public returned no usable server access token.");
  return payload.accessToken;
}

function accountId() {
  // PUBLIC_ACCOUNT_ID is the preferred name. Keep the legacy alias so existing
  // deployments do not break during migration.
  const value = process.env.PUBLIC_ACCOUNT_ID ?? process.env.PUBLIC_READ_ONLY_WORKSPACE_ID;
  if (!value) throw new Error("Public account selection is not configured.");
  return value;
}

function brokerStateNeedsRefresh(state: any, now: number) {
  return state.connection?.status !== "connected_read_only"
    || !state.connection.lastSyncedAt
    || now - state.connection.lastSyncedAt > 15 * 60 * 1000
    || state.reconciliation?.status !== "reconciled";
}

async function request(path: string, method: "POST" | "GET" | "DELETE", token: string, payload?: object) {
  const response = await sendPublicJsonRequest(fetch, `${PUBLIC_API_BASE_URL}${path}`, method, token, payload);
  let data: unknown = null;
  try { data = await response.json(); } catch { /* no body is valid for cancellation */ }
  return { response, data };
}

function publicStatus(value: unknown) {
  const status = typeof (value as { status?: unknown })?.status === "string" ? (value as { status: string }).status.toUpperCase() : "UNKNOWN";
  if (["FILLED", "EXECUTED"].includes(status)) return "filled" as const;
  if (["PARTIALLY_FILLED", "PARTIAL_FILL"].includes(status)) return "partially_filled" as const;
  if (["REJECTED", "CANCELED", "CANCELLED", "EXPIRED"].includes(status)) return status === "REJECTED" ? "rejected" as const : "cancelled" as const;
  if (["NEW", "PENDING", "OPEN", "ACCEPTED"].includes(status)) return "accepted" as const;
  return "unknown" as const;
}

export const preflight = internalAction({
  args: { intentId: v.id("camaroExecutionIntents") },
  handler: async (ctx, args) => {
    let state = await ctx.runQuery(internal.camaroBrokerInternal.getExecutionIntentForBroker, args);
    if (!state) throw new Error("Execution intent was not found.");
    let now = Date.now();

    // A stale read-only snapshot should not require the operator to discover and
    // press a separate sync button. Refresh it once before evaluating the gate;
    // the order still fails closed if sync or reconciliation does not succeed.
    if (brokerStateNeedsRefresh(state, now)) {
      await ctx.runAction(internal.publicConnector.syncReadOnly, { workspaceId: state.intent.workspaceId });
      state = await ctx.runQuery(internal.camaroBrokerInternal.getExecutionIntentForBroker, args);
      if (!state) throw new Error("Execution intent was not found after broker refresh.");
      now = Date.now();
    }

    const blockReason = evaluatePublicPreflightGate({ now, liveFlagEnabled: liveOrderGateEnabled(), tradingPermissionVerified: publicTradingPermissionVerified(), pdtLiveConstraintsVerified: publicPdtLiveConstraintsVerified(), ...state });
    if (blockReason) {
      await ctx.runMutation(internal.camaroBrokerInternal.recordBrokerOrderResult, { intentId: args.intentId, eventType: "execution_blocked", blockReason, summary: `Server revalidation blocked Public preflight with ${blockReason}; no order was sent.`, preflightStatus: "failed", status: "blocked", outboundAttemptResult: "not_sent" });
      throw new Error(`${blockReason}: server revalidation blocked Public preflight; no broker order was sent.`);
    }
    const token = await accessToken();
    const result = await request(`/userapigateway/trading/${encodeURIComponent(accountId())}/preflight/single-leg`, "POST", token, createPublicOrderPayload(state.intent, false));
    if (!result.response.ok) {
      await ctx.runMutation(internal.camaroBrokerInternal.recordBrokerOrderResult, { intentId: args.intentId, eventType: "preflight_failed", summary: safeError(result.response.status), preflightStatus: "failed", status: "blocked" });
      throw new Error(safeError(result.response.status));
    }
    await ctx.runMutation(internal.camaroBrokerInternal.recordBrokerOrderResult, { intentId: args.intentId, eventType: "preflight_passed", summary: "Public order preflight passed; confirm the immutable order before its expiry.", preflightStatus: "passed", preflightVerifiedAt: Date.now(), status: "awaiting_confirmation" });
    return { accepted: true };
  },
});

export const submit = internalAction({
  args: { intentId: v.id("camaroExecutionIntents") },
  handler: async (ctx, args) => {
    const state = await ctx.runQuery(internal.camaroBrokerInternal.getExecutionIntentForBroker, args);
    if (!state) throw new Error("Execution intent was not found.");
    if (!liveOrderGateEnabled()) {
      await ctx.runMutation(internal.camaroBrokerInternal.recordBrokerOrderResult, { intentId: args.intentId, eventType: "execution_blocked", blockReason: "LIVE_FLAG_OFF", summary: "Server revalidation blocked broker submission; no order was sent.", status: "blocked", outboundAttemptResult: "not_sent" });
      throw new Error("LIVE_FLAG_OFF: server live-order feature flag is disabled; no broker order was sent.");
    }
    const claim = await ctx.runMutation(internal.camaroBrokerInternal.claimBrokerSubmission, { ...args, liveFlagEnabled: liveOrderGateEnabled(), tradingPermissionVerified: publicTradingPermissionVerified(), pdtLiveConstraintsVerified: publicPdtLiveConstraintsVerified() });
    if (claim.state !== "claimed") {
      if (claim.state === "invalid_order_id") throw new Error("INVALID_ORDER_ID: execution intent has an invalid Public orderId; no broker order was sent.");
      throw new Error(`${claim.blockReason ?? "EXECUTION_BLOCKED"}: server revalidation blocked broker submission; no broker order was sent.`);
    }
    const intent = claim.intent;
    try {
      const token = await accessToken();
      const result = await request(`/userapigateway/trading/${encodeURIComponent(accountId())}/order`, "POST", token, createPublicOrderPayload(intent));
      if (!result.response.ok || typeof (result.data as { orderId?: unknown })?.orderId !== "string") {
        await ctx.runMutation(internal.camaroBrokerInternal.recordBrokerOrderResult, { intentId: args.intentId, eventType: "broker_rejected", summary: safeError(result.response.status), status: "rejected", orderStatus: "rejected", orderId: intent.orderId, retryState: "initial", outboundAttemptResult: "rejected" });
        throw new Error(safeError(result.response.status));
      }
      await ctx.runMutation(internal.camaroBrokerInternal.recordBrokerOrderResult, { intentId: args.intentId, eventType: "broker_accepted", summary: "Public accepted the submission. Submitted is not filled; refresh broker status for execution state.", status: "submitted", orderStatus: "submitted", externalOrderReference: (result.data as { orderId: string }).orderId, orderId: intent.orderId, retryState: "initial", outboundAttemptResult: "accepted" });
      await ctx.runAction(internal.publicConnector.syncReadOnly, { workspaceId: intent.workspaceId });
      return { status: "submitted" };
    } catch (error) {
      if (error instanceof Error && error.message.startsWith("Public")) throw error;
      await ctx.runMutation(internal.camaroBrokerInternal.recordBrokerOrderResult, { intentId: args.intentId, eventType: "submission_failed", summary: "Broker submission failed before acceptance was recorded.", status: "blocked", orderId: intent.orderId, retryState: "initial", outboundAttemptResult: "failed" });
      throw error;
    }
  },
});

export const refreshStatus = internalAction({
  args: { intentId: v.id("camaroExecutionIntents") },
  handler: async (ctx, args) => {
    const state = await ctx.runQuery(internal.camaroBrokerInternal.getExecutionIntentForBroker, args);
    if (!state?.intent.externalOrderReference) throw new Error("No submitted Public order is available to refresh.");
    const token = await accessToken();
    const result = await request(`/userapigateway/trading/${encodeURIComponent(accountId())}/order/${encodeURIComponent(state.intent.externalOrderReference)}`, "GET", token);
    if (!result.response.ok) throw new Error(safeError(result.response.status));
    const status = publicStatus(result.data);
    const filledQuantity = Number((result.data as { filledQuantity?: unknown })?.filledQuantity);
    const persistedStatus = status === "unknown" ? "accepted" : status;
    await ctx.runMutation(internal.camaroBrokerInternal.recordBrokerOrderResult, { intentId: args.intentId, eventType: status === "filled" ? "fill_recorded" : "status_updated", summary: status === "filled" ? "Public reports the order filled." : `Public reports order state: ${status.replaceAll("_", " ")}.`, status: persistedStatus, orderStatus: status, ...(Number.isFinite(filledQuantity) ? { filledQuantity } : {}) });
    return { status };
  },
});

export const cancel = internalAction({
  args: { intentId: v.id("camaroExecutionIntents") },
  handler: async (ctx, args) => {
    const state = await ctx.runQuery(internal.camaroBrokerInternal.getExecutionIntentForBroker, args);
    if (!state?.intent.externalOrderReference) throw new Error("No submitted Public order is available to cancel.");
    await ctx.runMutation(internal.camaroBrokerInternal.recordBrokerOrderResult, { intentId: args.intentId, eventType: "cancellation_attempt", summary: "Public order cancellation requested by the operator.", status: "cancel_pending", orderStatus: "cancel_pending" });
    const token = await accessToken();
    const result = await request(`/userapigateway/trading/${encodeURIComponent(accountId())}/order/${encodeURIComponent(state.intent.externalOrderReference)}`, "DELETE", token);
    if (!result.response.ok) {
      await ctx.runMutation(internal.camaroBrokerInternal.recordBrokerOrderResult, { intentId: args.intentId, eventType: "cancellation_result", summary: safeError(result.response.status), status: "accepted" });
      throw new Error(safeError(result.response.status));
    }
    await ctx.runMutation(internal.camaroBrokerInternal.recordBrokerOrderResult, { intentId: args.intentId, eventType: "cancellation_result", summary: "Public accepted the cancellation request. Refresh status for final broker state.", status: "cancel_pending", orderStatus: "cancel_pending" });
    return { status: "cancel_pending" };
  },
});
