import { convexAuth } from "@convex-dev/auth/server";
import { Password } from "@convex-dev/auth/providers/Password";

export const { auth, signIn, signOut, store, isAuthenticated } = convexAuth({
  providers: [
    Password({
      profile: (params) => {
        const rawEmail = params.email;
        if (typeof rawEmail !== "string") {
          throw new Error("Email is required");
        }

        const email = rawEmail.trim().toLowerCase();
        if (!email || !email.includes("@")) {
          throw new Error("Enter a valid email address");
        }

        const rawName = params.name;
        const name = typeof rawName === "string" ? rawName.trim() : "";
        if (name.length > 80) {
          throw new Error("Operator name must be 80 characters or fewer");
        }

        return {
          email,
          ...(name ? { name } : {}),
        };
      },
    }),
  ],
});
