export const PUBLIC_BROKER_DISCLOSURE_VERSION = "public-broker-connect-v1";
export const PUBLIC_BROKER_DISCLOSURE = 'The Software is provided on an "as-is" and "as-available" basis. The Company does not guarantee any specific financial outcome, profits, or success rates. You retain ultimate responsibility for monitoring your Brokerage Account activity and managing your risk settings.';
export const PUBLIC_BROKER_DISCLOSURE_SHA256 = "f72838594490642bd972e5b75466a4b9c0c4170a1e66169ad9477a8254f4236a";
export const PUBLIC_CONNECTION_REFERENCE = "public:server-selected-account";

export const brokerMode = ["read_only", "paper", "operator_confirmed", "live_capable"] as const;
export type BrokerMode = (typeof brokerMode)[number];

export function isCurrentPublicConsent(record: {
  providerId: string;
  termsVersion: string;
  disclosureVersion: string;
  disclosureHash: string;
}) {
  return record.providerId === "public"
    && record.termsVersion === PUBLIC_BROKER_DISCLOSURE_VERSION
    && record.disclosureVersion === PUBLIC_BROKER_DISCLOSURE_VERSION
    && record.disclosureHash === PUBLIC_BROKER_DISCLOSURE_SHA256;
}
