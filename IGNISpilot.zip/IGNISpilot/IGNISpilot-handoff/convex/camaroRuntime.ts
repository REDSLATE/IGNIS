import { mutation, query } from "./_generated/server";
import type { MutationCtx } from "./_generated/server";
import type { Id } from "./_generated/dataModel";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

const assetClass = v.union(v.literal("equity"), v.literal("crypto"));
const stanceSide = v.union(v.literal("long"), v.literal("short"), v.literal("neutral"));

const doctrineChecks = [
  {
    name: "Approval-only authority",
    state: "blocked" as const,
    detail: "Camaro may create and inspect intent, but cannot place or route an order.",
  },
  {
    name: "Runtime token boundary",
    state: "unavailable" as const,
    detail: "No runtime token is captured or stored by the cockpit. A future sidecar must verify tokens server-side.",
  },
  {
    name: "Equity policy route",
    state: "unavailable" as const,
    detail: "Equity policy is represented separately; live market, PDT, and account checks are not connected.",
  },
  {
    name: "Crypto policy route",
    state: "unavailable" as const,
    detail: "Crypto policy is represented separately; venue, custody, and account checks are not connected.",
  },
  {
    name: "Broker reality",
    state: "unavailable" as const,
    detail: "No broker account, positions, orders, fills, or reconciliation data is available in this runtime.",
  },
];

async function requireMembership(ctx: MutationCtx, workspaceId: Id<"workspaces">) {
  const userId = await getAuthUserId(ctx);
  if (!userId) throw new Error("Not authenticated");

  const membership = await ctx.db
    .query("workspaceMembers")
    .withIndex("by_workspaceId_userId", (index) =>
      index.eq("workspaceId", workspaceId).eq("userId", userId)
    )
    .unique();

  if (!membership) throw new Error("Workspace access denied");
  return { userId, membership };
}

async function writeReceipt(
  ctx: MutationCtx,
  args: {
    workspaceId: Id<"workspaces">;
    receiptType: "heartbeat" | "stance" | "challenge" | "outcome" | "promotion" | "doctrine_check";
    summary: string;
    subjectType: "runtime" | "stance" | "intent" | "promotion" | "doctrine";
    subjectId?: string;
    createdBy: Id<"users">;
    createdAt: number;
  }
) {
  return ctx.db.insert("camaroRuntimeReceipts", args);
}

export const getRuntimeSpine = query({
  args: { workspaceId: v.id("workspaces") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return null;

    const membership = await ctx.db
      .query("workspaceMembers")
      .withIndex("by_workspaceId_userId", (index) =>
        index.eq("workspaceId", args.workspaceId).eq("userId", userId)
      )
      .unique();
    if (!membership) return null;

    const [heartbeats, stances, challenges, outcomes, promotions, receipts, publicConnection] = await Promise.all([
      ctx.db
        .query("camaroRuntimeHeartbeats")
        .withIndex("by_workspaceId_createdAt", (index) => index.eq("workspaceId", args.workspaceId))
        .order("desc")
        .take(1),
      ctx.db
        .query("camaroStances")
        .withIndex("by_workspaceId_createdAt", (index) => index.eq("workspaceId", args.workspaceId))
        .order("desc")
        .take(8),
      ctx.db
        .query("camaroChallenges")
        .withIndex("by_workspaceId_createdAt", (index) => index.eq("workspaceId", args.workspaceId))
        .order("desc")
        .take(8),
      ctx.db
        .query("camaroOutcomes")
        .withIndex("by_workspaceId_createdAt", (index) => index.eq("workspaceId", args.workspaceId))
        .order("desc")
        .take(8),
      ctx.db
        .query("camaroPromotionReadiness")
        .withIndex("by_workspaceId_createdAt", (index) => index.eq("workspaceId", args.workspaceId))
        .order("desc")
        .take(6),
      ctx.db
        .query("camaroRuntimeReceipts")
        .withIndex("by_workspaceId_createdAt", (index) => index.eq("workspaceId", args.workspaceId))
        .order("desc")
        .take(12),
      ctx.db
        .query("camaroProviderConnections")
        .withIndex("by_workspaceId_providerId", (index) => index.eq("workspaceId", args.workspaceId).eq("providerId", "public"))
        .unique(),
    ]);
    const publicAge = publicConnection?.lastSyncedAt ? Date.now() - publicConnection.lastSyncedAt : null;
    const brokerReality = !publicConnection
      ? { state: "unavailable" as const, detail: "Public read-only monitoring has not been enabled." }
      : publicConnection.status === "sync_unavailable"
        ? { state: "unavailable" as const, detail: "Public read-only sync is in an error state; broker authority remains blocked." }
        : publicAge === null || publicAge > 15 * 60 * 1000
          ? { state: "unavailable" as const, detail: "Public broker data is unavailable or stale; broker authority remains blocked." }
          : { state: "clear" as const, detail: "Public account and position state are recent; order and fill coverage remains degraded and authority stays blocked." };

    const latestHeartbeat = heartbeats[0] ?? null;
    const heartbeat = latestHeartbeat
      ? {
          ...latestHeartbeat,
          freshness: Date.now() - latestHeartbeat.recordedAt > 5 * 60 * 1000 ? "stale" : "recorded",
        }
      : null;

    return {
      heartbeat,
      stances,
      challenges,
      outcomes,
      promotions,
      receipts,
      doctrineChecks: doctrineChecks.map((check) => check.name === "Broker reality" ? { ...check, ...brokerReality } : check),
      routes: {
        missionControl: {
          state: "unavailable" as const,
          detail: "Mission Control contract is modeled as an intent and receipt boundary; no Mission Control service is connected.",
        },
        equity: {
          state: "unavailable" as const,
          detail: "Equity route reserves policy, PDT, and market-session checks without claiming live coverage.",
        },
        crypto: {
          state: "unavailable" as const,
          detail: "Crypto route reserves venue, custody, and continuous-market checks without claiming live coverage.",
        },
      },
    };
  },
});

export const recordOperatorHeartbeat = mutation({
  args: { workspaceId: v.id("workspaces") },
  handler: async (ctx, args) => {
    const { userId } = await requireMembership(ctx, args.workspaceId);
    const now = Date.now();
    const heartbeatId = await ctx.db.insert("camaroRuntimeHeartbeats", {
      workspaceId: args.workspaceId,
      runtime: "camaro",
      source: "operator_recorded",
      status: "available",
      tokenCheck: "unavailable",
      missionControlState: "unavailable",
      detail: "Operator-recorded cockpit heartbeat. No sovereign sidecar or runtime-token verification is connected.",
      recordedBy: userId,
      recordedAt: now,
    });
    await writeReceipt(ctx, {
      workspaceId: args.workspaceId,
      receiptType: "heartbeat",
      summary: "Operator-recorded Camaro heartbeat captured; no sidecar or Mission Control connection was asserted.",
      subjectType: "runtime",
      subjectId: heartbeatId,
      createdBy: userId,
      createdAt: now,
    });
    return heartbeatId;
  },
});

export const publishStance = mutation({
  args: {
    workspaceId: v.id("workspaces"),
    symbol: v.string(),
    assetClass,
    side: stanceSide,
    confidence: v.number(),
    rationale: v.string(),
  },
  handler: async (ctx, args) => {
    const { userId } = await requireMembership(ctx, args.workspaceId);
    const symbol = args.symbol.trim().toUpperCase();
    const rationale = args.rationale.trim();
    if (!symbol || symbol.length > 20) throw new Error("Provide a symbol of 20 characters or fewer");
    if (rationale.length < 10 || rationale.length > 1200) throw new Error("Provide a rationale between 10 and 1200 characters");
    if (args.confidence < 0 || args.confidence > 1) throw new Error("Confidence must be between 0 and 1");

    const now = Date.now();
    const stanceId = await ctx.db.insert("camaroStances", {
      workspaceId: args.workspaceId,
      runtime: "camaro",
      symbol,
      assetClass: args.assetClass,
      side: args.side,
      confidence: args.confidence,
      rationale,
      resolution: "published",
      createdBy: userId,
      createdAt: now,
    });
    await writeReceipt(ctx, {
      workspaceId: args.workspaceId,
      receiptType: "stance",
      summary: `Camaro published a ${args.side} stance for ${symbol}; it is an operator-recorded opinion, not a market signal.`,
      subjectType: "stance",
      subjectId: stanceId,
      createdBy: userId,
      createdAt: now,
    });
    return stanceId;
  },
});

export const challengeStance = mutation({
  args: {
    stanceId: v.id("camaroStances"),
    targetRuntime: v.string(),
    counterSide: stanceSide,
    rationale: v.string(),
  },
  handler: async (ctx, args) => {
    const stance = await ctx.db.get(args.stanceId);
    if (!stance) throw new Error("Stance not found");
    const { userId } = await requireMembership(ctx, stance.workspaceId);
    const targetRuntime = args.targetRuntime.trim();
    const rationale = args.rationale.trim();
    if (!targetRuntime || targetRuntime.length > 50) throw new Error("Provide a target runtime");
    if (rationale.length < 10 || rationale.length > 1200) throw new Error("Provide a challenge rationale between 10 and 1200 characters");

    const now = Date.now();
    const challengeId = await ctx.db.insert("camaroChallenges", {
      workspaceId: stance.workspaceId,
      stanceId: stance._id,
      targetRuntime,
      counterSide: args.counterSide,
      rationale,
      status: "open",
      createdBy: userId,
      createdAt: now,
    });
    await ctx.db.patch(stance._id, { resolution: "challenged" });
    await writeReceipt(ctx, {
      workspaceId: stance.workspaceId,
      receiptType: "challenge",
      summary: `Camaro recorded an open challenge to ${targetRuntime} for ${stance.symbol}. No peer runtime was contacted.`,
      subjectType: "stance",
      subjectId: challengeId,
      createdBy: userId,
      createdAt: now,
    });
    return challengeId;
  },
});

export const recordOutcome = mutation({
  args: {
    workspaceId: v.id("workspaces"),
    intentId: v.optional(v.id("camaroIntents")),
    disposition: v.union(v.literal("observed"), v.literal("unresolved"), v.literal("blocked")),
    summary: v.string(),
  },
  handler: async (ctx, args) => {
    const { userId } = await requireMembership(ctx, args.workspaceId);
    const summary = args.summary.trim();
    if (summary.length < 10 || summary.length > 1200) throw new Error("Provide an outcome note between 10 and 1200 characters");
    if (args.intentId) {
      const intent = await ctx.db.get(args.intentId);
      if (!intent || intent.workspaceId !== args.workspaceId) throw new Error("Intent not found in this workspace");
    }
    const now = Date.now();
    const outcomeId = await ctx.db.insert("camaroOutcomes", {
      workspaceId: args.workspaceId,
      intentId: args.intentId,
      disposition: args.disposition,
      summary,
      createdBy: userId,
      createdAt: now,
    });
    await writeReceipt(ctx, {
      workspaceId: args.workspaceId,
      receiptType: "outcome",
      summary: "Outcome review recorded without performance, price, fill, or external execution claims.",
      subjectType: "intent",
      subjectId: args.intentId,
      createdBy: userId,
      createdAt: now,
    });
    return outcomeId;
  },
});

export const inspectPromotionReadiness = mutation({
  args: { workspaceId: v.id("workspaces"), artifactName: v.string() },
  handler: async (ctx, args) => {
    const { userId } = await requireMembership(ctx, args.workspaceId);
    const artifactName = args.artifactName.trim();
    if (!artifactName || artifactName.length > 100) throw new Error("Provide an artifact name of 100 characters or fewer");
    const now = Date.now();
    const readinessId = await ctx.db.insert("camaroPromotionReadiness", {
      workspaceId: args.workspaceId,
      artifactName,
      stage: "inspection",
      status: "not_ready",
      blockers: [
        "No resolved evidence package is attached.",
        "No runtime-token verification is connected.",
        "No sidecar or Mission Control promotion gate is connected.",
      ],
      createdBy: userId,
      createdAt: now,
    });
    await writeReceipt(ctx, {
      workspaceId: args.workspaceId,
      receiptType: "promotion",
      summary: `${artifactName} promotion readiness inspected and held at not ready; no artifact was promoted.`,
      subjectType: "promotion",
      subjectId: readinessId,
      createdBy: userId,
      createdAt: now,
    });
    return readinessId;
  },
});
