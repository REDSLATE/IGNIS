const MAX_STALE_MS = 15 * 60 * 1000;
const PEAK_TOLERANCE = 0.03;
const INVALIDATION_BUFFER = 0.01;

function clampConfidence(value) {
  return Math.round(Math.max(0, Math.min(1, value)) * 100) / 100;
}

function freshnessFor(bars, now) {
  return now - bars[bars.length - 1].timestamp <= MAX_STALE_MS ? "recent" : "stale";
}

function noPattern(pattern, latestClose, freshness, detail) {
  return { pattern, state: "blocked", confidence: 0, freshness, latestClose, detail, criteria: [{ label: "Evidence", met: false, detail }] };
}

function isFiniteBar(bar) {
  return Number.isFinite(bar.timestamp) && Number.isFinite(bar.high) && Number.isFinite(bar.low) && Number.isFinite(bar.close) && bar.high >= bar.low;
}

function regression(points) {
  const averageIndex = points.reduce((total, point) => total + point.index, 0) / points.length;
  const averageValue = points.reduce((total, point) => total + point.value, 0) / points.length;
  const denominator = points.reduce((total, point) => total + (point.index - averageIndex) ** 2, 0);
  const slope = denominator === 0 ? 0 : points.reduce((total, point) => total + (point.index - averageIndex) * (point.value - averageValue), 0) / denominator;
  return { slope, at: (index) => averageValue + slope * (index - averageIndex) };
}

export function assessBearishPatterns(bars, now = Date.now()) {
  if (bars.length === 0) return [];
  const latest = bars[bars.length - 1];
  const freshness = freshnessFor(bars, now);
  if (!bars.every(isFiniteBar)) {
    return ["double_top", "head_and_shoulders", "rising_wedge"].map((pattern) => noPattern(pattern, latest.close, freshness, "Malformed OHLC research input was blocked; no pattern conclusion was recorded."));
  }
  return [assessDoubleTop(bars, freshness), assessHeadAndShoulders(bars, freshness), assessRisingWedge(bars, freshness)];
}

function assessDoubleTop(bars, freshness) {
  const latest = bars[bars.length - 1];
  if (bars.length < 5) return noPattern("double_top", latest.close, freshness, "At least five ordered bars are required to inspect two peaks and a neckline.");
  const window = bars.slice(-5);
  const [firstPeak, necklineBar, secondPeak] = window;
  const peakDifference = Math.abs(firstPeak.high - secondPeak.high) / Math.max(firstPeak.high, secondPeak.high);
  const peaksComparable = peakDifference <= PEAK_TOLERANCE;
  const neckline = necklineBar.low;
  const invalidation = Math.max(firstPeak.high, secondPeak.high) * (1 + INVALIDATION_BUFFER);
  const brokeNeckline = latest.close < neckline;
  const invalidated = latest.high >= invalidation || latest.close >= invalidation;
  const state = invalidated ? "invalidated" : peaksComparable && brokeNeckline ? "confirmed" : peaksComparable ? "forming" : "blocked";
  const criteria = [
    { label: "Comparable peaks", met: peaksComparable, detail: `Peak separation ${(peakDifference * 100).toFixed(1)}% (maximum ${(PEAK_TOLERANCE * 100).toFixed(0)}%).` },
    { label: "Neckline break", met: brokeNeckline, detail: `Latest close ${latest.close.toFixed(2)} versus neckline ${neckline.toFixed(2)}.` },
    { label: "Invalidation", met: invalidated, detail: `Invalidation above ${invalidation.toFixed(2)}; latest high ${latest.high.toFixed(2)}.` },
  ];
  const detail = state === "confirmed" ? "Double Top neckline break is recorded as bearish research context only; it does not create a signal, advice, intent, or order." : state === "invalidated" ? "Double Top structure was invalidated above its peak buffer; this is an append-only research record." : state === "forming" ? "Double Top geometry is forming but remains unconfirmed until a close breaks the neckline." : "Double Top evidence is ambiguous and was blocked from research promotion.";
  return { pattern: "double_top", state, confidence: clampConfidence(peaksComparable ? (brokeNeckline ? 0.78 : 0.52) : 0.18), freshness, necklineOrSupport: neckline, invalidationLevel: invalidation, latestClose: latest.close, detail, criteria };
}

function assessHeadAndShoulders(bars, freshness) {
  const latest = bars[bars.length - 1];
  if (bars.length < 7) return noPattern("head_and_shoulders", latest.close, freshness, "At least seven ordered bars are required to inspect shoulders, head, and neckline.");
  const window = bars.slice(-7);
  const leftShoulder = window[0];
  const leftTrough = window[1];
  const head = window[2];
  const rightTrough = window[3];
  const rightShoulder = window[4];
  const neckline = (leftTrough.low + rightTrough.low) / 2;
  const shoulderDifference = Math.abs(leftShoulder.high - rightShoulder.high) / Math.max(leftShoulder.high, rightShoulder.high);
  const shouldersComparable = shoulderDifference <= 0.05;
  const headDominant = head.high > leftShoulder.high && head.high > rightShoulder.high;
  const invalidation = head.high * (1 + INVALIDATION_BUFFER);
  const brokeNeckline = latest.close < neckline;
  const invalidated = latest.high >= invalidation || latest.close >= invalidation;
  const geometry = shouldersComparable && headDominant;
  const state = invalidated ? "invalidated" : geometry && brokeNeckline ? "confirmed" : geometry ? "forming" : "blocked";
  const criteria = [
    { label: "Shoulder symmetry", met: shouldersComparable, detail: `Shoulder separation ${(shoulderDifference * 100).toFixed(1)}% (maximum 5%).` },
    { label: "Head dominance", met: headDominant, detail: `Head ${head.high.toFixed(2)} versus shoulders ${leftShoulder.high.toFixed(2)} / ${rightShoulder.high.toFixed(2)}.` },
    { label: "Neckline break", met: brokeNeckline, detail: `Latest close ${latest.close.toFixed(2)} versus neckline ${neckline.toFixed(2)}.` },
    { label: "Invalidation", met: invalidated, detail: `Invalidation above ${invalidation.toFixed(2)}; latest high ${latest.high.toFixed(2)}.` },
  ];
  const detail = state === "confirmed" ? "Head & Shoulders neckline break is research-only context; Camaro cannot convert it into advice, intent, authority, or execution." : state === "invalidated" ? "Head & Shoulders structure was invalidated above the head buffer; this is an append-only research record." : state === "forming" ? "Head & Shoulders geometry is forming but remains unconfirmed until a close breaks the neckline." : "Head & Shoulders geometry is ambiguous and was blocked from research promotion.";
  return { pattern: "head_and_shoulders", state, confidence: clampConfidence(geometry ? (brokeNeckline ? 0.81 : 0.56) : 0.17), freshness, necklineOrSupport: neckline, invalidationLevel: invalidation, latestClose: latest.close, detail, criteria };
}

function assessRisingWedge(bars, freshness) {
  const latest = bars[bars.length - 1];
  if (bars.length < 6) return noPattern("rising_wedge", latest.close, freshness, "At least six ordered bars are required to inspect converging rising support and resistance.");
  const window = bars.slice(-6);
  const indexes = window.map((_, index) => index);
  const resistance = regression(indexes.map((index) => ({ index, value: window[index].high })));
  const support = regression(indexes.map((index) => ({ index, value: window[index].low })));
  const startWidth = resistance.at(0) - support.at(0);
  const endWidth = resistance.at(window.length - 1) - support.at(window.length - 1);
  const rising = resistance.slope > 0 && support.slope > 0;
  const converging = endWidth > 0 && endWidth < startWidth && support.slope > resistance.slope;
  const supportLevel = support.at(window.length - 1);
  const resistanceLevel = resistance.at(window.length - 1);
  const invalidation = resistanceLevel * (1 + INVALIDATION_BUFFER);
  const brokeSupport = latest.close < supportLevel;
  const invalidated = latest.high >= invalidation || latest.close >= invalidation;
  const geometry = rising && converging;
  const state = invalidated ? "invalidated" : geometry && brokeSupport ? "confirmed" : geometry ? "forming" : "blocked";
  const criteria = [
    { label: "Rising boundaries", met: rising, detail: `Resistance slope ${resistance.slope.toFixed(3)}, support slope ${support.slope.toFixed(3)}.` },
    { label: "Convergence", met: converging, detail: `Channel width ${startWidth.toFixed(2)} → ${endWidth.toFixed(2)}.` },
    { label: "Support break", met: brokeSupport, detail: `Latest close ${latest.close.toFixed(2)} versus support ${supportLevel.toFixed(2)}.` },
    { label: "Invalidation", met: invalidated, detail: `Invalidation above ${invalidation.toFixed(2)}; latest high ${latest.high.toFixed(2)}.` },
  ];
  const detail = state === "confirmed" ? "Rising Wedge support break is research-only context; it is never a trade signal, recommendation, intent, or broker call." : state === "invalidated" ? "Rising Wedge structure was invalidated above resistance; this is an append-only research record." : state === "forming" ? "Rising Wedge geometry is forming but remains unconfirmed until a close breaks support." : "Rising Wedge geometry is ambiguous and was blocked from research promotion.";
  return { pattern: "rising_wedge", state, confidence: clampConfidence(geometry ? (brokeSupport ? 0.74 : 0.49) : 0.16), freshness, necklineOrSupport: supportLevel, invalidationLevel: invalidation, latestClose: latest.close, detail, criteria };
}
