import { internalMutation } from "./_generated/server";
import { v } from "convex/values";

const productStatus = v.union(
  v.literal("active"),
  v.literal("draft"),
  v.literal("archived")
);

export const create = internalMutation({
  args: {
    title: v.string(),
    description: v.optional(v.string()),
    priceAmountCents: v.number(),
    currency: v.string(),
    status: productStatus,
    coverImageUrl: v.optional(v.string()),
    platformProductId: v.string(),
  },
  handler: async (ctx, args) => {
    const now = Date.now();
    return await ctx.db.insert("products", { ...args, createdAt: now, updatedAt: now });
  },
});

export const update = internalMutation({
  args: {
    id: v.id("products"),
    title: v.string(),
    description: v.optional(v.string()),
    priceAmountCents: v.number(),
    currency: v.string(),
    status: productStatus,
    coverImageUrl: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const { id, ...updates } = args;
    await ctx.db.patch(id, { ...updates, updatedAt: Date.now() });
    return id;
  },
});

export const updateCheckoutUrl = internalMutation({
  args: {
    id: v.id("products"),
    platformProductId: v.string(),
    checkoutUrl: v.string(),
  },
  handler: async (ctx, args) => {
    await ctx.db.patch(args.id, {
      platformProductId: args.platformProductId,
      checkoutUrl: args.checkoutUrl,
      updatedAt: Date.now(),
    });
    return args.id;
  },
});
