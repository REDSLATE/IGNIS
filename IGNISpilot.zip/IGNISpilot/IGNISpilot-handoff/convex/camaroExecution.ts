export const EXECUTION_MODES = [
  "READ_ONLY",
  "PAPER",
  "OPERATOR_CONFIRM_REQUIRED",
  "LIVE_DISABLED_PENDING_ENABLEMENT",
] as const;

export type ExecutionMode = (typeof EXECUTION_MODES)[number];

export function liveOrderGateEnabled() {
  return process.env.PUBLIC_LIVE_ORDER_GATE_ENABLED === "true";
}

export function publicTradingPermissionVerified() {
  return process.env.PUBLIC_TRADING_PERMISSION_VERIFIED === "true";
}

export function publicPdtLiveConstraintsVerified() {
  return process.env.PUBLIC_PDT_LIVE_CONSTRAINTS_VERIFIED === "true";
}

export const MAX_PUBLIC_ORDER_NOTIONAL = 10_000;
export const MAX_PUBLIC_ORDER_QUANTITY = 100;

export const EXECUTION_INTENT_TTL_MS = 5 * 60 * 1000;
export const ACCOUNT_STATE_FRESHNESS_MS = 15 * 60 * 1000;

export function createIntentHash(input: {
  workspaceId: string;
  symbol: string;
  side: string;
  quantity?: number;
  notional?: number;
  orderType: string;
  timeInForce: string;
  limitPrice?: number;
  accountReference: string;
  authorityScope: string;
  preflightedAt: number;
  expiresAt: number;
}) {
  const canonical = [
    input.workspaceId,
    input.symbol.toUpperCase(),
    input.side,
    input.quantity ?? "",
    input.notional ?? "",
    input.orderType,
    input.timeInForce,
    input.limitPrice ?? "market",
    input.accountReference,
    input.authorityScope,
    input.preflightedAt,
    input.expiresAt,
  ].join("|");
  let hash = 2166136261;
  for (let index = 0; index < canonical.length; index += 1) {
    hash ^= canonical.charCodeAt(index);
    hash = Math.imul(hash, 16777619);
  }
  return `camaro-${(hash >>> 0).toString(16).padStart(8, "0")}`;
}

export function brokerWriteBlockReason(mode: ExecutionMode) {
  if (mode === "READ_ONLY") return "Broker writes are unavailable in READ_ONLY mode.";
  if (mode === "PAPER") return "Broker writes are unavailable in PAPER mode.";
  if (mode === "LIVE_DISABLED_PENDING_ENABLEMENT") return "Live broker writes are disabled pending explicit enablement.";
  return "Live broker writes require the separately enabled global live-order gate.";
}
