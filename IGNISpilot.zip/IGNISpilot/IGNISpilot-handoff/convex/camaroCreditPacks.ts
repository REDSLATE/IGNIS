export const CAMARO_CREDIT_PACKS = [
  {
    id: "camaro_100",
    label: "Camaro 100",
    credits: 100,
    productId: process.env.CAMARO_CREDIT_PACK_100_PRODUCT_ID?.trim() || null,
    checkoutUrl: process.env.CAMARO_CREDIT_PACK_100_CHECKOUT_URL?.trim() || null,
  },
  {
    id: "camaro_300",
    label: "Camaro 300",
    credits: 300,
    productId: process.env.CAMARO_CREDIT_PACK_300_PRODUCT_ID?.trim() || null,
    checkoutUrl: process.env.CAMARO_CREDIT_PACK_300_CHECKOUT_URL?.trim() || null,
  },
] as const;

export type CamaroCreditPackId = (typeof CAMARO_CREDIT_PACKS)[number]["id"];

export function availableCamaroCreditPacks() {
  return CAMARO_CREDIT_PACKS.map((pack) => ({
    id: pack.id,
    label: pack.label,
    credits: pack.credits,
    productId: pack.productId,
    checkoutUrl: pack.checkoutUrl,
    available: Boolean(pack.productId && pack.checkoutUrl),
  }));
}

export function findCamaroCreditPack(productId: string) {
  return availableCamaroCreditPacks().find((pack) => pack.available && pack.productId === productId) ?? null;
}
