import { mutation, query } from "./_generated/server";
import type { MutationCtx } from "./_generated/server";
import type { Id } from "./_generated/dataModel";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

const assetClass = v.union(v.literal("equity"), v.literal("crypto"));
const horizon = v.union(
  v.literal("intraday"),
  v.literal("swing"),
  v.literal("position")
);

const EXAMPLE_WATCHLIST = [
  { symbol: "AAPL", assetClass: "equity" as const },
  { symbol: "MSFT", assetClass: "equity" as const },
  { symbol: "BTC-USD", assetClass: "crypto" as const },
  { symbol: "ETH-USD", assetClass: "crypto" as const },
];

async function requireMembership(
  ctx: MutationCtx,
  workspaceId: Id<"workspaces">
) {
  const userId = await getAuthUserId(ctx);
  if (!userId) throw new Error("Not authenticated");

  const membership = await ctx.db
    .query("workspaceMembers")
    .withIndex("by_workspaceId_userId", (index) =>
      index.eq("workspaceId", workspaceId).eq("userId", userId)
    )
    .unique();

  if (!membership) throw new Error("Workspace access denied");
  return { userId, membership };
}

function providerState() {
  return process.env.MARKET_DATA_PROVIDER_API_KEY
    ? {
        status: "configured" as const,
        label: "Provider configured",
        detail:
          "Credential is present server-side. A market-data adapter has not been enabled in this release.",
      }
    : {
        status: "not_configured" as const,
        label: "Provider not configured",
        detail:
          "No market-data credential is configured. Quotes and runtime signals are intentionally unavailable.",
      };
}

export const getCockpit = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return null;

    const memberships = await ctx.db
      .query("workspaceMembers")
      .withIndex("by_userId", (index) => index.eq("userId", userId))
      .collect();

    const membership = memberships[0];
    if (!membership) {
      return {
        workspace: null,
        provider: providerState(),
        broker: {
          status: "not_connected" as const,
          label: "Broker read-only connection unavailable",
          detail:
            "Connect a broker through a future server-side integration to read accounts, positions, and reconciliation state.",
        },
        watchlist: [],
        intents: [],
        audit: [],
      };
    }

    const workspace = await ctx.db.get(membership.workspaceId);
    if (!workspace) return null;

    const [watchlist, intents, audit] = await Promise.all([
      ctx.db
        .query("camaroWatchlist")
        .withIndex("by_workspaceId", (index) =>
          index.eq("workspaceId", workspace._id)
        )
        .collect(),
      ctx.db
        .query("camaroIntents")
        .withIndex("by_workspaceId_createdAt", (index) =>
          index.eq("workspaceId", workspace._id)
        )
        .order("desc")
        .take(8),
      ctx.db
        .query("camaroAudit")
        .withIndex("by_workspaceId_createdAt", (index) =>
          index.eq("workspaceId", workspace._id)
        )
        .order("desc")
        .take(12),
    ]);

    return {
      workspace: { ...workspace, memberRole: membership.role },
      provider: providerState(),
      broker: {
        status: "not_connected" as const,
        label: "Broker read-only connection unavailable",
        detail:
          "No broker session is connected. Account, positions, orders, fills, and reconciliation values are intentionally empty.",
      },
      watchlist,
      intents,
      audit,
    };
  },
});

export const seedExamples = mutation({
  args: { workspaceId: v.id("workspaces") },
  handler: async (ctx, args) => {
    const { userId } = await requireMembership(ctx, args.workspaceId);
    const existing = await ctx.db
      .query("camaroWatchlist")
      .withIndex("by_workspaceId", (index) => index.eq("workspaceId", args.workspaceId))
      .collect();

    if (existing.length > 0) return existing.length;

    const now = Date.now();
    await Promise.all(
      EXAMPLE_WATCHLIST.map((entry) =>
        ctx.db.insert("camaroWatchlist", {
          workspaceId: args.workspaceId,
          symbol: entry.symbol,
          assetClass: entry.assetClass,
          createdBy: userId,
          createdAt: now,
        })
      )
    );

    await ctx.db.insert("camaroAudit", {
      workspaceId: args.workspaceId,
      eventType: "watchlist_seeded",
      summary: "Neutral example watchlist added by workspace member.",
      createdBy: userId,
      createdAt: now,
    });

    return EXAMPLE_WATCHLIST.length;
  },
});

export const addWatchlistSymbol = mutation({
  args: {
    workspaceId: v.id("workspaces"),
    symbol: v.string(),
    assetClass,
  },
  handler: async (ctx, args) => {
    const { userId } = await requireMembership(ctx, args.workspaceId);
    const symbol = args.symbol.trim().toUpperCase();
    if (!symbol) throw new Error("Symbol is required");
    if (symbol.length > 20) throw new Error("Symbol must be 20 characters or fewer");

    const existing = await ctx.db
      .query("camaroWatchlist")
      .withIndex("by_workspaceId_symbol", (index) =>
        index.eq("workspaceId", args.workspaceId).eq("symbol", symbol)
      )
      .unique();
    if (existing) throw new Error(`${symbol} is already on the watchlist`);

    const now = Date.now();
    const watchlistId = await ctx.db.insert("camaroWatchlist", {
      workspaceId: args.workspaceId,
      symbol,
      assetClass: args.assetClass,
      createdBy: userId,
      createdAt: now,
    });

    await ctx.db.insert("camaroAudit", {
      workspaceId: args.workspaceId,
      eventType: "watchlist_added",
      summary: `${symbol} added to the ${args.assetClass} watchlist.`,
      createdBy: userId,
      createdAt: now,
    });

    return watchlistId;
  },
});

export const removeWatchlistSymbol = mutation({
  args: { watchlistId: v.id("camaroWatchlist") },
  handler: async (ctx, args) => {
    const item = await ctx.db.get(args.watchlistId);
    if (!item) throw new Error("Watchlist symbol not found");
    const { userId } = await requireMembership(ctx, item.workspaceId);

    await ctx.db.delete(args.watchlistId);
    await ctx.db.insert("camaroAudit", {
      workspaceId: item.workspaceId,
      eventType: "watchlist_removed",
      summary: `${item.symbol} removed from the watchlist.`,
      createdBy: userId,
      createdAt: Date.now(),
    });
  },
});

export const createIntent = mutation({
  args: {
    workspaceId: v.id("workspaces"),
    symbol: v.string(),
    assetClass,
    horizon,
    thesis: v.string(),
    confidence: v.number(),
  },
  handler: async (ctx, args) => {
    const { userId } = await requireMembership(ctx, args.workspaceId);
    const thesis = args.thesis.trim();
    if (thesis.length < 10) throw new Error("Provide a thesis of at least 10 characters");
    if (thesis.length > 1200) throw new Error("Thesis must be 1200 characters or fewer");
    if (args.confidence < 0 || args.confidence > 1) {
      throw new Error("Confidence must be between 0 and 1");
    }

    const symbol = args.symbol.trim().toUpperCase();
    const activeIntent = await ctx.db
      .query("camaroIntents")
      .withIndex("by_workspaceId_symbol", (index) =>
        index.eq("workspaceId", args.workspaceId).eq("symbol", symbol)
      )
      .filter((filter) => filter.eq(filter.field("status"), "awaiting_approval"))
      .first();

    const marketData = providerState();
    const blockedReasons = [
      marketData.status === "not_configured"
        ? "Market-data provider is not configured; Camaro cannot evaluate a live market snapshot."
        : "Market-data adapter is not enabled for this runtime release.",
      "Broker read-only connection is not configured; account, positions, and reconciliation are unavailable.",
      "Live order routing is unavailable by doctrine. No order can be placed from this cockpit.",
    ];
    if (activeIntent) {
      blockedReasons.push(`An awaiting-approval intent already exists for ${symbol}.`);
    }

    const riskChecks = [
      {
        name: "Market data freshness",
        state: "blocked" as const,
        detail: blockedReasons[0],
      },
      {
        name: "Duplicate symbol",
        state: activeIntent ? ("blocked" as const) : ("clear" as const),
        detail: activeIntent
          ? `Existing intent ${activeIntent._id} is awaiting approval.`
          : "No awaiting-approval intent is recorded for this symbol.",
      },
      {
        name: "Exposure and position state",
        state: "unavailable" as const,
        detail:
          "Requires a future read-only broker account and positions reconciliation connection.",
      },
      {
        name: "Authority and execution",
        state: "blocked" as const,
        detail: "Approval-only mode is active; autonomous and live order execution are unavailable.",
      },
    ];

    const now = Date.now();
    const intentId = await ctx.db.insert("camaroIntents", {
      workspaceId: args.workspaceId,
      symbol,
      assetClass: args.assetClass,
      horizon: args.horizon,
      thesis,
      confidence: args.confidence,
      status: "blocked",
      blockedReasons,
      riskChecks,
      createdBy: userId,
      createdAt: now,
    });

    await ctx.db.insert("camaroAudit", {
      workspaceId: args.workspaceId,
      eventType: "decision_receipt_created",
      summary: `Decision-support intent for ${symbol} was created and blocked before execution.`,
      intentId,
      createdBy: userId,
      createdAt: now,
    });

    return intentId;
  },
});
