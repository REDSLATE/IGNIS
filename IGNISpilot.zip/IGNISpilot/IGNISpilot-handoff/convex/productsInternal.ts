import { internalQuery } from "./_generated/server";
import { v } from "convex/values";

export const getByPlatformProductId = internalQuery({ args: { platformProductId: v.string() }, handler: (ctx, args) => ctx.db.query("products").withIndex("by_platformProductId", (index) => index.eq("platformProductId", args.platformProductId)).unique() });
