import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

export default defineSchema({
  ...authTables,
  users: defineTable({
    name: v.optional(v.string()),
    email: v.optional(v.string()),
    emailVerificationTime: v.optional(v.number()),
    image: v.optional(v.string()),
    isAnonymous: v.optional(v.boolean()),
    role: v.optional(
      v.union(v.literal("owner"), v.literal("admin"), v.literal("member"))
    ),
    onboardingComplete: v.optional(v.boolean()),
    createdAt: v.optional(v.number()),
  }).index("email", ["email"]),

  workspaces: defineTable({
    name: v.string(),
    slug: v.string(),
    ownerId: v.id("users"),
    plan: v.union(
      v.literal("free"),
      v.literal("pro"),
      v.literal("enterprise")
    ),
    trialEndsAt: v.optional(v.number()),
    platformProductId: v.optional(v.string()),
    checkoutUrl: v.optional(v.string()),
    subscriptionStatus: v.optional(
      v.union(
        v.literal("active"),
        v.literal("trialing"),
        v.literal("past_due"),
        v.literal("canceled"),
        v.literal("inactive")
      )
    ),
    memberCount: v.number(),
    createdAt: v.number(),
    updatedAt: v.number(),
  })
    .index("by_slug", ["slug"])
    .index("by_ownerId", ["ownerId"])
    .index("by_platformProductId", ["platformProductId"]),

  workspaceMembers: defineTable({
    workspaceId: v.id("workspaces"),
    userId: v.id("users"),
    role: v.union(
      v.literal("owner"),
      v.literal("admin"),
      v.literal("member")
    ),
    invitedAt: v.optional(v.number()),
    joinedAt: v.number(),
  })
    .index("by_workspaceId", ["workspaceId"])
    .index("by_userId", ["userId"])
    .index("by_workspaceId_userId", ["workspaceId", "userId"]),

  invitations: defineTable({
    workspaceId: v.id("workspaces"),
    email: v.string(),
    role: v.union(
      v.literal("admin"),
      v.literal("member")
    ),
    invitedBy: v.id("users"),
    token: v.string(),
    expiresAt: v.number(),
    acceptedAt: v.optional(v.number()),
  })
    .index("by_workspaceId", ["workspaceId"])
    .index("by_email", ["email"])
    .index("by_token", ["token"]),

  camaroWatchlist: defineTable({
    workspaceId: v.id("workspaces"),
    symbol: v.string(),
    assetClass: v.union(v.literal("equity"), v.literal("crypto")),
    createdBy: v.id("users"),
    createdAt: v.number(),
  })
    .index("by_workspaceId", ["workspaceId"])
    .index("by_workspaceId_symbol", ["workspaceId", "symbol"]),

  camaroIntents: defineTable({
    workspaceId: v.id("workspaces"),
    symbol: v.string(),
    assetClass: v.union(v.literal("equity"), v.literal("crypto")),
    horizon: v.union(
      v.literal("intraday"),
      v.literal("swing"),
      v.literal("position")
    ),
    thesis: v.string(),
    confidence: v.number(),
    economicFingerprint: v.optional(v.string()),
    strategy: v.optional(v.string()),
    direction: v.optional(v.union(v.literal("long"), v.literal("short"))),
    entryZone: v.optional(v.number()),
    atr: v.optional(v.number()),
    status: v.union(v.literal("blocked"), v.literal("awaiting_approval")),
    blockedReasons: v.array(v.string()),
    riskChecks: v.array(
      v.object({
        name: v.string(),
        state: v.union(v.literal("clear"), v.literal("blocked"), v.literal("unavailable")),
        detail: v.string(),
      })
    ),
    createdBy: v.id("users"),
    createdAt: v.number(),
  })
    .index("by_workspaceId_createdAt", ["workspaceId", "createdAt"])
    .index("by_workspaceId_symbol", ["workspaceId", "symbol"])
    .index("by_workspaceId_economicFingerprint", ["workspaceId", "economicFingerprint"]),

  camaroAudit: defineTable({
    workspaceId: v.id("workspaces"),
    eventType: v.string(),
    summary: v.string(),
    intentId: v.optional(v.id("camaroIntents")),
    createdBy: v.id("users"),
    createdAt: v.number(),
  }).index("by_workspaceId_createdAt", ["workspaceId", "createdAt"]),

  camaroOpportunityConfig: defineTable({
    workspaceId: v.id("workspaces"),
    universe: v.array(v.object({ symbol: v.string(), assetClass: v.union(v.literal("equity"), v.literal("crypto")) })),
    topN: v.number(),
    capitalPressureThreshold: v.number(),
    modelWeights: v.object({
      momentumBreakout: v.number(),
      meanReversion: v.number(),
      fundingArbitrage: v.number(),
      optionsFlow: v.number(),
      trendFollowing: v.number(),
    }),
    resolvedLoopCount: v.number(),
    updatedBy: v.id("users"),
    updatedAt: v.number(),
  }).index("by_workspaceId", ["workspaceId"]),

  camaroOpportunityScans: defineTable({
    workspaceId: v.id("workspaces"),
    symbol: v.string(),
    assetClass: v.union(v.literal("equity"), v.literal("crypto")),
    strategy: v.string(),
    direction: v.union(v.literal("long"), v.literal("short")),
    timeframe: v.union(v.literal("intraday"), v.literal("swing"), v.literal("position")),
    entryZone: v.number(),
    atr: v.number(),
    expectedEdge: v.number(),
    conviction: v.number(),
    adaptiveScore: v.number(),
    modelContributions: v.object({
      momentumBreakout: v.number(),
      meanReversion: v.number(),
      fundingArbitrage: v.number(),
      optionsFlow: v.number(),
      trendFollowing: v.number(),
    }),
    rank: v.number(),
    selectedForCognition: v.boolean(),
    createdBy: v.id("users"),
    createdAt: v.number(),
  })
    .index("by_workspaceId_createdAt", ["workspaceId", "createdAt"])
    .index("by_workspaceId_symbol", ["workspaceId", "symbol"]),

  camaroPatternResearch: defineTable({
    workspaceId: v.id("workspaces"),
    symbol: v.string(),
    timeframe: v.union(v.literal("intraday"), v.literal("swing"), v.literal("position")),
    pattern: v.union(v.literal("double_top"), v.literal("head_and_shoulders"), v.literal("rising_wedge"), v.literal("double_bottom"), v.literal("inverse_head_and_shoulders"), v.literal("falling_wedge")),
    state: v.union(v.literal("forming"), v.literal("confirmed"), v.literal("invalidated"), v.literal("blocked")),
    confidence: v.number(),
    freshness: v.union(v.literal("recent"), v.literal("stale")),
    necklineOrSupport: v.optional(v.number()),
    invalidationLevel: v.optional(v.number()),
    latestClose: v.number(),
    detail: v.string(),
    criteria: v.array(v.object({ label: v.string(), met: v.boolean(), detail: v.string() })),
    createdBy: v.id("users"),
    createdAt: v.number(),
  })
    .index("by_workspaceId_createdAt", ["workspaceId", "createdAt"])
    .index("by_workspaceId_symbol_createdAt", ["workspaceId", "symbol", "createdAt"]),

  camaroAdaptiveKernelUpdates: defineTable({
    workspaceId: v.id("workspaces"),
    resolvedLoopCount: v.number(),
    status: v.union(v.literal("default_retained"), v.literal("updated")),
    priorWeights: v.object({ momentumBreakout: v.number(), meanReversion: v.number(), fundingArbitrage: v.number(), optionsFlow: v.number(), trendFollowing: v.number() }),
    nextWeights: v.object({ momentumBreakout: v.number(), meanReversion: v.number(), fundingArbitrage: v.number(), optionsFlow: v.number(), trendFollowing: v.number() }),
    detail: v.string(),
    createdBy: v.id("users"),
    createdAt: v.number(),
  }).index("by_workspaceId_createdAt", ["workspaceId", "createdAt"]),

  camaroProviderConnections: defineTable({
    workspaceId: v.id("workspaces"),
    providerId: v.string(),
    providerName: v.string(),
    connectionMode: v.union(
      v.literal("oauth"),
      v.literal("api_key"),
      v.literal("personal_access_token"),
      v.literal("manual_import")
    ),
    status: v.union(
      v.literal("manual_import_ready"),
      v.literal("not_connected"),
      v.literal("connected_read_only"),
      v.literal("sync_unavailable")
    ),
    createdBy: v.id("users"),
    createdAt: v.number(),
    updatedAt: v.number(),
    lastSyncedAt: v.optional(v.number()),
  })
    .index("by_workspaceId", ["workspaceId"])
    .index("by_workspaceId_providerId", ["workspaceId", "providerId"]),

  camaroBrokerConsents: defineTable({
    workspaceId: v.id("workspaces"),
    userId: v.id("users"),
    providerId: v.literal("public"),
    connectionReference: v.string(),
    modeRequested: v.union(
      v.literal("read_only"),
      v.literal("paper"),
      v.literal("operator_confirmed"),
      v.literal("live_capable")
    ),
    termsVersion: v.string(),
    disclosureVersion: v.string(),
    disclosureText: v.string(),
    disclosureHash: v.string(),
    createdAt: v.number(),
  })
    .index("by_workspaceId_userId_createdAt", ["workspaceId", "userId", "createdAt"])
    .index("by_workspaceId_providerId_createdAt", ["workspaceId", "providerId", "createdAt"]),

  camaroExecutionSettings: defineTable({
    workspaceId: v.id("workspaces"),
    providerId: v.literal("public"),
    mode: v.union(
      v.literal("READ_ONLY"),
      v.literal("PAPER"),
      v.literal("OPERATOR_CONFIRM_REQUIRED"),
      v.literal("LIVE_DISABLED_PENDING_ENABLEMENT")
    ),
    selectedBy: v.id("users"),
    selectedAt: v.number(),
    liveOrderGateEnabled: v.optional(v.boolean()),
    liveOrderGateEnabledBy: v.optional(v.id("users")),
    liveOrderGateEnabledAt: v.optional(v.number()),
    updatedAt: v.number(),
  }).index("by_workspaceId_providerId", ["workspaceId", "providerId"]),

  camaroExecutionIntents: defineTable({
    workspaceId: v.id("workspaces"),
    providerId: v.literal("public"),
    intentHash: v.string(),
    symbol: v.string(),
    side: v.union(v.literal("buy"), v.literal("sell")),
    quantity: v.optional(v.number()),
    notional: v.optional(v.number()),
    orderType: v.union(v.literal("market"), v.literal("limit")),
    timeInForce: v.literal("day"),
    limitPrice: v.optional(v.number()),
    accountReference: v.string(),
    authorityScope: v.string(),
    preflightStatus: v.union(v.literal("pending"), v.literal("passed"), v.literal("failed")),
    preflightedAt: v.number(),
    preflightVerifiedAt: v.optional(v.number()),
    ownerApprovalStatus: v.union(v.literal("pending"), v.literal("approved"), v.literal("rejected")),
    ownerApprovedBy: v.optional(v.id("users")),
    ownerApprovedAt: v.optional(v.number()),
    riskStatus: v.union(v.literal("pending"), v.literal("passed"), v.literal("failed")),
    riskSummary: v.string(),
    submissionAttemptCount: v.optional(v.number()),
    expiresAt: v.number(),
    idempotencyKey: v.string(),
    orderId: v.optional(v.string()),
    externalOrderReference: v.optional(v.string()),
    filledQuantity: v.optional(v.number()),
    orderStatus: v.optional(v.union(v.literal("submitted"), v.literal("accepted"), v.literal("partially_filled"), v.literal("filled"), v.literal("rejected"), v.literal("cancel_pending"), v.literal("cancelled"), v.literal("unknown"))),
    status: v.union(v.literal("awaiting_confirmation"), v.literal("submitting"), v.literal("submitted"), v.literal("accepted"), v.literal("partially_filled"), v.literal("filled"), v.literal("rejected"), v.literal("cancel_pending"), v.literal("cancelled"), v.literal("blocked"), v.literal("expired")),
    createdBy: v.id("users"),
    createdAt: v.number(),
  })
    .index("by_workspaceId_createdAt", ["workspaceId", "createdAt"])
    .index("by_workspaceId_symbol_status", ["workspaceId", "symbol", "status"])
    .index("by_workspaceId_intentHash", ["workspaceId", "intentHash"]),

  camaroExecutionReceipts: defineTable({
    workspaceId: v.id("workspaces"),
    providerId: v.literal("public"),
    eventType: v.union(
      v.literal("mode_changed"),
      v.literal("intent_created"),
      v.literal("preflight_passed"),
      v.literal("preflight_failed"),
      v.literal("confirmation_requested"),
      v.literal("owner_approval_recorded"),
      v.literal("confirmation_rejected"),
      v.literal("intent_timed_out"),
      v.literal("execution_blocked"),
      v.literal("submission_attempt"),
      v.literal("broker_accepted"),
      v.literal("broker_rejected"),
      v.literal("submission_failed"),
      v.literal("status_updated"),
      v.literal("fill_recorded"),
      v.literal("cancellation_attempt"),
      v.literal("cancellation_result"),
      v.literal("live_order_gate_changed")
    ),
    intentId: v.optional(v.id("camaroExecutionIntents")),
    orderId: v.optional(v.string()),
    retryState: v.optional(v.union(v.literal("initial"), v.literal("retry"), v.literal("duplicate_blocked"))),
    outboundAttemptResult: v.optional(v.union(v.literal("started"), v.literal("accepted"), v.literal("rejected"), v.literal("failed"), v.literal("not_sent"))),
    blockReason: v.optional(v.string()),
    summary: v.string(),
    createdBy: v.id("users"),
    createdAt: v.number(),
  }).index("by_workspaceId_createdAt", ["workspaceId", "createdAt"]),

  camaroBrokerSnapshots: defineTable({
    workspaceId: v.id("workspaces"),
    connectionId: v.id("camaroProviderConnections"),
    providerId: v.string(),
    accounts: v.array(v.object({
      accountLabel: v.string(),
      accountType: v.optional(v.string()),
      available: v.optional(v.number()),
      total: v.optional(v.number()),
    })),
    positions: v.array(v.object({
      symbol: v.string(),
      assetClass: v.union(v.literal("equity"), v.literal("crypto")),
      quantity: v.number(),
      averageEntryPrice: v.optional(v.number()),
      marketValue: v.optional(v.number()),
      expectedEdge: v.optional(v.number()),
    })),
    syncedAt: v.number(),
    createdAt: v.number(),
  }).index("by_workspaceId_syncedAt", ["workspaceId", "syncedAt"]),

  camaroReconciliationReceipts: defineTable({
    workspaceId: v.id("workspaces"),
    connectionId: v.optional(v.id("camaroProviderConnections")),
    providerId: v.string(),
    status: v.union(
      v.literal("unavailable"),
      v.literal("no_data"),
      v.literal("reconciled"),
      v.literal("attention")
    ),
    summary: v.string(),
    comparedIntentCount: v.number(),
    externalPositionCount: v.number(),
    externalOrderCount: v.number(),
    discrepancyCount: v.number(),
    createdBy: v.id("users"),
    createdAt: v.number(),
  }).index("by_workspaceId_createdAt", ["workspaceId", "createdAt"]),

  camaroRuntimeHeartbeats: defineTable({
    workspaceId: v.id("workspaces"),
    runtime: v.literal("camaro"),
    source: v.literal("operator_recorded"),
    status: v.union(v.literal("available"), v.literal("stale"), v.literal("unavailable")),
    tokenCheck: v.union(v.literal("verified"), v.literal("unavailable"), v.literal("not_configured")),
    missionControlState: v.union(v.literal("connected"), v.literal("unavailable")),
    detail: v.string(),
    recordedBy: v.id("users"),
    recordedAt: v.number(),
  }).index("by_workspaceId_createdAt", ["workspaceId", "recordedAt"]),

  camaroStances: defineTable({
    workspaceId: v.id("workspaces"),
    runtime: v.literal("camaro"),
    symbol: v.string(),
    assetClass: v.union(v.literal("equity"), v.literal("crypto")),
    side: v.union(v.literal("long"), v.literal("short"), v.literal("neutral")),
    confidence: v.number(),
    rationale: v.string(),
    resolution: v.union(v.literal("published"), v.literal("challenged")),
    createdBy: v.id("users"),
    createdAt: v.number(),
  }).index("by_workspaceId_createdAt", ["workspaceId", "createdAt"]),

  camaroChallenges: defineTable({
    workspaceId: v.id("workspaces"),
    stanceId: v.id("camaroStances"),
    targetRuntime: v.string(),
    counterSide: v.union(v.literal("long"), v.literal("short"), v.literal("neutral")),
    rationale: v.string(),
    status: v.union(v.literal("open"), v.literal("acknowledged")),
    createdBy: v.id("users"),
    createdAt: v.number(),
  }).index("by_workspaceId_createdAt", ["workspaceId", "createdAt"]),

  camaroOutcomes: defineTable({
    workspaceId: v.id("workspaces"),
    intentId: v.optional(v.id("camaroIntents")),
    disposition: v.union(v.literal("observed"), v.literal("unresolved"), v.literal("blocked")),
    summary: v.string(),
    createdBy: v.id("users"),
    createdAt: v.number(),
  }).index("by_workspaceId_createdAt", ["workspaceId", "createdAt"]),

  camaroPromotionReadiness: defineTable({
    workspaceId: v.id("workspaces"),
    artifactName: v.string(),
    stage: v.literal("inspection"),
    status: v.union(v.literal("not_ready"), v.literal("ready")),
    blockers: v.array(v.string()),
    createdBy: v.id("users"),
    createdAt: v.number(),
  }).index("by_workspaceId_createdAt", ["workspaceId", "createdAt"]),

  camaroRuntimeReceipts: defineTable({
    workspaceId: v.id("workspaces"),
    receiptType: v.union(
      v.literal("heartbeat"),
      v.literal("stance"),
      v.literal("challenge"),
      v.literal("outcome"),
      v.literal("promotion"),
      v.literal("doctrine_check")
    ),
    summary: v.string(),
    subjectType: v.union(v.literal("runtime"), v.literal("stance"), v.literal("intent"), v.literal("promotion"), v.literal("doctrine")),
    subjectId: v.optional(v.string()),
    createdBy: v.id("users"),
    createdAt: v.number(),
  }).index("by_workspaceId_createdAt", ["workspaceId", "createdAt"]),

  camaroCreditBalances: defineTable({
    workspaceId: v.id("workspaces"),
    availableCredits: v.number(),
    lastIncludedGrantPeriod: v.optional(v.string()),
    updatedAt: v.number(),
  }).index("by_workspaceId", ["workspaceId"]),

  camaroCreditLedger: defineTable({
    workspaceId: v.id("workspaces"),
    entryType: v.union(
      v.literal("included_grant"),
      v.literal("manual_grant"),
      v.literal("platform_grant"),
      v.literal("debit"),
      v.literal("refund"),
      v.literal("blocked")
    ),
    action: v.optional(
      v.union(
        v.literal("historical_simulation"),
        v.literal("extended_replay"),
        v.literal("resolved_outcome_training"),
        v.literal("advanced_challenge_pack")
      )
    ),
    amount: v.number(),
    balanceAfter: v.number(),
    idempotencyKey: v.string(),
    source: v.union(
      v.literal("monthly_included"),
      v.literal("manual_top_up"),
      v.literal("platform_checkout"),
      v.literal("optional_compute"),
      v.literal("compensation")
    ),
    summary: v.string(),
    reference: v.optional(v.string()),
    packId: v.optional(v.string()),
    platformOrderId: v.optional(v.string()),
    checkoutSessionId: v.optional(v.string()),
    actorSource: v.optional(v.string()),
    createdBy: v.id("users"),
    createdAt: v.number(),
  })
    .index("by_workspaceId_createdAt", ["workspaceId", "createdAt"])
    .index("by_workspaceId_idempotencyKey", ["workspaceId", "idempotencyKey"])
    .index("by_platformOrderId", ["platformOrderId"]),

  blogPosts: defineTable({
    title: v.string(),
    slug: v.string(),
    content: v.string(),
    excerpt: v.optional(v.string()),
    publishedAt: v.optional(v.number()),
    authorId: v.optional(v.id("users")),
    status: v.union(v.literal("draft"), v.literal("published")),
    createdAt: v.number(),
    updatedAt: v.number(),
  })
    .index("by_slug", ["slug"])
    .index("by_status", ["status"])
    .index("by_publishedAt", ["publishedAt"]),

  products: defineTable({
    title: v.string(),
    description: v.optional(v.string()),
    priceAmountCents: v.number(),
    currency: v.string(),
    status: v.union(
      v.literal("active"),
      v.literal("draft"),
      v.literal("archived")
    ),
    coverImageUrl: v.optional(v.string()),
    platformProductId: v.string(),
    checkoutUrl: v.optional(v.string()),
    createdAt: v.number(),
    updatedAt: v.number(),
  })
    .index("by_platformProductId", ["platformProductId"])
    .index("by_status", ["status"]),
});
