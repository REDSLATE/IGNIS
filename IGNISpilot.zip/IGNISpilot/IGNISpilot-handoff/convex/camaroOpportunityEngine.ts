import { mutation, query } from "./_generated/server";
import type { MutationCtx, QueryCtx } from "./_generated/server";
import type { Id } from "./_generated/dataModel";
import { getAuthUserId } from "@convex-dev/auth/server";
import { v } from "convex/values";
import { assessBearishPatterns } from "./camaroBearishPatterns";
import { assessBullishPatterns } from "./camaroBullishPatterns";

export const DEFAULT_UNIVERSE = [
  { symbol: "AAPL", assetClass: "equity" as const },
  { symbol: "TSLA", assetClass: "equity" as const },
  { symbol: "NVDA", assetClass: "equity" as const },
  { symbol: "SPY", assetClass: "equity" as const },
  { symbol: "BTC-USD", assetClass: "crypto" as const },
  { symbol: "ETH-USD", assetClass: "crypto" as const },
];

const DEFAULT_WEIGHTS = {
  momentumBreakout: 0.2,
  meanReversion: 0.2,
  fundingArbitrage: 0.2,
  optionsFlow: 0.2,
  trendFollowing: 0.2,
};

const timeframe = v.union(v.literal("intraday"), v.literal("swing"), v.literal("position"));
const assetClass = v.union(v.literal("equity"), v.literal("crypto"));
const direction = v.union(v.literal("long"), v.literal("short"));
const contributionValidator = v.object({
  momentumBreakout: v.number(), meanReversion: v.number(), fundingArbitrage: v.number(), optionsFlow: v.number(), trendFollowing: v.number(),
});

type Weights = typeof DEFAULT_WEIGHTS;
type Contributions = Weights;

async function requireMembership(ctx: MutationCtx | QueryCtx, workspaceId: Id<"workspaces">) {
  const userId = await getAuthUserId(ctx);
  if (!userId) throw new Error("Not authenticated");
  const membership = await ctx.db.query("workspaceMembers").withIndex("by_workspaceId_userId", (index) => index.eq("workspaceId", workspaceId).eq("userId", userId)).unique();
  if (!membership) throw new Error("Workspace access denied");
  return { userId, membership };
}

function normalizeSymbol(symbol: string) {
  const normalized = symbol.trim().toUpperCase();
  if (!normalized || normalized.length > 20) throw new Error("Provide a valid symbol");
  return normalized;
}

function normalizedWeights(weights: Weights): Weights {
  const total = Object.values(weights).reduce((sum, value) => sum + Math.max(0, value), 0);
  if (total <= 0) return DEFAULT_WEIGHTS;
  return Object.fromEntries(Object.entries(weights).map(([key, value]) => [key, Math.max(0, value) / total])) as Weights;
}

export async function economic_fingerprint(symbol: string, strategy: string, directionValue: "long" | "short", timeframeValue: "intraday" | "swing" | "position", entry_zone: number, atr = 1.0) {
  if (!Number.isFinite(entry_zone) || !Number.isFinite(atr) || atr <= 0) throw new Error("Entry zone and ATR must be finite positive numbers");
  const zone_size = Math.max(atr * 0.25, Math.abs(entry_zone) * 0.001);
  const normalized_zone = Math.round(entry_zone / zone_size);
  const canonical = [normalizeSymbol(symbol), strategy.trim().toLowerCase(), directionValue, timeframeValue, normalized_zone].join("|");
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(canonical));
  return Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, "0")).join("");
}

function weightedScore(contributions: Contributions, weights: Weights) {
  return Object.entries(weights).reduce((score, [key, weight]) => score + contributions[key as keyof Contributions] * weight, 0);
}

export function create_jarvis(config?: { topN?: number; capitalPressureThreshold?: number }) {
  return {
    config: { topN: config?.topN ?? 3, capitalPressureThreshold: config?.capitalPressureThreshold ?? 0.15 },
    feeds: "perception snapshots supplied to scan",
    models: ["MomentumBreakout", "MeanReversion", "FundingArbitrage", "OptionsFlow", "TrendFollowing"],
    cognition: "Forven thesis generation for ranked top-N only",
    services: ["sizing", "portfolio", "learning", "adaptive kernel", "opportunity engine", "capital pressure", "broker reconciler", "startup health"],
    execution: "intent-only; existing authority, consent, risk, and live-order gates remain required",
    universe: DEFAULT_UNIVERSE,
  };
}

export const bootstrapJarvis = mutation({
  args: { workspaceId: v.id("workspaces"), topN: v.optional(v.number()), capitalPressureThreshold: v.optional(v.number()) },
  handler: async (ctx, args) => {
    const { userId } = await requireMembership(ctx, args.workspaceId);
    const runtime = create_jarvis({ topN: args.topN, capitalPressureThreshold: args.capitalPressureThreshold });
    if (!Number.isInteger(runtime.config.topN) || runtime.config.topN < 1 || runtime.config.topN > runtime.universe.length) throw new Error("topN must fit the configured universe");
    if (!Number.isFinite(runtime.config.capitalPressureThreshold) || runtime.config.capitalPressureThreshold < 0) throw new Error("capital pressure threshold must be non-negative");
    const now = Date.now();
    const existing = await ctx.db.query("camaroOpportunityConfig").withIndex("by_workspaceId", (index) => index.eq("workspaceId", args.workspaceId)).unique();
    const values = { universe: runtime.universe, topN: runtime.config.topN, capitalPressureThreshold: runtime.config.capitalPressureThreshold, modelWeights: DEFAULT_WEIGHTS, resolvedLoopCount: 0, updatedBy: userId, updatedAt: now };
    if (existing) await ctx.db.patch(existing._id, values); else await ctx.db.insert("camaroOpportunityConfig", { workspaceId: args.workspaceId, ...values });
    for (const entry of runtime.universe) {
      const watchlist = await ctx.db.query("camaroWatchlist").withIndex("by_workspaceId_symbol", (index) => index.eq("workspaceId", args.workspaceId).eq("symbol", entry.symbol)).unique();
      if (!watchlist) await ctx.db.insert("camaroWatchlist", { workspaceId: args.workspaceId, ...entry, createdBy: userId, createdAt: now });
    }
    await ctx.db.insert("camaroAudit", { workspaceId: args.workspaceId, eventType: "jarvis_bootstrap_recorded", summary: "Jarvis bootstrap recorded with a discovery-only opportunity engine; no broker authority or order route was enabled.", createdBy: userId, createdAt: now });
    return runtime;
  },
});

export const scanUniverse = mutation({
  args: { workspaceId: v.id("workspaces"), snapshots: v.array(v.object({ symbol: v.string(), strategy: v.string(), direction, timeframe, entryZone: v.number(), atr: v.number(), expectedEdge: v.number(), conviction: v.number(), contributions: contributionValidator })) },
  handler: async (ctx, args) => {
    const { userId } = await requireMembership(ctx, args.workspaceId);
    const config = await ctx.db.query("camaroOpportunityConfig").withIndex("by_workspaceId", (index) => index.eq("workspaceId", args.workspaceId)).unique();
    if (!config) throw new Error("Bootstrap Jarvis before scanning the configured universe");
    const supplied = new Map(args.snapshots.map((snapshot) => [normalizeSymbol(snapshot.symbol), snapshot]));
    if (supplied.size !== config.universe.length || config.universe.some((entry) => !supplied.has(entry.symbol))) throw new Error("A discovery scan requires one perception snapshot for every configured universe symbol");
    const ranked = config.universe.map((entry) => {
      const snapshot = supplied.get(entry.symbol)!;
      return {
        symbol: entry.symbol,
        assetClass: entry.assetClass,
        strategy: snapshot.strategy.trim(),
        direction: snapshot.direction,
        timeframe: snapshot.timeframe,
        entryZone: snapshot.entryZone,
        atr: snapshot.atr,
        expectedEdge: snapshot.expectedEdge,
        conviction: snapshot.conviction,
        modelContributions: snapshot.contributions,
        adaptiveScore: weightedScore(snapshot.contributions, config.modelWeights),
      };
    }).sort((left, right) => right.adaptiveScore - left.adaptiveScore);
    const now = Date.now();
    await Promise.all(ranked.map((opportunity, index) => ctx.db.insert("camaroOpportunityScans", { workspaceId: args.workspaceId, ...opportunity, rank: index + 1, selectedForCognition: index < config.topN, createdBy: userId, createdAt: now })));
    await ctx.db.insert("camaroAudit", { workspaceId: args.workspaceId, eventType: "opportunity_scan_recorded", summary: `Discovery-only scan ranked ${ranked.length} configured symbols and sent the top ${config.topN} to Forven cognition. No intent or broker order was created.`, createdBy: userId, createdAt: now });
    return ranked.slice(0, config.topN).map((opportunity, index) => ({ ...opportunity, rank: index + 1, selectedForCognition: true }));
  },
});

export const recordBearishPatternResearch = mutation({
  args: {
    workspaceId: v.id("workspaces"),
    symbol: v.string(),
    timeframe,
    bars: v.array(v.object({ timestamp: v.number(), high: v.number(), low: v.number(), close: v.number() })),
  },
  handler: async (ctx, args) => {
    const { userId } = await requireMembership(ctx, args.workspaceId);
    const symbol = normalizeSymbol(args.symbol);
    if (!args.bars.length) throw new Error("Provide ordered OHLC bars for read-only pattern research");
    const now = Date.now();
    const assessments = assessBearishPatterns(args.bars, now);
    for (const assessment of assessments) {
      const state = assessment.state as "forming" | "confirmed" | "invalidated" | "blocked";
      const pattern = assessment.pattern as "double_top" | "head_and_shoulders" | "rising_wedge";
      const freshness = assessment.freshness as "recent" | "stale";
      await ctx.db.insert("camaroPatternResearch", { workspaceId: args.workspaceId, symbol, timeframe: args.timeframe, ...assessment, state, pattern, freshness, createdBy: userId, createdAt: now });
      const eventType = assessment.state === "confirmed" ? "bearish_pattern_detected" : assessment.state === "invalidated" ? "bearish_pattern_invalidated" : "bearish_pattern_blocked";
      await ctx.db.insert("camaroAudit", {
        workspaceId: args.workspaceId,
        eventType,
        summary: `${assessment.pattern} for ${symbol} is ${assessment.state}. ${assessment.detail} No execution intent, broker call, authority change, or live-order action was created.`,
        createdBy: userId,
        createdAt: now,
      });
    }
    return assessments;
  },
});

export const recordBullishPatternResearch = mutation({
  args: {
    workspaceId: v.id("workspaces"),
    symbol: v.string(),
    timeframe,
    bars: v.array(v.object({ timestamp: v.number(), high: v.number(), low: v.number(), close: v.number() })),
  },
  handler: async (ctx, args) => {
    const { userId } = await requireMembership(ctx, args.workspaceId);
    const symbol = normalizeSymbol(args.symbol);
    if (!args.bars.length) throw new Error("Provide ordered OHLC bars for read-only pattern research");
    const now = Date.now();
    const assessments = assessBullishPatterns(args.bars, now);
    for (const assessment of assessments) {
      const state = assessment.state as "forming" | "confirmed" | "invalidated" | "blocked";
      const pattern = assessment.pattern as "double_bottom" | "inverse_head_and_shoulders" | "falling_wedge";
      const freshness = assessment.freshness as "recent" | "stale";
      await ctx.db.insert("camaroPatternResearch", { workspaceId: args.workspaceId, symbol, timeframe: args.timeframe, ...assessment, state, pattern, freshness, createdBy: userId, createdAt: now });
      const eventType = assessment.state === "confirmed" ? "bullish_pattern_detected" : assessment.state === "invalidated" ? "bullish_pattern_invalidated" : "bullish_pattern_blocked";
      await ctx.db.insert("camaroAudit", {
        workspaceId: args.workspaceId,
        eventType,
        summary: `${assessment.pattern} for ${symbol} is ${assessment.state}. ${assessment.detail} No execution intent, broker call, authority change, or live-order action was created.`,
        createdBy: userId,
        createdAt: now,
      });
    }
    return assessments;
  },
});

export const createOpportunityPlan = mutation({
  args: { workspaceId: v.id("workspaces"), symbol: v.string(), assetClass, strategy: v.string(), direction, timeframe, entryZone: v.number(), atr: v.optional(v.number()), thesis: v.string(), conviction: v.number(), expectedEdge: v.number() },
  handler: async (ctx, args) => {
    const { userId } = await requireMembership(ctx, args.workspaceId);
    const symbol = normalizeSymbol(args.symbol);
    const thesis = args.thesis.trim();
    if (thesis.length < 10 || thesis.length > 1200) throw new Error("Provide a thesis between 10 and 1200 characters");
    if (![args.conviction, args.expectedEdge, args.entryZone, args.atr ?? 1].every(Number.isFinite) || args.conviction < 0 || args.conviction > 1) throw new Error("Plan values are invalid");
    const atr = args.atr ?? 1;
    const fingerprint = await economic_fingerprint(symbol, args.strategy, args.direction, args.timeframe, args.entryZone, atr);
    const prior = await ctx.db.query("camaroIntents").withIndex("by_workspaceId_economicFingerprint", (index) => index.eq("workspaceId", args.workspaceId).eq("economicFingerprint", fingerprint)).first();
    const now = Date.now();
    if (prior) {
      await ctx.db.insert("camaroAudit", {
        workspaceId: args.workspaceId,
        eventType: "opportunity_plan_deduplicated",
        summary: `Economically identical ${symbol} plan was blocked and deduplicated against ${prior._id}; no second plan was created and this receipt remains append-only.`,
        intentId: prior._id,
        createdBy: userId,
        createdAt: now,
      });
      return { intentId: prior._id, fingerprint, deduplicated: true, capitalPressure: null };
    }
    const intentId = await ctx.db.insert("camaroIntents", {
      workspaceId: args.workspaceId, symbol, assetClass: args.assetClass, horizon: args.timeframe, thesis, confidence: args.conviction,
      economicFingerprint: fingerprint, strategy: args.strategy.trim(), direction: args.direction, entryZone: args.entryZone, atr,
      status: "blocked", blockedReasons: ["Opportunity plans are discovery output only; existing authority, risk, consent, reconciliation, confirmation, and live-order gates remain required."],
      riskChecks: [{ name: "Economic deduplication", state: "clear", detail: `Fingerprint ${fingerprint} is not yet recorded.` }, { name: "Authority and execution", state: "blocked", detail: "A plan is not broker execution and cannot submit an order." }],
      createdBy: userId, createdAt: now,
    });
    await ctx.db.insert("camaroAudit", { workspaceId: args.workspaceId, eventType: "opportunity_plan_created", summary: `Discovery plan for ${symbol} was recorded as blocked pending all existing execution gates.`, intentId, createdBy: userId, createdAt: now });
    const latestSnapshot = await ctx.db.query("camaroBrokerSnapshots").withIndex("by_workspaceId_syncedAt", (index) => index.eq("workspaceId", args.workspaceId)).order("desc").first();
    const weakest = latestSnapshot?.positions.filter((position) => position.quantity !== 0).sort((left, right) => (left.expectedEdge ?? Number.POSITIVE_INFINITY) - (right.expectedEdge ?? Number.POSITIVE_INFINITY))[0];
    const config = await ctx.db.query("camaroOpportunityConfig").withIndex("by_workspaceId", (index) => index.eq("workspaceId", args.workspaceId)).unique();
    const pressure = weakest && config && weakest.expectedEdge !== undefined && args.expectedEdge - weakest.expectedEdge > config.capitalPressureThreshold
      ? { action: "REDUCE" as const, symbol: weakest.symbol, reason: `New-plan edge exceeds the weakest reconciled position by ${(args.expectedEdge - weakest.expectedEdge).toFixed(3)}. Recommendation only; no position was closed or broker order submitted.` }
      : null;
    if (pressure) await ctx.db.insert("camaroAudit", { workspaceId: args.workspaceId, eventType: "capital_pressure_reduce_recommended", summary: `${pressure.action} recommendation for ${pressure.symbol} paired with ${symbol}; non-executing and not a broker instruction.`, intentId, createdBy: userId, createdAt: now });
    return { intentId, fingerprint, deduplicated: false, capitalPressure: pressure };
  },
});

export const recordResolvedLoop = mutation({
  args: { workspaceId: v.id("workspaces"), performance: v.object({ momentumBreakout: v.optional(v.number()), meanReversion: v.optional(v.number()), fundingArbitrage: v.optional(v.number()), optionsFlow: v.optional(v.number()), trendFollowing: v.optional(v.number()) }) },
  handler: async (ctx, args) => {
    const { userId } = await requireMembership(ctx, args.workspaceId);
    const config = await ctx.db.query("camaroOpportunityConfig").withIndex("by_workspaceId", (index) => index.eq("workspaceId", args.workspaceId)).unique();
    if (!config) throw new Error("Bootstrap Jarvis before recording a resolved loop");
    const resolvedLoopCount = config.resolvedLoopCount + 1;
    const priorWeights = config.modelWeights;
    const available = Object.values(args.performance).filter((value): value is number => value !== undefined && Number.isFinite(value));
    const shouldUpdate = resolvedLoopCount % 5 === 0 && available.length >= 2;
    const raw = Object.fromEntries(Object.entries(priorWeights).map(([model, prior]) => [model, args.performance[model as keyof typeof args.performance] ?? prior])) as Weights;
    const nextWeights = shouldUpdate ? normalizedWeights(raw) : priorWeights;
    const now = Date.now();
    await ctx.db.patch(config._id, { resolvedLoopCount, modelWeights: nextWeights, updatedBy: userId, updatedAt: now });
    await ctx.db.insert("camaroAdaptiveKernelUpdates", { workspaceId: args.workspaceId, resolvedLoopCount, status: shouldUpdate ? "updated" : "default_retained", priorWeights, nextWeights, detail: shouldUpdate ? "AdaptiveKernel updated weights from supplied resolved-outcome performance at the five-loop cadence." : "AdaptiveKernel retained safe/default weights because the five-loop cadence or sufficient resolved performance was unavailable.", createdBy: userId, createdAt: now });
    return { resolvedLoopCount, updated: shouldUpdate, weights: nextWeights };
  },
});
