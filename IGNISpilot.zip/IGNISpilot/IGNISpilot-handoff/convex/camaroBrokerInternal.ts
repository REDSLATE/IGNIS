import { internalMutation, internalQuery } from "./_generated/server";
import { v } from "convex/values";
import { assertPublicOrderId } from "./publicOrderId.mjs";
import { reconcileBrokerSnapshot } from "./brokerAdapters";
import { isCurrentPublicConsent } from "./brokerConsent";
import { evaluatePublicOrderGate, evaluatePublicPreflightGate, PUBLIC_ORDER_BLOCK_REASONS } from "./publicOrderGate.mjs";

const assetClass = v.union(v.literal("equity"), v.literal("crypto"));

function publicSyncSummary(reason: "unauthorized" | "error" | "stale") {
  if (reason === "unauthorized") return "Public read-only sync was denied. Verify the server-side credential and account scope.";
  if (reason === "stale") return "Public read-only data is stale. The last verified snapshot is retained for inspection only.";
  return "Public read-only sync failed before a verified snapshot was recorded.";
}

export const recordPublicSyncUnavailable = internalMutation({
  args: {
    workspaceId: v.id("workspaces"),
    reason: v.union(v.literal("unauthorized"), v.literal("error"), v.literal("stale")),
  },
  handler: async (ctx, args) => {
    const connection = await ctx.db
      .query("camaroProviderConnections")
      .withIndex("by_workspaceId_providerId", (index) => index.eq("workspaceId", args.workspaceId).eq("providerId", "public"))
      .unique();
    if (!connection) return null;
    const now = Date.now();
    await ctx.db.patch(connection._id, { status: "sync_unavailable", updatedAt: now });
    await ctx.db.insert("camaroReconciliationReceipts", {
      workspaceId: args.workspaceId,
      connectionId: connection._id,
      providerId: "public",
      status: "unavailable",
      summary: publicSyncSummary(args.reason),
      comparedIntentCount: 0,
      externalPositionCount: 0,
      externalOrderCount: 0,
      discrepancyCount: 0,
      createdBy: connection.createdBy,
      createdAt: now,
    });
    await ctx.db.insert("camaroAudit", {
      workspaceId: args.workspaceId,
      eventType: `public_read_only_sync_${args.reason}`,
      summary: publicSyncSummary(args.reason),
      createdBy: connection.createdBy,
      createdAt: now,
    });
    return connection._id;
  },
});

export const recordPublicReadOnlySync = internalMutation({
  args: {
    workspaceId: v.id("workspaces"),
    accounts: v.array(v.object({ accountLabel: v.string(), accountType: v.optional(v.string()), available: v.optional(v.number()), total: v.optional(v.number()) })),
    positions: v.array(v.object({ symbol: v.string(), assetClass, quantity: v.number(), averageEntryPrice: v.optional(v.number()), marketValue: v.optional(v.number()) })),
  },
  handler: async (ctx, args) => {
    const connection = await ctx.db
      .query("camaroProviderConnections")
      .withIndex("by_workspaceId_providerId", (index) => index.eq("workspaceId", args.workspaceId).eq("providerId", "public"))
      .unique();
    if (!connection) return null;

    const now = Date.now();
    const intents = await ctx.db
      .query("camaroIntents")
      .withIndex("by_workspaceId_createdAt", (index) => index.eq("workspaceId", args.workspaceId))
      .collect();
    const result = reconcileBrokerSnapshot(
      {
        providerId: "public",
        syncedAt: now,
        accounts: [],
        positions: args.positions,
        orders: [],
        fills: [],
      },
      intents.map((intent) => ({ symbol: intent.symbol }))
    );

    await ctx.db.patch(connection._id, { status: "connected_read_only", lastSyncedAt: now, updatedAt: now });
    await ctx.db.insert("camaroBrokerSnapshots", {
      workspaceId: args.workspaceId,
      connectionId: connection._id,
      providerId: "public",
      accounts: args.accounts,
      positions: args.positions,
      syncedAt: now,
      createdAt: now,
    });
    await ctx.db.insert("camaroReconciliationReceipts", {
      workspaceId: args.workspaceId,
      connectionId: connection._id,
      providerId: "public",
      ...result,
      createdBy: connection.createdBy,
      createdAt: now,
    });
    await ctx.db.insert("camaroAudit", {
      workspaceId: args.workspaceId,
      eventType: "public_read_only_sync_verified",
      summary: `Verified Public account and portfolio snapshot recorded with ${args.positions.length} position(s).`,
      createdBy: connection.createdBy,
      createdAt: now,
    });
    return connection._id;
  },
});

export const getExecutionIntentForBroker = internalQuery({
  args: { intentId: v.id("camaroExecutionIntents") },
  handler: async (ctx, args) => {
    const intent = await ctx.db.get(args.intentId);
    if (!intent) return null;
    const settings = await ctx.db.query("camaroExecutionSettings")
      .withIndex("by_workspaceId_providerId", (index) => index.eq("workspaceId", intent.workspaceId).eq("providerId", "public"))
      .unique();
    const connection = await ctx.db.query("camaroProviderConnections")
      .withIndex("by_workspaceId_providerId", (index) => index.eq("workspaceId", intent.workspaceId).eq("providerId", "public"))
      .unique();
    const reconciliation = await ctx.db.query("camaroReconciliationReceipts")
      .withIndex("by_workspaceId_createdAt", (index) => index.eq("workspaceId", intent.workspaceId)).order("desc").first();
    const ownerMembership = intent.ownerApprovedBy ? await ctx.db.query("workspaceMembers")
      .withIndex("by_workspaceId_userId", (index) => index.eq("workspaceId", intent.workspaceId).eq("userId", intent.ownerApprovedBy!))
      .unique() : null;
    const ownerConsent = intent.ownerApprovedBy ? await ctx.db.query("camaroBrokerConsents")
      .withIndex("by_workspaceId_userId_createdAt", (index) => index.eq("workspaceId", intent.workspaceId).eq("userId", intent.ownerApprovedBy!))
      .order("desc")
      .first() : null;
    return { intent, settings, connection, reconciliation, ownerAuthorityValid: Boolean(ownerMembership?.role === "owner" && ownerConsent && isCurrentPublicConsent(ownerConsent)) };
  },
});

export const recordBrokerOrderResult = internalMutation({
  args: {
    intentId: v.id("camaroExecutionIntents"),
    eventType: v.union(v.literal("preflight_passed"), v.literal("preflight_failed"), v.literal("confirmation_requested"), v.literal("owner_approval_recorded"), v.literal("submission_attempt"), v.literal("broker_accepted"), v.literal("broker_rejected"), v.literal("submission_failed"), v.literal("status_updated"), v.literal("fill_recorded"), v.literal("cancellation_attempt"), v.literal("cancellation_result"), v.literal("execution_blocked")),
    summary: v.string(),
    status: v.optional(v.union(v.literal("awaiting_confirmation"), v.literal("submitting"), v.literal("submitted"), v.literal("accepted"), v.literal("partially_filled"), v.literal("filled"), v.literal("rejected"), v.literal("cancel_pending"), v.literal("cancelled"), v.literal("blocked"))),
    preflightStatus: v.optional(v.union(v.literal("pending"), v.literal("passed"), v.literal("failed"))),
    externalOrderReference: v.optional(v.string()),
    orderId: v.optional(v.string()),
    retryState: v.optional(v.union(v.literal("initial"), v.literal("retry"), v.literal("duplicate_blocked"))),
    outboundAttemptResult: v.optional(v.union(v.literal("started"), v.literal("accepted"), v.literal("rejected"), v.literal("failed"), v.literal("not_sent"))),
    orderStatus: v.optional(v.union(v.literal("submitted"), v.literal("accepted"), v.literal("partially_filled"), v.literal("filled"), v.literal("rejected"), v.literal("cancel_pending"), v.literal("cancelled"), v.literal("unknown"))),
    filledQuantity: v.optional(v.number()),
    preflightVerifiedAt: v.optional(v.number()),
    blockReason: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const intent = await ctx.db.get(args.intentId);
    if (!intent) return null;
    const { intentId, eventType, summary, blockReason, ...patch } = args;
    await ctx.db.patch(intentId, patch);
    await ctx.db.insert("camaroExecutionReceipts", {
      workspaceId: intent.workspaceId,
      providerId: "public",
      eventType,
      intentId,
      ...(args.orderId ? { orderId: args.orderId } : {}),
      ...(args.retryState ? { retryState: args.retryState } : {}),
      ...(args.outboundAttemptResult ? { outboundAttemptResult: args.outboundAttemptResult } : {}),
      ...(blockReason ? { blockReason } : {}),
      summary,
      createdBy: intent.createdBy,
      createdAt: Date.now(),
    });
    return intentId;
  },
});

export const claimBrokerSubmission = internalMutation({
  args: { intentId: v.id("camaroExecutionIntents"), liveFlagEnabled: v.boolean(), tradingPermissionVerified: v.boolean(), pdtLiveConstraintsVerified: v.boolean() },
  handler: async (ctx, args) => {
    const intent = await ctx.db.get(args.intentId);
    if (!intent) return { state: "blocked" as const, blockReason: "INTENT_NOT_FOUND" };
    try {
      assertPublicOrderId(intent.orderId);
    } catch {
      await ctx.db.insert("camaroExecutionReceipts", {
        workspaceId: intent.workspaceId,
        providerId: "public",
        eventType: "execution_blocked",
        intentId: intent._id,
        retryState: "duplicate_blocked",
        outboundAttemptResult: "not_sent",
        summary: "Broker submission blocked because the immutable Public orderId is missing or malformed. No order was sent.",
        createdBy: intent.createdBy,
        createdAt: Date.now(),
      });
      return { state: "invalid_order_id" as const, blockReason: PUBLIC_ORDER_BLOCK_REASONS.INVALID_ORDER_ID };
    }
    if (intent.status === "submitting") {
      await ctx.db.insert("camaroExecutionReceipts", {
        workspaceId: intent.workspaceId,
        providerId: "public",
        eventType: "execution_blocked",
        intentId: intent._id,
        orderId: intent.orderId,
        retryState: "duplicate_blocked",
        outboundAttemptResult: "not_sent",
        summary: "Duplicate broker submission was blocked after the immutable intent was already claimed. No additional order was sent.",
        createdBy: intent.createdBy,
        createdAt: Date.now(),
      });
      return { state: "duplicate" as const, blockReason: PUBLIC_ORDER_BLOCK_REASONS.DUPLICATE_SUBMISSION };
    }
    const settings = await ctx.db.query("camaroExecutionSettings").withIndex("by_workspaceId_providerId", (index) => index.eq("workspaceId", intent.workspaceId).eq("providerId", "public")).unique();
    const connection = await ctx.db.query("camaroProviderConnections").withIndex("by_workspaceId_providerId", (index) => index.eq("workspaceId", intent.workspaceId).eq("providerId", "public")).unique();
    const reconciliation = await ctx.db.query("camaroReconciliationReceipts").withIndex("by_workspaceId_createdAt", (index) => index.eq("workspaceId", intent.workspaceId)).order("desc").first();
    // !settings.liveOrderGateEnabled is intentionally enforced by the shared order-gate evaluator.
    const blockReason = evaluatePublicOrderGate({ now: Date.now(), liveFlagEnabled: args.liveFlagEnabled, tradingPermissionVerified: args.tradingPermissionVerified, pdtLiveConstraintsVerified: args.pdtLiveConstraintsVerified, settings, connection, reconciliation, intent });
    if (blockReason) {
      await ctx.db.insert("camaroExecutionReceipts", { workspaceId: intent.workspaceId, providerId: "public", eventType: "execution_blocked", intentId: intent._id, orderId: intent.orderId, retryState: "initial", outboundAttemptResult: "not_sent", blockReason, summary: `Broker submission blocked by ${blockReason}; no order was sent.`, createdBy: intent.createdBy, createdAt: Date.now() });
      return { state: "blocked" as const, blockReason };
    }
    const retryState = (intent.submissionAttemptCount ?? 0) > 0 ? "retry" as const : "initial" as const;
    await ctx.db.patch(intent._id, { status: "submitting", submissionAttemptCount: (intent.submissionAttemptCount ?? 0) + 1 });
    await ctx.db.insert("camaroExecutionReceipts", { workspaceId: intent.workspaceId, providerId: "public", eventType: "submission_attempt", intentId: intent._id, orderId: intent.orderId, retryState, outboundAttemptResult: "started", summary: "Broker submission claimed once with the immutable Public orderId.", createdBy: intent.createdBy, createdAt: Date.now() });
    return { state: "claimed" as const, intent };
  },
});

export const findExecutionIntent = internalQuery({
  args: { workspaceId: v.id("workspaces"), intentHash: v.string(), authorityScope: v.string() },
  handler: async (ctx, args) => {
    const intent = await ctx.db.query("camaroExecutionIntents")
      .withIndex("by_workspaceId_intentHash", (index) => index.eq("workspaceId", args.workspaceId).eq("intentHash", args.intentHash))
      .unique();
    return intent;
  },
});

export const authorizeExecutionWorkspace = internalQuery({
  args: { workspaceId: v.id("workspaces"), userId: v.id("users") },
  handler: async (ctx, args) => {
    const membership = await ctx.db.query("workspaceMembers").withIndex("by_workspaceId_userId", (index) => index.eq("workspaceId", args.workspaceId).eq("userId", args.userId)).unique();
    return Boolean(membership);
  },
});

export const authorizeExecutionAction = internalQuery({
  args: { workspaceId: v.id("workspaces"), intentId: v.id("camaroExecutionIntents"), userId: v.id("users") },
  handler: async (ctx, args) => {
    const membership = await ctx.db.query("workspaceMembers").withIndex("by_workspaceId_userId", (index) => index.eq("workspaceId", args.workspaceId).eq("userId", args.userId)).unique();
    const consent = await ctx.db.query("camaroBrokerConsents").withIndex("by_workspaceId_userId_createdAt", (index) => index.eq("workspaceId", args.workspaceId).eq("userId", args.userId)).order("desc").first();
    const intent = await ctx.db.get(args.intentId);
    return Boolean(membership && consent && isCurrentPublicConsent(consent) && intent?.workspaceId === args.workspaceId);
  },
});
