export const PUBLIC_ORDER_BLOCK_REASONS = Object.freeze({
  LIVE_FLAG_OFF: "LIVE_FLAG_OFF",
  WORKSPACE_GATE_OFF: "WORKSPACE_GATE_OFF",
  OWNER_APPROVAL_REQUIRED: "OWNER_APPROVAL_REQUIRED",
  AUTHORITY_CONSENT_REQUIRED: "AUTHORITY_CONSENT_REQUIRED",
  BROKER_CONNECTIVITY_REQUIRED: "BROKER_CONNECTIVITY_REQUIRED",
  BROKER_PERMISSION_UNVERIFIED: "BROKER_PERMISSION_UNVERIFIED",
  RECONCILIATION_REQUIRED: "RECONCILIATION_REQUIRED",
  PDT_LIVE_CONSTRAINTS_UNVERIFIED: "PDT_LIVE_CONSTRAINTS_UNVERIFIED",
  RISK_CHECK_FAILED: "RISK_CHECK_FAILED",
  PREFLIGHT_REQUIRED: "PREFLIGHT_REQUIRED",
  INTENT_EXPIRED: "INTENT_EXPIRED",
  INVALID_ORDER_ID: "INVALID_ORDER_ID",
  DUPLICATE_SUBMISSION: "DUPLICATE_SUBMISSION",
});

export function evaluatePublicOrderGate({
  now = Date.now(),
  liveFlagEnabled,
  tradingPermissionVerified,
  pdtLiveConstraintsVerified,
  settings,
  connection,
  reconciliation,
  intent,
}) {
  if (!liveFlagEnabled) return PUBLIC_ORDER_BLOCK_REASONS.LIVE_FLAG_OFF;
  if (!settings?.liveOrderGateEnabled || settings.mode !== "OPERATOR_CONFIRM_REQUIRED") return PUBLIC_ORDER_BLOCK_REASONS.WORKSPACE_GATE_OFF;
  if (intent.ownerApprovalStatus !== "approved" || !intent.ownerApprovedBy || !intent.ownerApprovedAt) return PUBLIC_ORDER_BLOCK_REASONS.OWNER_APPROVAL_REQUIRED;
  if (!intent.authorityScope?.trim()) return PUBLIC_ORDER_BLOCK_REASONS.AUTHORITY_CONSENT_REQUIRED;
  if (connection?.status !== "connected_read_only" || !connection.lastSyncedAt || now - connection.lastSyncedAt > 15 * 60 * 1000) return PUBLIC_ORDER_BLOCK_REASONS.BROKER_CONNECTIVITY_REQUIRED;
  if (!tradingPermissionVerified) return PUBLIC_ORDER_BLOCK_REASONS.BROKER_PERMISSION_UNVERIFIED;
  if (reconciliation?.status !== "reconciled") return PUBLIC_ORDER_BLOCK_REASONS.RECONCILIATION_REQUIRED;
  if (!pdtLiveConstraintsVerified) return PUBLIC_ORDER_BLOCK_REASONS.PDT_LIVE_CONSTRAINTS_UNVERIFIED;
  if (intent.riskStatus !== "passed") return PUBLIC_ORDER_BLOCK_REASONS.RISK_CHECK_FAILED;
  if (intent.preflightStatus !== "passed" || !intent.preflightVerifiedAt) return PUBLIC_ORDER_BLOCK_REASONS.PREFLIGHT_REQUIRED;
  if (intent.expiresAt <= now) return PUBLIC_ORDER_BLOCK_REASONS.INTENT_EXPIRED;
  return null;
}

export function evaluatePublicPreflightGate(input) {
  const { intent } = input;
  if (!input.liveFlagEnabled) return PUBLIC_ORDER_BLOCK_REASONS.LIVE_FLAG_OFF;
  if (!input.settings?.liveOrderGateEnabled || input.settings.mode !== "OPERATOR_CONFIRM_REQUIRED") return PUBLIC_ORDER_BLOCK_REASONS.WORKSPACE_GATE_OFF;
  if (!intent.ownerApprovalStatus || intent.ownerApprovalStatus !== "approved" || !intent.ownerApprovedBy || !intent.ownerApprovedAt) return PUBLIC_ORDER_BLOCK_REASONS.OWNER_APPROVAL_REQUIRED;
  if (!input.ownerAuthorityValid || !intent.authorityScope?.trim()) return PUBLIC_ORDER_BLOCK_REASONS.AUTHORITY_CONSENT_REQUIRED;
  if (input.connection?.status !== "connected_read_only" || !input.connection.lastSyncedAt || input.now - input.connection.lastSyncedAt > 15 * 60 * 1000) return PUBLIC_ORDER_BLOCK_REASONS.BROKER_CONNECTIVITY_REQUIRED;
  if (!input.tradingPermissionVerified) return PUBLIC_ORDER_BLOCK_REASONS.BROKER_PERMISSION_UNVERIFIED;
  if (input.reconciliation?.status !== "reconciled") return PUBLIC_ORDER_BLOCK_REASONS.RECONCILIATION_REQUIRED;
  if (!input.pdtLiveConstraintsVerified) return PUBLIC_ORDER_BLOCK_REASONS.PDT_LIVE_CONSTRAINTS_UNVERIFIED;
  if (intent.riskStatus !== "passed") return PUBLIC_ORDER_BLOCK_REASONS.RISK_CHECK_FAILED;
  if (intent.status !== "awaiting_confirmation" || intent.preflightStatus !== "pending" || intent.expiresAt <= input.now) return PUBLIC_ORDER_BLOCK_REASONS.INTENT_EXPIRED;
  return null;
}
