# IGNISpilot Handoff

This repository is a **sanitized source handoff** for IGNISpilot. It is intentionally independent of the live application repository and contains source code and tests only.

## Included

- Next.js application source, Convex functions, Camaro CLI source, and tests.
- Dependency manifests (`package.json` and `package-lock.json`).
- No deployment linkage, production runtime state, generated output, or credentials.

## Local setup

1. Install Node.js 20 LTS or later and npm.
2. Install dependencies:

   ```bash
   npm ci
   ```

3. Copy `.env.example.template` to `.env.local` and fill values supplied through an approved secret manager. Never commit that file.
4. Generate Convex types and run the app:

   ```bash
   npm run convex:codegen
   npm run dev
   ```

5. Verify production readiness locally:

   ```bash
   npx tsc --noEmit
   npm run build
   ```

## Security boundaries

- This handoff excludes all `.env` files, credentials, secrets, broker tokens, runtime state, generated artifacts, local caches, and deployment metadata.
- Keep production values in your secret manager or hosting-provider environment settings; do not place them in Git, issues, pull requests, or client-side `NEXT_PUBLIC_` variables unless they are intentionally public.
- The included environment template lists variable **names only**, with no values. Treat every non-public variable as server-side only.
- This repository does not establish a connection to the live IGNISpilot deployment. Configure a separate development or staging environment before running server-side integrations.

## Trading and order-submission safety

Camaro may evaluate conditions and create execution intent, but identity or seat assignment never authorizes broker activity. Live trading/order submission remains policy-gated and fails closed unless all required controls are satisfied, including explicit server-side live-order enablement, verified broker permissions, owner authority, risk/PDT checks, reconciliation, and required confirmations. Do not enable `PUBLIC_LIVE_ORDER_GATE_ENABLED` outside an owner-approved environment.

## Collaboration

Suggested remote target: `https://github.com/REDSLATE/IGNIS.git`.

After a REDSLATE maintainer clones this handoff and confirms source review, they can publish it without force-pushing:

```bash
git remote add origin https://github.com/REDSLATE/IGNIS.git
git fetch origin
git merge origin/main --allow-unrelated-histories
git push -u origin main
```

Grant the REDSLATE organization access from the repository owner’s GitHub settings as appropriate for its internal team policy. This handoff does not contain GitHub credentials or collaborator invitations.


## Live trading activation runbook

The source handoff is intentionally **not live-enabled by default**. To make the existing operator-confirmed Public order path usable without removing its risk controls:

1. Create a separate staging or production Convex deployment and configure `PUBLIC_PERSONAL_SECRET_TOKEN`.
2. Set `PUBLIC_ACCOUNT_ID` to the Public account ID returned by the authenticated account endpoint. The legacy `PUBLIC_READ_ONLY_WORKSPACE_ID` variable is still accepted during migration.
3. Verify that the credential can access the documented trading endpoints, then set `PUBLIC_TRADING_PERMISSION_VERIFIED=true`.
4. Review the account's current day-trading and buying-power constraints, then set `PUBLIC_PDT_LIVE_CONSTRAINTS_VERIFIED=true`. This is an operational attestation; the application does not infer legal or account eligibility.
5. Set `PUBLIC_LIVE_ORDER_GATE_ENABLED=true`.
6. In the application, record current Public consent, select `OPERATOR_CONFIRM_REQUIRED`, and have a workspace owner explicitly arm the workspace live-order gate.
7. Create an immutable intent, approve it as owner, run preflight, review the final order, and submit before the five-minute intent expiry.

Preflight now performs one automatic read-only refresh when broker state is stale or unreconciled. It still fails closed when connectivity, reconciliation, permissions, risk, consent, approval, or expiry checks do not pass.

### Common block reasons

- `LIVE_FLAG_OFF`: `PUBLIC_LIVE_ORDER_GATE_ENABLED` is not exactly `true` in the Convex server environment.
- `WORKSPACE_GATE_OFF`: the workspace is not in `OPERATOR_CONFIRM_REQUIRED`, or the owner has not armed its gate.
- `BROKER_PERMISSION_UNVERIFIED`: `PUBLIC_TRADING_PERMISSION_VERIFIED` is not exactly `true`.
- `PDT_LIVE_CONSTRAINTS_UNVERIFIED`: `PUBLIC_PDT_LIVE_CONSTRAINTS_VERIFIED` is not exactly `true`.
- `BROKER_CONNECTIVITY_REQUIRED`: the Public credential/account selection is invalid or the refresh failed.
- `RECONCILIATION_REQUIRED`: the latest broker snapshot does not reconcile with recorded state.
- `OWNER_APPROVAL_REQUIRED`, `PREFLIGHT_REQUIRED`, or `INTENT_EXPIRED`: complete the immutable owner-review flow within the intent TTL.

## Manual live order workflow

The owner-operated ticket is a live-only workflow. It does not place a paper order and does not submit automatically.

1. Enter symbol, side, quantity/notional, order type, and optional limit price.
2. Create the manual live ticket. The authenticated workspace owner confirmation is attached to that immutable ticket.
3. Run Public broker preflight.
4. Review the final ticket and press **Submit live order** before expiry.
5. Refresh the broker status until filled, rejected, cancelled, or expired.

The server still requires current consent, `OPERATOR_CONFIRM_REQUIRED`, the workspace live gate, verified broker permissions/PDT controls, fresh reconciliation, risk bounds, and idempotency.


## Brand assets

The supplied IGNISpilot visual system is included under `public/brand/` and wired into the site header, application sidebar, browser icons, and metadata defaults.

- `ignispilot-icon-orange.png` — primary console mark
- `ignispilot-icon-dark.png` — dark-mode monochrome mark
- `ignispilot-icon-light.png` — light-mode browser/app mark
- `ignispilot-wordmark-dark.png` — primary wordmark presentation
- `ignispilot-brand-board.png` — source visual-system reference
- `icon-192.png` and `icon-512.png` — app/PWA-ready icon sizes

The original environment-variable logo overrides remain supported, so a deployment may replace these assets without source changes.

## Direct manual live trading (FastAPI)

The new `/app/live-trade` screen bypasses Convex for all broker operations. It uses a protected Next.js server proxy to call `execution-service/`, which then calls Public for live quotes, portfolio, preflight, order submission, status, and cancellation.

Start the execution service first, configure matching `EXECUTION_SERVICE_TOKEN` values in both environments, then run Next.js. Keep `LIVE_TRADING_ENABLED=false` until reads and preflight work. Setting it to `true` enables only the explicit final **Confirm and submit live order** operation.
